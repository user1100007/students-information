export interface ColumnGroup {
  id: string;
  titleKm: string;
  titleEn: string;
  columns: ColumnDefinition[];
}

export interface ColumnDefinition {
  id: string;
  key: keyof StudentRecord;
  labelKm: string;
  labelEn: string;
  required?: boolean;
  type?: 'text' | 'date' | 'number' | 'select' | 'tel';
  options?: string[];
  placeholderKm?: string;
  placeholderEn?: string;
}

export interface StudentRecord {
  id: string; // Internal unique identifier
  // Group 1: ព័ត៌មានសិស្ស (Student Info)
  studentCode: string; // អត្តលេខ
  lastName: string; // គោត្តនាម *
  firstName: string; // នាម *
  gender: string; // ភេទ * (ប្រុស / ស្រី)
  dob: string; // ថ្ងៃខែឆ្នាំកំណើត
  age?: number | string; // អាយុ
  phone: string; // ទូរស័ព្ទ
  nationality: string; // សញ្ជាតិ

  // Group 2: ទីកន្លែងកំណើត (Place of Birth)
  pobProvince: string; // ខេត្ត/ក្រុង
  pobDistrict: string; // ស្រុក/ខណ្ឌ
  pobCommune: string; // ឃុំ/សង្កាត់
  pobVillage: string; // ភូមិ

  // Group 3: អាសយដ្ឋានបច្ចុប្បន្ន (Current Address)
  curProvince: string; // ខេត្ត/ក្រុង
  curDistrict: string; // ស្រុក/ខណ្ឌ
  curCommune: string; // ឃុំ/សង្កាត់
  curVillage: string; // ភូមិ

  // Group 4: ព័ត៌មានសិក្សា (Academic Info)
  academicYear: string; // ឆ្នាំសិក្សា
  previousGrade: string; // ថ្នាក់ឆ្នាំមុន
  enrollmentDate: string; // ថ្ងៃចុះឈ្មោះចូលរៀន
  disabilityType: string; // ប្រភេទពិការភាព

  // Group 5: កញ្ចប់សម្ភារជំនួយ (Support Packages)
  kitReading: string; // កញ្ចប់អំណាន
  kitMath: string; // កញ្ចប់គណិត
  kitKhmerBook: string; // សៀវភៅជំនួយភាសាខ្មែរ
  kitMathBook: string; // សៀវភៅជំនួយគណិតវិទ្យា

  // Group 6: សមធម៌ (Equity / IDPoor)
  equityFamily: string; // គ្រួសារក្រីក្រ
  equityCard: string; // បណ្ណសមធម៌

  // Group 7: ព័ត៌មានបន្ថែមសិស្ស (Additional Info)
  ethnicMinority: string; // ជនជាតិភាគតិច
  specialTrait: string; // លក្ខណៈពិសេស
  orphanStatus?: string; // ស្ថានភាពកំព្រា (មិនកំព្រា / កំព្រាឪពុក / កំព្រាម្ដាយ / កំព្រាឪពុកម្ដាយ)

  // Group 8: ទម្ងន់/កម្ពស់ ឆមាស១ (Semester 1 Health)
  weightSem1: string; // ទម្ងន់
  heightSem1: string; // កម្ពស់
  bmiSem1?: string; // BMI ឆមាស១
  bmiStatusSem1?: string; // ស្ថានភាព BMI ឆមាស១

  // Group 9: ទម្ងន់/កម្ពស់ ឆមាស២ (Semester 2 Health)
  weightSem2: string; // ទម្ងន់
  heightSem2: string; // កម្ពស់
  bmiSem2?: string; // BMI ឆមាស២
  bmiStatusSem2?: string; // ស្ថានភាព BMI ឆមាស២
  otherNotes?: string; // សេចក្តីផ្សេងៗ

  // Group 10: ភ្នែក (Vision)
  eyeLeft: string; // ឆ្វេង
  eyeRight: string; // ស្ដាំ
  eyeBoth: string; // ទាំងពីរ
  eyeResult: string; // លទ្ធផល
  eyePrescription: string; // វេជ្ជបញ្ជា
  eyeDevice: string; // ឧបករណ៍

  // Group 11: ត្រចៀក (Hearing)
  earLeft: string; // ឆ្វេង
  earRight: string; // ស្ដាំ
  earBoth: string; // ទាំងពីរ
  earResult: string; // លទ្ធផល
  earPrescription: string; // វេជ្ជបញ្ជា
  earDevice: string; // ឧបករណ៍

  // Group 12: វ៉ាក់សាំង (Vaccination)
  vaccineList: string; // បញ្ជី

  // Group 13: ព័ត៌មានឪពុក (Father's Info)
  fatherLastName: string; // គោត្តនាម
  fatherFirstName: string; // នាម
  fatherPhone: string; // ទូរស័ព្ទ
  fatherOccupation: string; // មុខរបរ

  // Group 14: អាសយដ្ឋានឪពុក (Father's Address)
  fatherProvince: string; // ខេត្ត/ក្រុង
  fatherDistrict: string; // ស្រុក/ខណ្ឌ
  fatherCommune: string; // ឃុំ/សង្កាត់
  fatherVillage: string; // ភូមិ

  // Group 15: ព័ត៌មានម្ដាយ (Mother's Info)
  motherLastName: string; // គោត្តនាម
  motherFirstName: string; // នាម
  motherPhone: string; // ទូរស័ព្ទ
  motherOccupation: string; // មុខរបរ

  // Group 16: អាសយដ្ឋានម្ដាយ (Mother's Address)
  motherProvince: string; // ខេត្ត/ក្រុង
  motherDistrict: string; // ស្រុក/ខណ្ឌ
  motherCommune: string; // ឃុំ/សង្កាត់
  motherVillage: string; // ភូមិ

  // Group 17: អាណាព្យាបាល (Guardian)
  guardianType: string; // ប្រភេទ
  guardianLastName: string; // គោត្តនាម
  guardianFirstName: string; // នាម
  guardianGender: string; // ភេទ
  guardianPhone: string; // ទូរស័ព្ទ
  guardianOccupation: string; // មុខរបរ
  guardianAddress: string; // អាសយដ្ឋាន
}

export type Language = 'km' | 'en';
