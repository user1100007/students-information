/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { StatsOverview } from './components/StatsOverview';
import { StudentTable } from './components/StudentTable';
import { StudentDetailModal } from './components/StudentDetailModal';
import { StudentFormModal } from './components/StudentFormModal';
import { ImportModal } from './components/ImportModal';
import { ReportModal, ReportType } from './components/ReportModal';
import { AnalyticsView } from './components/AnalyticsView';
import { HealthEquityView } from './components/HealthEquityView';
import { GuidelinesView } from './components/GuidelinesView';
import { AuthModal } from './components/AuthModal';
import { StudentRecord, Language } from './types/student';
import { SAMPLE_STUDENTS } from './data/initialData';
import { autoCalculateStudentFields } from './utils/calculations';
import {
  auth,
  User,
  onAuthStateChanged,
  signOut,
  saveStudentToCloud,
  deleteStudentFromCloud,
  syncAllStudentsToCloud,
  loadStudentsFromCloud,
  testFirestoreConnection,
} from './firebase';

const STORAGE_KEY = 'moeys_students_data_v1';
const LANG_STORAGE_KEY = 'moeys_sis_lang';

export default function App() {
  const [lang, setLang] = useState<Language>(() => {
    const saved = localStorage.getItem(LANG_STORAGE_KEY);
    return saved === 'en' ? 'en' : 'km';
  });

  const [activeTab, setActiveTab] = useState<'table' | 'analytics' | 'health' | 'guidelines'>('table');

  // Firebase Auth State
  const [user, setUser] = useState<User | null>(null);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [lastCloudSyncTime, setLastCloudSyncTime] = useState<string | null>(null);
  const [cloudToast, setCloudToast] = useState<string | null>(null);

  const [students, setStudents] = useState<StudentRecord[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch (e) {
      console.error('Failed to load students from localStorage', e);
    }
    return SAMPLE_STUDENTS;
  });

  // Modals state
  const [viewingStudent, setViewingStudent] = useState<StudentRecord | null>(null);
  const [editingStudent, setEditingStudent] = useState<StudentRecord | null>(null);
  const [isFormModalOpen, setIsFormModalOpen] = useState(false);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);
  const [selectedReportType, setSelectedReportType] = useState<ReportType>('attendance_roster');

  const showCloudToast = (msg: string) => {
    setCloudToast(msg);
    setTimeout(() => setCloudToast(null), 3000);
  };

  // Listen to Firebase Auth state
  useEffect(() => {
    testFirestoreConnection();
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        // Automatically check if Firestore has cloud student records
        try {
          const cloudStudents = await loadStudentsFromCloud();
          if (cloudStudents.length > 0) {
            setStudents(cloudStudents);
            setLastCloudSyncTime(new Date().toLocaleTimeString());
            showCloudToast(
              lang === 'km'
                ? `បានទាញយកទិន្នន័យសិស្ស ${cloudStudents.length} នាក់ពី Cloud Firestore`
                : `Loaded ${cloudStudents.length} students from Cloud Firestore`
            );
          } else {
            // Push initial sample students to cloud if cloud is empty
            await syncAllStudentsToCloud(students);
            setLastCloudSyncTime(new Date().toLocaleTimeString());
          }
        } catch (err) {
          console.warn('Initial cloud sync check:', err);
        }
      }
    });
    return () => unsubscribe();
  }, []);

  const handleOpenReport = (type: ReportType) => {
    setSelectedReportType(type);
    setIsReportModalOpen(true);
  };

  // Sync to local storage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(students));
    } catch (e) {
      console.error('Failed to save students to localStorage', e);
    }
  }, [students]);

  const toggleLanguage = () => {
    const nextLang = lang === 'km' ? 'en' : 'km';
    setLang(nextLang);
    localStorage.setItem(LANG_STORAGE_KEY, nextLang);
  };

  // Student CRUD with cloud synchronization
  const handleOpenAdd = () => {
    setEditingStudent(null);
    setIsFormModalOpen(true);
  };

  const handleEditStudent = (student: StudentRecord) => {
    setViewingStudent(null);
    setEditingStudent(student);
    setIsFormModalOpen(true);
  };

  const handleSaveStudent = async (saved: StudentRecord) => {
    const calculated = autoCalculateStudentFields(saved);
    setStudents((prev) => {
      const index = prev.findIndex((s) => s.id === calculated.id);
      if (index >= 0) {
        const updated = [...prev];
        updated[index] = calculated;
        return updated;
      }
      return [calculated, ...prev];
    });

    if (user) {
      try {
        await saveStudentToCloud(calculated);
        setLastCloudSyncTime(new Date().toLocaleTimeString());
      } catch (err) {
        console.error('Failed to sync student to cloud:', err);
      }
    }
  };

  const handleUpdateStudent = async (updatedStudent: StudentRecord) => {
    const calculated = autoCalculateStudentFields(updatedStudent);
    setStudents((prev) => prev.map((s) => (s.id === calculated.id ? calculated : s)));

    if (user) {
      try {
        await saveStudentToCloud(calculated);
        setLastCloudSyncTime(new Date().toLocaleTimeString());
      } catch (err) {
        console.error('Failed to auto-sync to cloud:', err);
      }
    }
  };

  const handleRecalculateAll = async () => {
    const recalculated = students.map((s) => autoCalculateStudentFields(s));
    setStudents(recalculated);

    if (user) {
      setIsSyncing(true);
      try {
        await syncAllStudentsToCloud(recalculated);
        setLastCloudSyncTime(new Date().toLocaleTimeString());
        showCloudToast(
          lang === 'km'
            ? 'បានគណនា និងរក្សាទុកគ្រប់សិស្សទាំងអស់ទៅ Cloud Firestore រួចរាល់!'
            : 'Recalculated & synced all students to Cloud Firestore!'
        );
      } catch (err) {
        console.error('Error batch syncing recalculations:', err);
      } finally {
        setIsSyncing(false);
      }
    }
  };

  const handleDeleteStudent = async (studentId: string) => {
    setStudents((prev) => prev.filter((s) => s.id !== studentId));
    if (user) {
      try {
        await deleteStudentFromCloud(studentId);
      } catch (err) {
        console.error('Failed to delete student from cloud:', err);
      }
    }
  };

  const handleDeleteMultiple = async (ids: string[]) => {
    setStudents((prev) => prev.filter((s) => !ids.includes(s.id)));
    if (user) {
      for (const id of ids) {
        try {
          await deleteStudentFromCloud(id);
        } catch (e) {
          console.error('Cloud delete error:', e);
        }
      }
    }
  };

  const handleResetData = () => {
    if (
      confirm(
        lang === 'km'
          ? 'តើអ្នកពិតជាចង់កំណត់ទិន្នន័យឡើងវិញទៅគំរូដើមមែនទេ?'
          : 'Reset all student data to the original sample dataset?'
      )
    ) {
      setStudents(SAMPLE_STUDENTS);
      localStorage.removeItem(STORAGE_KEY);
      if (user) {
        syncAllStudentsToCloud(SAMPLE_STUDENTS);
      }
    }
  };

  const handleImport = async (newStudents: StudentRecord[], mode: 'append' | 'replace') => {
    let finalStudents: StudentRecord[] = [];
    if (mode === 'replace') {
      finalStudents = newStudents;
      setStudents(newStudents);
    } else {
      finalStudents = [...students, ...newStudents];
      setStudents((prev) => [...prev, ...newStudents]);
    }
    setActiveTab('table');

    if (user) {
      setIsSyncing(true);
      try {
        await syncAllStudentsToCloud(finalStudents);
        setLastCloudSyncTime(new Date().toLocaleTimeString());
        showCloudToast(
          lang === 'km'
            ? `បានបញ្ចូលទិន្នន័យ និងរក្សាទុក ${newStudents.length} នាក់លើ Cloud Firestore`
            : `Imported and synced ${newStudents.length} students to Cloud Firestore`
        );
      } catch (e) {
        console.error('Failed to sync import to cloud:', e);
      } finally {
        setIsSyncing(false);
      }
    }
  };

  // Manual Trigger: Cloud Sync
  const handleSyncToCloud = async () => {
    if (!user) {
      setIsAuthModalOpen(true);
      return;
    }

    setIsSyncing(true);
    try {
      const count = await syncAllStudentsToCloud(students);
      setLastCloudSyncTime(new Date().toLocaleTimeString());
      showCloudToast(
        lang === 'km'
          ? `បានរក្សាទុកទិន្នន័យសិស្សទាំង ${count} នាក់លើ Cloud Firestore រួចរាល់!`
          : `Successfully synchronized ${count} students to Cloud Firestore!`
      );
    } catch (err: unknown) {
      console.error('Cloud sync error:', err);
      showCloudToast(
        lang === 'km' ? 'មានបញ្ហាក្នុងការសមកាលកម្ម Cloud' : 'Failed to sync with Cloud'
      );
    } finally {
      setIsSyncing(false);
    }
  };

  const [showStats, setShowStats] = useState(true);

  // Calculate next sequential student ID e.g. "0008"
  const nextStudentCode = `000${students.length + 1}`.slice(-4);

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900 flex flex-col font-sans">
      {/* Top Bar with Brand, Navigation, Auth & Cloud Sync */}
      <Header
        lang={lang}
        onToggleLang={toggleLanguage}
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        onOpenAddModal={handleOpenAdd}
        user={user}
        onOpenAuthModal={() => setIsAuthModalOpen(true)}
        onSignOut={() => signOut(auth)}
        onSyncToCloud={handleSyncToCloud}
        isSyncing={isSyncing}
        lastCloudSyncTime={lastCloudSyncTime}
      />

      {/* Cloud Notification Toast */}
      {cloudToast && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white px-4 py-2.5 rounded-lg shadow-xl text-xs font-semibold flex items-center gap-2 animate-in fade-in slide-in-from-bottom-3 duration-200 border border-slate-700">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          <span>{cloudToast}</span>
        </div>
      )}

      {/* Main Content Area - Full width responsive */}
      <main className="flex-1 w-full max-w-[1720px] mx-auto px-2 sm:px-4 lg:px-6 py-2.5">
        {/* Breadcrumb & Section Kicker */}
        <div className="no-print flex items-center justify-between pb-1.5 text-xs text-slate-600">
          <div className="flex items-center gap-1.5">
            <span className="font-medium">{lang === 'km' ? 'ប្រព័ន្ធ SIS' : 'School SIS'}</span>
            <span aria-hidden="true">/</span>
            <span className="font-bold text-slate-900">
              {activeTab === 'table'
                ? lang === 'km'
                  ? 'បញ្ជីព័ត៌មានសិស្ស (៦៥ ជួរឈរ)'
                  : 'Student Roster (65 Columns)'
                : activeTab === 'analytics'
                ? lang === 'km'
                  ? 'ស្ថិតិ និងរបាយការណ៍សង្ខេប'
                  : 'Analytics & Demographics'
                : activeTab === 'health'
                ? lang === 'km'
                  ? 'សុខភាព និងសមធម៌សង្គម'
                  : 'Health & Equity Monitoring'
                : lang === 'km'
                ? 'សេចក្ដីណែនាំ និងស្ដង់ដារ MoEYS'
                : 'MoEYS Standard SIS Format'}
            </span>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setShowStats(!showStats)}
              className="hover:text-blue-700 transition-colors font-medium cursor-pointer"
            >
              {showStats
                ? lang === 'km'
                  ? 'លាក់ផ្ទាំងសង្ខេប ▲'
                  : 'Hide Stats ▲'
                : lang === 'km'
                ? 'បង្ហាញផ្ទាំងសង្ខេប ▼'
                : 'Show Stats ▼'}
            </button>
          </div>
        </div>

        {/* 5 Executive Metric Cards (Interactive: click to open relevant report) */}
        {showStats && (
          <div className="mb-2.5">
            <StatsOverview
              students={students}
              lang={lang}
              onOpenReport={handleOpenReport}
            />
          </div>
        )}

        {/* Active Tab View */}
        {activeTab === 'table' && (
          <StudentTable
            students={students}
            lang={lang}
            onViewStudent={(student) => setViewingStudent(student)}
            onEditStudent={handleEditStudent}
            onDeleteStudent={handleDeleteStudent}
            onDeleteMultiple={handleDeleteMultiple}
            onOpenImportModal={() => setIsImportModalOpen(true)}
            onOpenAddModal={handleOpenAdd}
            onResetData={handleResetData}
            onUpdateStudent={handleUpdateStudent}
            onRecalculateAll={handleRecalculateAll}
          />
        )}

        {activeTab === 'analytics' && (
          <AnalyticsView students={students} lang={lang} />
        )}

        {activeTab === 'health' && (
          <HealthEquityView
            students={students}
            lang={lang}
            onViewStudent={(student) => setViewingStudent(student)}
            onEditStudent={handleEditStudent}
          />
        )}

        {activeTab === 'guidelines' && <GuidelinesView lang={lang} />}
      </main>

      {/* Footer */}
      <footer className="no-print mt-auto border-t border-slate-200 bg-white py-4 text-xs text-slate-500">
        <div className="max-w-[1720px] mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div>
            <p className="font-semibold text-slate-700">
              {lang === 'km'
                ? 'ប្រព័ន្ធគ្រប់គ្រងព័ត៌មានសិស្សបឋមសិក្សា (SIS) · ក្រសួងអប់រំ យុវជន និងកីឡា'
                : 'Primary School Student Information System (SIS) · MoEYS'}
            </p>
            <p className="text-[11px] text-slate-400 mt-0.5">
              {lang === 'km'
                ? 'ភ្ជាប់ទៅ Google Cloud Firestore & Firebase Auth ដោយសុវត្ថិភាព'
                : 'Connected to Google Cloud Firestore & Firebase Authentication'}
            </p>
          </div>
          <div className="text-[11px] text-slate-500 flex items-center gap-3">
            <span>
              {user ? (
                <span className="text-emerald-700 font-semibold flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block"></span>
                  {lang === 'km' ? 'បានភ្ជាប់ Cloud' : 'Cloud Connected'}
                </span>
              ) : (
                <span className="text-slate-400">
                  {lang === 'km' ? 'រក្សាទិន្នន័យក្នុង Browser' : 'Local Storage Mode'}
                </span>
              )}
            </span>
          </div>
        </div>
      </footer>

      {/* Modals */}
      <AuthModal
        isOpen={isAuthModalOpen}
        lang={lang}
        onClose={() => setIsAuthModalOpen(false)}
      />

      <ReportModal
        isOpen={isReportModalOpen}
        initialReportType={selectedReportType}
        students={students}
        lang={lang}
        onClose={() => setIsReportModalOpen(false)}
      />

      <StudentDetailModal
        student={viewingStudent}
        lang={lang}
        onClose={() => setViewingStudent(null)}
        onEdit={handleEditStudent}
      />

      <StudentFormModal
        isOpen={isFormModalOpen}
        student={editingStudent}
        lang={lang}
        onClose={() => {
          setIsFormModalOpen(false);
          setEditingStudent(null);
        }}
        onSave={handleSaveStudent}
        nextStudentCode={nextStudentCode}
      />

      <ImportModal
        isOpen={isImportModalOpen}
        lang={lang}
        onClose={() => setIsImportModalOpen(false)}
        onImport={handleImport}
      />
    </div>
  );
}
