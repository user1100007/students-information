import React, { useState } from 'react';
import { X, Lock, Mail, User, ShieldCheck, AlertCircle, LogIn, UserPlus, Sparkles } from 'lucide-react';
import {
  auth,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signInAnonymously,
  updateProfile,
} from '../firebase';
import { Language } from '../types/student';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
}

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose, lang }) => {
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      if (mode === 'login') {
        await signInWithEmailAndPassword(auth, email, password);
      } else {
        const userCred = await createUserWithEmailAndPassword(auth, email, password);
        if (name.trim()) {
          await updateProfile(userCred.user, { displayName: name.trim() });
        }
      }
      onClose();
    } catch (err: unknown) {
      console.error('Firebase Auth Error:', err);
      if (err instanceof Error) {
        if (err.message.includes('user-not-found') || err.message.includes('wrong-password') || err.message.includes('invalid-credential')) {
          setError(lang === 'km' ? 'អ៊ីមែល ឬពាក្យសម្ងាត់មិនត្រឹមត្រូវទេ' : 'Invalid email or password');
        } else if (err.message.includes('email-already-in-use')) {
          setError(lang === 'km' ? 'អ៊ីមែលនេះមានគណនីរួចហើយ' : 'Email is already registered');
        } else if (err.message.includes('weak-password')) {
          setError(lang === 'km' ? 'ពាក្យសម្ងាត់ត្រូវមានយ៉ាងហោចណាស់ ៦ តួ' : 'Password must be at least 6 characters');
        } else {
          setError(err.message);
        }
      } else {
        setError(lang === 'km' ? 'មានបញ្ហាក្នុងការចូលប្រើប្រព័ន្ធ' : 'Failed to authenticate');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleAnonymousLogin = async () => {
    setError(null);
    setLoading(true);
    try {
      await signInAnonymously(auth);
      onClose();
    } catch (err: unknown) {
      console.error('Anonymous Auth Error:', err);
      if (err instanceof Error) {
        setError(err.message);
      } else {
        setError(lang === 'km' ? 'មិនអាចចូលប្រើសាកល្បងបានទេ' : 'Failed anonymous login');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-xl shadow-2xl border border-slate-200 max-w-md w-full overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="px-6 py-4 bg-gradient-to-r from-blue-900 to-indigo-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-white/10 flex items-center justify-center">
              <ShieldCheck className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <h3 className="font-bold text-base leading-snug">
                {lang === 'km' ? 'ការផ្ទៀងផ្ទាត់ Firebase Auth' : 'Firebase Authentication'}
              </h3>
              <p className="text-xs text-blue-200">
                {lang === 'km' ? 'គ្រប់គ្រងទិន្នន័យ និងរក្សាទុកលើ Cloud Firestore' : 'Secure Cloud Firestore Synchronization'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-white/80 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switcher */}
        <div className="flex border-b border-slate-200 bg-slate-50 text-sm font-semibold">
          <button
            onClick={() => {
              setMode('login');
              setError(null);
            }}
            className={`flex-1 py-3 text-center transition-colors cursor-pointer flex items-center justify-center gap-2 ${
              mode === 'login'
                ? 'bg-white text-blue-700 border-b-2 border-blue-700'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <LogIn className="w-4 h-4" />
            <span>{lang === 'km' ? 'ចូលប្រើប្រព័ន្ធ' : 'Sign In'}</span>
          </button>
          <button
            onClick={() => {
              setMode('signup');
              setError(null);
            }}
            className={`flex-1 py-3 text-center transition-colors cursor-pointer flex items-center justify-center gap-2 ${
              mode === 'signup'
                ? 'bg-white text-blue-700 border-b-2 border-blue-700'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <UserPlus className="w-4 h-4" />
            <span>{lang === 'km' ? 'បង្កើតគណនីថ្មី' : 'Create Account'}</span>
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-lg flex items-start gap-2.5 text-xs text-red-800">
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {mode === 'signup' && (
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                {lang === 'km' ? 'ឈ្មោះគ្រូបង្រៀន / អ្នកគ្រប់គ្រង' : 'Full Name / Title'}
              </label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder={lang === 'km' ? 'ឧ. លោកគ្រូ សុខ ជា' : 'e.g. Sok Chea'}
                  className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-900 focus:bg-white focus:ring-2 focus:ring-blue-600 focus:outline-hidden"
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              {lang === 'km' ? 'អាសយដ្ឋានអ៊ីមែល (Email)' : 'Email Address'}
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="teacher@school.edu.kh"
                className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-900 focus:bg-white focus:ring-2 focus:ring-blue-600 focus:outline-hidden"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              {lang === 'km' ? 'ពាក្យសម្ងាត់ (Password)' : 'Password'}
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="password"
                required
                minLength={6}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-900 focus:bg-white focus:ring-2 focus:ring-blue-600 focus:outline-hidden"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-2.5 bg-blue-700 hover:bg-blue-800 disabled:opacity-50 text-white font-semibold rounded-lg text-sm transition-colors shadow-xs flex items-center justify-center gap-2 cursor-pointer"
          >
            {loading ? (
              <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
            ) : mode === 'login' ? (
              <>
                <LogIn className="w-4 h-4" />
                <span>{lang === 'km' ? 'ចូលប្រព័ន្ធ' : 'Sign In'}</span>
              </>
            ) : (
              <>
                <UserPlus className="w-4 h-4" />
                <span>{lang === 'km' ? 'ចុះឈ្មោះ និងបង្កើតគណនី' : 'Register Account'}</span>
              </>
            )}
          </button>

          <div className="relative my-3">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-slate-200"></div>
            </div>
            <div className="relative flex justify-center text-xs">
              <span className="bg-white px-2 text-slate-500 font-medium">
                {lang === 'km' ? 'ឬចូលប្រើរហ័ស' : 'Or quick access'}
              </span>
            </div>
          </div>

          <button
            type="button"
            onClick={handleAnonymousLogin}
            disabled={loading}
            className="w-full py-2 border border-slate-300 hover:bg-slate-50 text-slate-700 font-medium rounded-lg text-xs transition-colors flex items-center justify-center gap-2 cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            <span>{lang === 'km' ? 'ចូលប្រើសាកល្បងភ្លាមៗ (Guest / Demo)' : 'Sign In as Guest (Demo)'}</span>
          </button>
        </form>

        {/* Footer info */}
        <div className="p-3 bg-slate-50 border-t border-slate-200 text-center text-[11px] text-slate-500">
          {lang === 'km'
            ? 'ទិន្នន័យសិស្សត្រូវបានការពារដោយសុវត្ថិភាពលើ Google Cloud Firestore'
            : 'Protected and securely synchronized with Google Cloud Firestore'}
        </div>
      </div>
    </div>
  );
};
