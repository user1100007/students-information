import React, { useState, useEffect } from 'react';
import {
  X,
  Printer,
  FileSpreadsheet,
  Users,
  HeartHandshake,
  Heart,
  Eye,
  CheckCircle2,
  FileText,
  ShieldAlert,
} from 'lucide-react';
import { StudentRecord, Language } from '../types/student';
import { calculateBMI, exportToExcel } from '../utils/exportImport';

export type ReportType =
  | 'attendance_roster' // បញ្ជីហៅឈ្មោះសិស្ស
  | 'scholarship_students' // បញ្ជីឈ្មោះសិស្សអាហារូបករណ៍
  | 'disabled_students' // បញ្ជីឈ្មោះសិស្សមានពិការភាព
  | 'orphan_students' // បញ្ជីឈ្មោះសិស្សកំព្រា
  | 'bmi_students' // បញ្ជីឈ្មោះសិស្សមានទិន្នន័យ BMI
  | 'eye_ear_test' // បញ្ជីសិស្សតេស្តភ្នែក និងត្រចៀក
  | 'minority_students' // សិស្សជាជនជាតិដើមភាគតិច
  | 'student_absence'; // បញ្ជីអវត្តមានសិស្ស

interface ReportModalProps {
  isOpen: boolean;
  initialReportType?: ReportType;
  students: StudentRecord[];
  lang: Language;
  onClose: () => void;
}

export const ReportModal: React.FC<ReportModalProps> = ({
  isOpen,
  initialReportType = 'attendance_roster',
  students,
  lang,
  onClose,
}) => {
  const [activeReport, setActiveReport] = useState<ReportType>(initialReportType);

  useEffect(() => {
    if (initialReportType) {
      setActiveReport(initialReportType);
    }
  }, [initialReportType, isOpen]);

  if (!isOpen) return null;

  // Filter students based on report type
  const reportStudents = students.filter((s) => {
    switch (activeReport) {
      case 'scholarship_students':
        return s.equityFamily.includes('ក្រ') || s.equityFamily.includes('ផ្សេងៗ') || s.equityCard.trim() !== '';
      case 'disabled_students':
        return s.disabilityType.trim() !== '' && !s.disabilityType.includes('គ្មាន');
      case 'orphan_students':
        return s.orphanStatus && s.orphanStatus.trim() !== '' && !s.orphanStatus.includes('មិនកំព្រា');
      case 'bmi_students':
        return (s.weightSem1 && s.heightSem1) || (s.weightSem2 && s.heightSem2);
      case 'eye_ear_test':
        return s.eyeLeft.trim() !== '' || s.earLeft.trim() !== '';
      case 'minority_students':
        return s.ethnicMinority.trim() !== '' && !s.ethnicMinority.includes('គ្មាន');
      default:
        return true; // attendance roster shows all
    }
  });

  const total = reportStudents.length;
  const femaleCount = reportStudents.filter(
    (s) => s.gender === 'ស្រី' || s.gender.toLowerCase() === 'female' || s.gender === 'f'
  ).length;

  const handlePrint = () => {
    window.print();
  };

  const handleExport = () => {
    exportToExcel(reportStudents, lang, `${activeReport}_report.xlsx`);
  };

  const getReportTitle = () => {
    switch (activeReport) {
      case 'attendance_roster':
        return lang === 'km' ? 'បញ្ជីហៅឈ្មោះសិស្ស' : 'Student Attendance / Call Roster';
      case 'scholarship_students':
        return lang === 'km' ? 'បញ្ជីឈ្មោះសិស្សអាហារូបករណ៍ (សមធម៌ & ក្រីក្រ)' : 'Scholarship & Equity Students List';
      case 'disabled_students':
        return lang === 'km' ? 'បញ្ជីឈ្មោះសិស្សមានពិការភាព' : 'Students with Disabilities List';
      case 'orphan_students':
        return lang === 'km' ? 'បញ្ជីឈ្មោះសិស្សកំព្រា (ឪពុក/ម្ដាយ/ឪពុកម្ដាយ)' : 'Orphaned Students List';
      case 'bmi_students':
        return lang === 'km' ? 'បញ្ជីឈ្មោះសិស្សមានទិន្នន័យ BMI (អាហារូបត្ថម្ភ)' : 'Students with BMI Data List';
      case 'eye_ear_test':
        return lang === 'km' ? 'បញ្ជីសិស្សតេស្តភ្នែក និងត្រចៀក' : 'Vision & Hearing Screened Students List';
      case 'minority_students':
        return lang === 'km' ? 'បញ្ជីសិស្សជាជនជាតិដើមភាគតិច' : 'Indigenous & Minority Students List';
      case 'student_absence':
        return lang === 'km' ? 'បញ្ជីអវត្តមានសិស្ស' : 'Student Absence Roster';
      default:
        return lang === 'km' ? 'របាយការណ៍សិស្ស' : 'Student Report';
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-5xl max-h-[94vh] flex flex-col overflow-hidden border border-slate-300">
        {/* Top Header Controls (No-print) */}
        <div className="p-3 border-b border-slate-200 bg-slate-50 flex items-center justify-between no-print gap-2">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-blue-700 text-white flex items-center justify-center font-bold">
              <FileText className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900 leading-tight">
                {lang === 'km' ? 'ផ្ទាំងរបាយការណ៍សាលារៀន (MoEYS Reports)' : 'School Report System'}
              </h2>
              <p className="text-[11px] text-slate-500">
                {lang === 'km' ? 'ទម្រង់របាយការណ៍ស្របតាមស្ដង់ដារក្រសួង' : 'Official MoEYS standardized report'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>{lang === 'km' ? 'បោះពុម្ព' : 'Print'}</span>
            </button>
            <button
              onClick={handleExport}
              className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-emerald-800 bg-emerald-100 hover:bg-emerald-200 border border-emerald-300 rounded-lg transition-colors cursor-pointer"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>{lang === 'km' ? 'ទាញយក Excel' : 'Export Excel'}</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 rounded-lg transition-colors cursor-pointer ml-1"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Report Switcher Tabs matching IMG_4049.jpeg (No-print) */}
        <div className="flex items-center overflow-x-auto gap-1 p-2 bg-slate-100 border-b border-slate-200 text-xs no-print custom-scrollbar">
          <button
            onClick={() => setActiveReport('attendance_roster')}
            className={`px-2.5 py-1 rounded-md font-medium whitespace-nowrap transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeReport === 'attendance_roster'
                ? 'bg-blue-700 text-white font-semibold'
                : 'bg-white text-slate-700 hover:bg-slate-200'
            }`}
          >
            <Users className="w-3 h-3" />
            <span>{lang === 'km' ? 'បញ្ជីហៅឈ្មោះសិស្ស' : 'Call Roster'}</span>
          </button>

          <button
            onClick={() => setActiveReport('scholarship_students')}
            className={`px-2.5 py-1 rounded-md font-medium whitespace-nowrap transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeReport === 'scholarship_students'
                ? 'bg-amber-600 text-white font-semibold'
                : 'bg-white text-slate-700 hover:bg-slate-200'
            }`}
          >
            <HeartHandshake className="w-3 h-3" />
            <span>{lang === 'km' ? 'បញ្ជីឈ្មោះសិស្សអាហារូបករណ៍' : 'Scholarship'}</span>
          </button>

          <button
            onClick={() => setActiveReport('disabled_students')}
            className={`px-2.5 py-1 rounded-md font-medium whitespace-nowrap transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeReport === 'disabled_students'
                ? 'bg-purple-700 text-white font-semibold'
                : 'bg-white text-slate-700 hover:bg-slate-200'
            }`}
          >
            <span>♿</span>
            <span>{lang === 'km' ? 'បញ្ជីឈ្មោះសិស្សមានពិការភាព' : 'Disabilities'}</span>
          </button>

          <button
            onClick={() => setActiveReport('orphan_students')}
            className={`px-2.5 py-1 rounded-md font-medium whitespace-nowrap transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeReport === 'orphan_students'
                ? 'bg-orange-700 text-white font-semibold'
                : 'bg-white text-slate-700 hover:bg-slate-200'
            }`}
          >
            <ShieldAlert className="w-3 h-3" />
            <span>{lang === 'km' ? 'បញ្ជីឈ្មោះសិស្សកំព្រា' : 'Orphan Students'}</span>
          </button>

          <button
            onClick={() => setActiveReport('bmi_students')}
            className={`px-2.5 py-1 rounded-md font-medium whitespace-nowrap transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeReport === 'bmi_students'
                ? 'bg-rose-600 text-white font-semibold'
                : 'bg-white text-slate-700 hover:bg-slate-200'
            }`}
          >
            <Heart className="w-3 h-3" />
            <span>{lang === 'km' ? 'បញ្ជីឈ្មោះសិស្សមានទិន្នន័យ BMI' : 'BMI Nutrition'}</span>
          </button>

          <button
            onClick={() => setActiveReport('eye_ear_test')}
            className={`px-2.5 py-1 rounded-md font-medium whitespace-nowrap transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeReport === 'eye_ear_test'
                ? 'bg-teal-700 text-white font-semibold'
                : 'bg-white text-slate-700 hover:bg-slate-200'
            }`}
          >
            <Eye className="w-3 h-3" />
            <span>{lang === 'km' ? 'បញ្ជីសិស្សតេស្តភ្នែក និងត្រចៀក' : 'Vision & Hearing'}</span>
          </button>
        </div>

        {/* Printable Official Document Body */}
        <div className="p-6 sm:p-8 overflow-y-auto space-y-4 font-sans print:p-0">
          {/* Official MoEYS Header */}
          <div className="text-center space-y-1">
            <h1 className="text-sm sm:text-base font-bold text-slate-900 tracking-wide">ព្រះរាជាណាចក្រកម្ពុជា</h1>
            <h2 className="text-xs sm:text-sm font-semibold text-slate-800 tracking-wider">ជាតិ សាសនា ព្រះមហាក្សត្រ</h2>
            <div className="w-16 h-0.5 bg-slate-400 mx-auto my-1"></div>
            <div className="text-xs text-slate-600">ក្រសួងអប់រំ យុវជន និងកីឡា · មន្ទីរអប់រំ យុវជន និងកីឡា</div>
            <div className="text-xs text-slate-600 font-medium">សាលាបឋមសិក្សា / អនុវិទ្យាល័យ · ឆ្នាំសិក្សា ២០២៥-២០២៦</div>
            <h3 className="text-base sm:text-lg font-bold text-blue-950 uppercase pt-2 tracking-wide">
              {getReportTitle()}
            </h3>
          </div>

          {/* Quick Metrics Bar on top of table */}
          <div className="flex items-center justify-between text-xs text-slate-700 border-b border-slate-300 pb-2">
            <div>
              <span>{lang === 'km' ? 'សិស្សក្នុងរបាយការណ៍សរុប៖' : 'Total Students in Report:'} </span>
              <strong className="font-mono text-sm text-slate-900 tabular-nums">{total}</strong>{' '}
              <span>{lang === 'km' ? 'នាក់' : 'students'}</span>
              <span className="mx-2">·</span>
              <span className="text-pink-700 font-semibold">{lang === 'km' ? 'ស្រី៖' : 'Female:'} </span>
              <strong className="font-mono text-sm text-pink-700 tabular-nums">{femaleCount}</strong>{' '}
              <span>{lang === 'km' ? 'នាក់' : 'female'}</span>
            </div>
            <div className="text-slate-500 text-[11px] font-mono">
              {new Date().toLocaleDateString('km-KH')}
            </div>
          </div>

          {/* Main Printable Table */}
          <div className="overflow-x-auto border border-slate-500 rounded">
            <table className="min-w-full text-xs border-collapse sis-compact-table">
              <thead className="bg-slate-200 text-slate-900 font-bold border-b-2 border-slate-700">
                <tr>
                  <th className="border border-slate-500 p-1.5 w-10 text-center font-mono">#</th>
                  <th className="border border-slate-500 p-1.5 w-16 text-center font-mono">{lang === 'km' ? 'អត្តលេខ' : 'ID'}</th>
                  <th className="border border-slate-500 p-1.5 text-left min-w-[120px]">{lang === 'km' ? 'គោត្តនាម នាម' : 'Full Name'}</th>
                  <th className="border border-slate-500 p-1.5 w-14 text-center">{lang === 'km' ? 'ភេទ' : 'Gender'}</th>
                  <th className="border border-slate-500 p-1.5 w-24 text-center font-mono">{lang === 'km' ? 'ថ្ងៃខែកំណើត' : 'DOB'}</th>
                  <th className="border border-slate-500 p-1.5 w-16 text-center">{lang === 'km' ? 'ថ្នាក់' : 'Grade'}</th>

                  {/* Report-specific columns */}
                  {activeReport === 'attendance_roster' && (
                    <>
                      <th className="border border-slate-500 p-1.5 text-left">{lang === 'km' ? 'ទីកន្លែងកំណើត / អាសយដ្ឋាន' : 'Address'}</th>
                      <th className="border border-slate-500 p-1.5 text-left">{lang === 'km' ? 'ឪពុក / ម្ដាយ' : 'Parents'}</th>
                      <th className="border border-slate-500 p-1.5 text-center">{lang === 'km' ? 'ទូរស័ព្ទ' : 'Phone'}</th>
                    </>
                  )}

                  {activeReport === 'scholarship_students' && (
                    <>
                      <th className="border border-slate-500 p-1.5 text-center">{lang === 'km' ? 'កម្រិតក្រីក្រ' : 'Equity Level'}</th>
                      <th className="border border-slate-500 p-1.5 text-center font-mono">{lang === 'km' ? 'លេខបណ្ណសមធម៌' : 'Card ID'}</th>
                      <th className="border border-slate-500 p-1.5 text-left">{lang === 'km' ? 'អាណាព្យាបាល / មុខរបរ' : 'Guardian'}</th>
                      <th className="border border-slate-500 p-1.5 text-center">{lang === 'km' ? 'ស្ថានភាពកំព្រា' : 'Orphan'}</th>
                    </>
                  )}

                  {activeReport === 'disabled_students' && (
                    <>
                      <th className="border border-slate-500 p-1.5 text-center">{lang === 'km' ? 'ប្រភេទពិការភាព' : 'Disability'}</th>
                      <th className="border border-slate-500 p-1.5 text-left">{lang === 'km' ? 'លក្ខណៈពិសេស / តម្រូវការ' : 'Needs'}</th>
                      <th className="border border-slate-500 p-1.5 text-left">{lang === 'km' ? 'អាណាព្យាបាល & អាសយដ្ឋាន' : 'Guardian Address'}</th>
                    </>
                  )}

                  {activeReport === 'orphan_students' && (
                    <>
                      <th className="border border-slate-500 p-1.5 text-center">{lang === 'km' ? 'ស្ថានភាពកំព្រា' : 'Orphan Status'}</th>
                      <th className="border border-slate-500 p-1.5 text-left">{lang === 'km' ? 'អាណាព្យាបាល / ទំនាក់ទំនង' : 'Guardian Contact'}</th>
                      <th className="border border-slate-500 p-1.5 text-left">{lang === 'km' ? 'អាសយដ្ឋានបច្ចុប្បន្ន' : 'Address'}</th>
                    </>
                  )}

                  {activeReport === 'bmi_students' && (
                    <>
                      <th className="border border-slate-500 p-1.5 text-right font-mono">{lang === 'km' ? 'ទម្ងន់ ឆមាស១' : 'W Sem 1'}</th>
                      <th className="border border-slate-500 p-1.5 text-right font-mono">{lang === 'km' ? 'កម្ពស់ ឆមាស១' : 'H Sem 1'}</th>
                      <th className="border border-slate-500 p-1.5 text-center">{lang === 'km' ? 'BMI ឆមាស១' : 'BMI Sem 1'}</th>
                      <th className="border border-slate-500 p-1.5 text-right font-mono">{lang === 'km' ? 'ទម្ងន់ ឆមាស២' : 'W Sem 2'}</th>
                      <th className="border border-slate-500 p-1.5 text-right font-mono">{lang === 'km' ? 'កម្ពស់ ឆមាស២' : 'H Sem 2'}</th>
                      <th className="border border-slate-500 p-1.5 text-center">{lang === 'km' ? 'BMI ឆមាស២' : 'BMI Sem 2'}</th>
                    </>
                  )}

                  {activeReport === 'eye_ear_test' && (
                    <>
                      <th className="border border-slate-500 p-1.5 text-center font-mono">{lang === 'km' ? 'ភ្នែក (ឆ្វេង/ស្ដាំ)' : 'Vision'}</th>
                      <th className="border border-slate-500 p-1.5 text-center">{lang === 'km' ? 'លទ្ធផលភ្នែក' : 'Vision Result'}</th>
                      <th className="border border-slate-500 p-1.5 text-center font-mono">{lang === 'km' ? 'ត្រចៀក (ឆ្វេង/ស្ដាំ)' : 'Hearing'}</th>
                      <th className="border border-slate-500 p-1.5 text-center">{lang === 'km' ? 'លទ្ធផលត្រចៀក' : 'Hearing Result'}</th>
                      <th className="border border-slate-500 p-1.5 text-center">{lang === 'km' ? 'វ៉ាក់សាំង' : 'Vaccines'}</th>
                    </>
                  )}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-400">
                {reportStudents.length === 0 ? (
                  <tr>
                    <td colSpan={10} className="p-6 text-center text-slate-500">
                      {lang === 'km' ? 'គ្មានទិន្នន័យសិស្សសម្រាប់របាយការណ៍នេះទេ' : 'No students found for this report'}
                    </td>
                  </tr>
                ) : (
                  reportStudents.map((s, idx) => {
                    const isFemale = s.gender === 'ស្រី' || s.gender.toLowerCase() === 'female' || s.gender === 'f';
                    const bmi1 = calculateBMI(s.weightSem1, s.heightSem1);
                    const bmi2 = calculateBMI(s.weightSem2, s.heightSem2);

                    return (
                      <tr key={s.id} className={idx % 2 === 1 ? 'bg-slate-50' : 'bg-white'}>
                        <td className="border border-slate-400 p-1.5 text-center font-mono text-slate-500">{idx + 1}</td>
                        <td className="border border-slate-400 p-1.5 text-center font-mono font-bold text-slate-900">{s.studentCode || '—'}</td>
                        <td className="border border-slate-400 p-1.5 text-left font-bold text-slate-900">{s.lastName} {s.firstName}</td>
                        <td className={`border border-slate-400 p-1.5 text-center font-semibold ${isFemale ? 'text-pink-700' : 'text-blue-700'}`}>
                          {s.gender}
                        </td>
                        <td className="border border-slate-400 p-1.5 text-center font-mono text-slate-700">{s.dob || '—'}</td>
                        <td className="border border-slate-400 p-1.5 text-center font-semibold text-slate-800">{s.previousGrade || '—'}</td>

                        {activeReport === 'attendance_roster' && (
                          <>
                            <td className="border border-slate-400 p-1.5 text-left text-slate-700">
                              {s.curVillage ? `ភូមិ${s.curVillage} ឃុំ${s.curCommune} ស្រុក${s.curDistrict} ខេត្ត${s.curProvince}` : '—'}
                            </td>
                            <td className="border border-slate-400 p-1.5 text-left text-slate-700">
                              {s.fatherLastName ? `ឳ: ${s.fatherLastName} ${s.fatherFirstName}` : ''}
                              {s.motherLastName ? ` · ម្ត: ${s.motherLastName} ${s.motherFirstName}` : ''}
                            </td>
                            <td className="border border-slate-400 p-1.5 text-center font-mono text-slate-700">{s.phone || s.guardianPhone || '—'}</td>
                          </>
                        )}

                        {activeReport === 'scholarship_students' && (
                          <>
                            <td className="border border-slate-400 p-1.5 text-center font-bold text-amber-800">{s.equityFamily || '—'}</td>
                            <td className="border border-slate-400 p-1.5 text-center font-mono text-slate-700">{s.equityCard || '—'}</td>
                            <td className="border border-slate-400 p-1.5 text-left text-slate-700">
                              {s.guardianLastName ? `${s.guardianLastName} ${s.guardianFirstName} (${s.guardianType || 'អាណាព្យាបាល'})` : '—'}
                            </td>
                            <td className="border border-slate-400 p-1.5 text-center font-medium text-slate-700">{s.orphanStatus || 'មិនកំព្រា'}</td>
                          </>
                        )}

                        {activeReport === 'disabled_students' && (
                          <>
                            <td className="border border-slate-400 p-1.5 text-center font-bold text-purple-800">{s.disabilityType || '—'}</td>
                            <td className="border border-slate-400 p-1.5 text-left text-slate-700">{s.specialTrait || s.eyeDevice || '—'}</td>
                            <td className="border border-slate-400 p-1.5 text-left text-slate-700">{s.guardianAddress || s.curVillage || '—'}</td>
                          </>
                        )}

                        {activeReport === 'orphan_students' && (
                          <>
                            <td className="border border-slate-400 p-1.5 text-center font-bold text-orange-800">{s.orphanStatus || '—'}</td>
                            <td className="border border-slate-400 p-1.5 text-left text-slate-700">
                              {s.guardianLastName ? `${s.guardianLastName} ${s.guardianFirstName} (${s.guardianType || 'អាណាព្យាបាល'})` : '—'}
                              {s.guardianPhone || s.phone ? ` · ${s.guardianPhone || s.phone}` : ''}
                            </td>
                            <td className="border border-slate-400 p-1.5 text-left text-slate-700">
                              {s.guardianAddress || (s.curVillage ? `ភូមិ${s.curVillage} ឃុំ${s.curCommune} ស្រុក${s.curDistrict} ខេត្ត${s.curProvince}` : '—')}
                            </td>
                          </>
                        )}

                        {activeReport === 'bmi_students' && (
                          <>
                            <td className="border border-slate-400 p-1.5 text-right font-mono">{s.weightSem1 ? `${s.weightSem1} kg` : '—'}</td>
                            <td className="border border-slate-400 p-1.5 text-right font-mono">{s.heightSem1 ? `${s.heightSem1} cm` : '—'}</td>
                            <td className="border border-slate-400 p-1.5 text-center font-medium">
                              {bmi1.bmi ? `${bmi1.bmi} (${bmi1.labelKm})` : '—'}
                            </td>
                            <td className="border border-slate-400 p-1.5 text-right font-mono">{s.weightSem2 ? `${s.weightSem2} kg` : '—'}</td>
                            <td className="border border-slate-400 p-1.5 text-right font-mono">{s.heightSem2 ? `${s.heightSem2} cm` : '—'}</td>
                            <td className="border border-slate-400 p-1.5 text-center font-medium">
                              {bmi2.bmi ? `${bmi2.bmi} (${bmi2.labelKm})` : '—'}
                            </td>
                          </>
                        )}

                        {activeReport === 'eye_ear_test' && (
                          <>
                            <td className="border border-slate-400 p-1.5 text-center font-mono">{s.eyeLeft || '—'} / {s.eyeRight || '—'}</td>
                            <td className="border border-slate-400 p-1.5 text-center font-medium text-slate-700">{s.eyeResult || '—'}</td>
                            <td className="border border-slate-400 p-1.5 text-center font-mono">{s.earLeft || '—'} / {s.earRight || '—'}</td>
                            <td className="border border-slate-400 p-1.5 text-center font-medium text-slate-700">{s.earResult || '—'}</td>
                            <td className="border border-slate-400 p-1.5 text-center text-slate-700">{s.vaccineList || '—'}</td>
                          </>
                        )}
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>

          {/* Official MoEYS Approval Sign-Off Block */}
          <div className="pt-6 grid grid-cols-2 text-center text-xs text-slate-800">
            <div>
              <div className="font-semibold">{lang === 'km' ? 'បានឃើញ និងឯកភាព' : 'Approved by'}</div>
              <div className="font-bold text-slate-900 mt-1">{lang === 'km' ? 'នាយកសាលា' : 'School Principal'}</div>
              <div className="h-16"></div>
              <div className="text-slate-500">{lang === 'km' ? '(ហត្ថលេខា និងត្រា)' : '(Signature & Stamp)'}</div>
            </div>
            <div>
              <div>{lang === 'km' ? 'ថ្ងៃទី...... ខែ...... ឆ្នាំ២០២៦' : 'Date: ...... / ...... / 2026'}</div>
              <div className="font-bold text-slate-900 mt-1">{lang === 'km' ? 'គ្រូបន្ទុកថ្នាក់' : 'Class Teacher'}</div>
              <div className="h-16"></div>
              <div className="text-slate-500">{lang === 'km' ? '(ហត្ថលេខា និងឈ្មោះ)' : '(Signature & Name)'}</div>
            </div>
          </div>
        </div>

        {/* Modal Footer (No-print) */}
        <div className="p-3 border-t border-slate-200 bg-slate-50 flex items-center justify-between no-print">
          <div className="text-xs text-slate-500">
            {lang === 'km' ? 'របាយការណ៍នេះអាចបោះពុម្ពជាក្រដាស A4 ឬទាញយកជា Excel បាន' : 'Ready for A4 paper print or Excel export'}
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-semibold text-slate-700 hover:text-slate-900 bg-white border border-slate-300 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
          >
            {lang === 'km' ? 'បិទ' : 'Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
