import React, { useState } from 'react';
import { Eye, Volume2, Heart, ShieldAlert, Sparkles, AlertTriangle } from 'lucide-react';
import { StudentRecord, Language } from '../types/student';
import { calculateBMI } from '../utils/exportImport';

interface HealthEquityViewProps {
  students: StudentRecord[];
  lang: Language;
  onViewStudent: (student: StudentRecord) => void;
  onEditStudent: (student: StudentRecord) => void;
}

export const HealthEquityView: React.FC<HealthEquityViewProps> = ({
  students,
  lang,
  onViewStudent,
  onEditStudent,
}) => {
  const [filterType, setFilterType] = useState<'all' | 'vision_issue' | 'hearing_issue' | 'poor' | 'bmi_alert'>('all');

  const filteredStudents = students.filter((s) => {
    if (filterType === 'vision_issue') {
      return (
        (s.eyeLeft && s.eyeLeft !== '6/6') ||
        (s.eyeRight && s.eyeRight !== '6/6') ||
        s.eyeResult.includes('កម្រិត') ||
        s.eyePrescription.trim() !== ''
      );
    }
    if (filterType === 'hearing_issue') {
      return (
        s.earResult.includes('បញ្ហា') ||
        s.earPrescription.trim() !== '' ||
        s.earDevice.trim() !== ''
      );
    }
    if (filterType === 'poor') {
      return s.equityFamily.includes('ក្រ') || s.equityCard.trim() !== '';
    }
    if (filterType === 'bmi_alert') {
      const res = calculateBMI(s.weightSem1, s.heightSem1);
      return res.status === 'under' || res.status === 'over';
    }
    return true;
  });

  return (
    <div className="space-y-6">
      <div className="p-5 bg-white rounded-xl border border-slate-200/90 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-slate-900">
            {lang === 'km' ? 'តាមដានសុខភាព & សមធម៌សង្គម' : 'Health Screenings & Social Equity Tracking'}
          </h2>
          <p className="text-xs text-slate-500">
            {lang === 'km'
              ? 'ត្រួតពិនិត្យការលូតលាស់ សន្ទស្សន៍ BMI គំហើញភ្នែក សោតវិញ្ញាណ និងកុមារគ្រួសារក្រីក្រ'
              : 'Monitor growth, vision, hearing, and vulnerable students needing attention'}
          </p>
        </div>

        {/* Quick filter tabs */}
        <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg text-xs">
          <button
            onClick={() => setFilterType('all')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer ${
              filterType === 'all'
                ? 'bg-white text-slate-900 shadow-2xs font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {lang === 'km' ? 'ទាំងអស់' : 'All'}
          </button>
          <button
            onClick={() => setFilterType('vision_issue')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer ${
              filterType === 'vision_issue'
                ? 'bg-white text-blue-700 shadow-2xs font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {lang === 'km' ? 'ភ្នែកត្រូវតាមដាន' : 'Vision Attention'}
          </button>
          <button
            onClick={() => setFilterType('poor')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer ${
              filterType === 'poor'
                ? 'bg-white text-amber-700 shadow-2xs font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {lang === 'km' ? 'បណ្ណសមធម៌ក្រីក្រ' : 'Equity / IDPoor'}
          </button>
          <button
            onClick={() => setFilterType('bmi_alert')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer ${
              filterType === 'bmi_alert'
                ? 'bg-white text-red-700 shadow-2xs font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {lang === 'km' ? 'BMI មិនប្រក្រតី' : 'BMI Alerts'}
          </button>
        </div>
      </div>

      {/* Grid of Student Health Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredStudents.map((student) => {
          const bmi1 = calculateBMI(student.weightSem1, student.heightSem1);
          const hasVisionIssue =
            (student.eyeLeft && student.eyeLeft !== '6/6') ||
            (student.eyeRight && student.eyeRight !== '6/6') ||
            student.eyeResult.includes('កម្រិត');
          const isPoor = student.equityFamily.includes('ក្រ');

          return (
            <div
              key={student.id}
              className="p-4 bg-white rounded-xl border border-slate-200/90 shadow-2xs hover:border-blue-300 transition-colors"
            >
              <div className="flex items-center justify-between pb-2.5 mb-2.5 border-b border-slate-100">
                <div>
                  <button
                    onClick={() => onViewStudent(student)}
                    className="font-bold text-slate-900 hover:text-blue-700 text-sm hover:underline cursor-pointer"
                  >
                    {student.lastName} {student.firstName}
                  </button>
                  <div className="text-[11px] text-slate-400 font-mono">
                    ID: {student.studentCode} · {student.gender} · ថ្នាក់ {student.previousGrade || '—'}
                  </div>
                </div>

                <button
                  onClick={() => onEditStudent(student)}
                  className="px-2.5 py-1 text-xs text-blue-700 hover:bg-blue-50 border border-blue-200 rounded-md transition-colors cursor-pointer"
                >
                  {lang === 'km' ? 'កែប្រែ' : 'Update'}
                </button>
              </div>

              {/* Status Points */}
              <div className="space-y-2 text-xs">
                {/* Physical Growth & BMI */}
                <div className="flex items-center justify-between bg-slate-50 p-2 rounded-lg">
                  <span className="text-slate-500 flex items-center gap-1.5">
                    <Heart className="w-3.5 h-3.5 text-rose-500" />
                    <span>{lang === 'km' ? 'ទម្ងន់/កម្ពស់ (ឆមាស១)' : 'Growth (Sem 1)'}</span>
                  </span>
                  <span className="font-mono tabular-nums text-slate-800">
                    {student.weightSem1 || '—'}kg / {student.heightSem1 || '—'}cm
                  </span>
                </div>

                {/* BMI Status */}
                {bmi1.bmi && (
                  <div className="flex items-center justify-between px-2 text-[11px]">
                    <span className="text-slate-400">BMI:</span>
                    <span
                      className={`font-semibold ${
                        bmi1.status === 'normal'
                          ? 'text-emerald-700'
                          : bmi1.status === 'under'
                          ? 'text-blue-700'
                          : 'text-amber-700'
                      }`}
                    >
                      {bmi1.bmi} ({bmi1.labelKm})
                    </span>
                  </div>
                )}

                {/* Vision status */}
                <div className="flex items-center justify-between bg-slate-50 p-2 rounded-lg">
                  <span className="text-slate-500 flex items-center gap-1.5">
                    <Eye className="w-3.5 h-3.5 text-blue-500" />
                    <span>{lang === 'km' ? 'ភ្នែក (ឆ្វេង/ស្ដាំ)' : 'Vision'}</span>
                  </span>
                  <span className="font-mono text-slate-800">
                    {student.eyeLeft || '—'} / {student.eyeRight || '—'}{' '}
                    {hasVisionIssue && <span className="text-amber-600 font-bold ml-1">⚠</span>}
                  </span>
                </div>

                {/* Equity Status */}
                <div className="flex items-center justify-between px-2 text-[11px]">
                  <span className="text-slate-400">{lang === 'km' ? 'សមធម៌/ក្រីក្រ៖' : 'Equity:'}</span>
                  <span className={`font-semibold ${isPoor ? 'text-amber-700' : 'text-slate-600'}`}>
                    {student.equityFamily || 'មិនក្រីក្រ'}
                    {student.equityCard && ` (${student.equityCard})`}
                  </span>
                </div>

                {/* Vaccines */}
                <div className="flex items-center justify-between px-2 text-[11px]">
                  <span className="text-slate-400">{lang === 'km' ? 'វ៉ាក់សាំង៖' : 'Vaccines:'}</span>
                  <span className="text-slate-700 truncate max-w-44">{student.vaccineList || '—'}</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
