import React from 'react';
import { Users, HeartHandshake, Eye, Heart, ShieldAlert, ChevronRight, FileSpreadsheet } from 'lucide-react';
import { StudentRecord, Language } from '../types/student';
import { ReportType } from './ReportModal';

interface StatsOverviewProps {
  students: StudentRecord[];
  lang: Language;
  onOpenReport: (reportType: ReportType) => void;
}

export const StatsOverview: React.FC<StatsOverviewProps> = ({ students, lang, onOpenReport }) => {
  const total = students.length;
  const femaleCount = students.filter(
    (s) => s.gender === 'ស្រី' || s.gender.toLowerCase() === 'female' || s.gender === 'f'
  ).length;

  // 1. Scholarship / Equity / Poor students (ក្រ១, ក្រ២, ផ្សេងៗ)
  const scholarshipStudents = students.filter(
    (s) => s.equityFamily.includes('ក្រ') || s.equityFamily.includes('ផ្សេងៗ') || s.equityCard.trim() !== ''
  );
  const scholarshipTotal = scholarshipStudents.length;
  const scholarshipFemale = scholarshipStudents.filter(
    (s) => s.gender === 'ស្រី' || s.gender.toLowerCase() === 'female' || s.gender === 'f'
  ).length;

  // 2. Disabled students (ពិបាកនិយាយ, ពិបាកមើល, etc.)
  const disabledStudents = students.filter(
    (s) => s.disabilityType && s.disabilityType.trim() !== '' && !s.disabilityType.includes('គ្មាន')
  );
  const disabledTotal = disabledStudents.length;
  const disabledFemale = disabledStudents.filter(
    (s) => s.gender === 'ស្រី' || s.gender.toLowerCase() === 'female' || s.gender === 'f'
  ).length;

  // 3. Orphan students (កំព្រាឪពុក, កំព្រាម្ដាយ, កំព្រាឪពុកម្ដាយ)
  const orphanStudents = students.filter(
    (s) => s.orphanStatus && s.orphanStatus.trim() !== '' && !s.orphanStatus.includes('មិនកំព្រា')
  );
  const orphanTotal = orphanStudents.length;
  const orphanFemale = orphanStudents.filter(
    (s) => s.gender === 'ស្រី' || s.gender.toLowerCase() === 'female' || s.gender === 'f'
  ).length;

  // 4. Health & Nutrition (BMI / Screenings)
  const healthStudents = students.filter(
    (s) => (s.weightSem1 && s.heightSem1) || (s.weightSem2 && s.heightSem2) || s.eyeLeft.trim() !== '' || s.earLeft.trim() !== ''
  );
  const healthTotal = healthStudents.length;
  const healthFemale = healthStudents.filter(
    (s) => s.gender === 'ស្រី' || s.gender.toLowerCase() === 'female' || s.gender === 'f'
  ).length;

  return (
    <div className="my-2 no-print">
      <div className="flex items-center justify-between mb-1.5 px-0.5">
        <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-blue-600 inline-block"></span>
          <span>{lang === 'km' ? 'ផ្ទាំងរបាយការណ៍ទិន្នន័យសាលារៀន (ចុចលើប៊ូតុងខាងក្រោមដើម្បីបើករបាយការណ៍នីមួយៗ)' : 'School Report Buttons (Click to open each report)'}</span>
        </span>
        <span className="text-[11px] text-slate-500 font-mono">
          {lang === 'km' ? '៥ ប្រភេទរបាយការណ៍ផ្លូវការ' : '5 Official Reports'}
        </span>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2">
        {/* 1. បញ្ជីហៅឈ្មោះសិស្ស (General Call Roster) */}
        <button
          type="button"
          onClick={() => onOpenReport('attendance_roster')}
          className="p-2 sm:p-2.5 bg-white hover:bg-blue-50/80 active:bg-blue-100 rounded-lg border-2 border-blue-500 hover:border-blue-700 shadow-2xs hover:shadow-sm transition-all text-left cursor-pointer group flex flex-col justify-between"
          title="ចុចដើម្បីបើកផ្ទាំងរបាយការណ៍ បញ្ជីហៅឈ្មោះសិស្ស"
        >
          <div>
            <div className="flex items-center justify-between text-blue-900 mb-0.5">
              <span className="text-[11px] font-bold truncate">
                {lang === 'km' ? '១. បញ្ជីហៅឈ្មោះសិស្ស' : '1. Call Roster'}
              </span>
              <Users className="w-3.5 h-3.5 text-blue-700 group-hover:scale-110 transition-transform shrink-0" />
            </div>
            <div className="text-lg sm:text-xl font-bold text-slate-900 font-mono tabular-nums leading-tight">
              {total}{' '}
              <span className="text-xs font-normal text-slate-600">{lang === 'km' ? 'នាក់' : 'std'}</span>
            </div>
          </div>
          <div className="pt-1 border-t border-slate-100 mt-1 flex items-center justify-between text-[10px] text-pink-700 font-medium">
            <span>{lang === 'km' ? `ស្រី ${femaleCount} នាក់` : `Female ${femaleCount}`}</span>
            <span className="inline-flex items-center text-blue-700 font-bold group-hover:translate-x-0.5 transition-transform text-[10px]">
              {lang === 'km' ? 'បើករបាយការណ៍ ↗' : 'Open ↗'}
            </span>
          </div>
        </button>

        {/* 2. បញ្ជីឈ្មោះសិស្សអាហារូបករណ៍ / សមធម៌ក្រីក្រ */}
        <button
          type="button"
          onClick={() => onOpenReport('scholarship_students')}
          className="p-2 sm:p-2.5 bg-white hover:bg-amber-50/80 active:bg-amber-100 rounded-lg border-2 border-amber-500 hover:border-amber-700 shadow-2xs hover:shadow-sm transition-all text-left cursor-pointer group flex flex-col justify-between"
          title="ចុចដើម្បីបើកផ្ទាំងរបាយការណ៍ បញ្ជីឈ្មោះសិស្សអាហារូបករណ៍ និងគ្រួសារក្រីក្រ"
        >
          <div>
            <div className="flex items-center justify-between text-amber-900 mb-0.5">
              <span className="text-[11px] font-bold truncate">
                {lang === 'km' ? '២. អាហារូបករណ៍ / ក្រីក្រ' : '2. Scholarship / Poor'}
              </span>
              <HeartHandshake className="w-3.5 h-3.5 text-amber-700 group-hover:scale-110 transition-transform shrink-0" />
            </div>
            <div className="text-lg sm:text-xl font-bold text-slate-900 font-mono tabular-nums leading-tight">
              {scholarshipTotal}{' '}
              <span className="text-xs font-normal text-slate-600">{lang === 'km' ? 'នាក់' : 'std'}</span>
            </div>
          </div>
          <div className="pt-1 border-t border-slate-100 mt-1 flex items-center justify-between text-[10px] text-amber-900 font-medium">
            <span>{lang === 'km' ? `ស្រី ${scholarshipFemale} (ក្រ១, ក្រ២)` : `Female ${scholarshipFemale}`}</span>
            <span className="inline-flex items-center text-amber-800 font-bold group-hover:translate-x-0.5 transition-transform text-[10px]">
              {lang === 'km' ? 'បើករបាយការណ៍ ↗' : 'Open ↗'}
            </span>
          </div>
        </button>

        {/* 3. បញ្ជីឈ្មោះសិស្សមានពិការភាព */}
        <button
          type="button"
          onClick={() => onOpenReport('disabled_students')}
          className="p-2 sm:p-2.5 bg-white hover:bg-purple-50/80 active:bg-purple-100 rounded-lg border-2 border-purple-500 hover:border-purple-700 shadow-2xs hover:shadow-sm transition-all text-left cursor-pointer group flex flex-col justify-between"
          title="ចុចដើម្បីបើកផ្ទាំងរបាយការណ៍ បញ្ជីឈ្មោះសិស្សមានពិការភាព"
        >
          <div>
            <div className="flex items-center justify-between text-purple-900 mb-0.5">
              <span className="text-[11px] font-bold truncate">
                {lang === 'km' ? '៣. សិស្សមានពិការភាព' : '3. Disabilities'}
              </span>
              <span className="text-xs group-hover:scale-110 transition-transform shrink-0">♿</span>
            </div>
            <div className="text-lg sm:text-xl font-bold text-slate-900 font-mono tabular-nums leading-tight">
              {disabledTotal}{' '}
              <span className="text-xs font-normal text-slate-600">{lang === 'km' ? 'នាក់' : 'std'}</span>
            </div>
          </div>
          <div className="pt-1 border-t border-slate-100 mt-1 flex items-center justify-between text-[10px] text-purple-900 font-medium">
            <span>{lang === 'km' ? `ស្រី ${disabledFemale} (និយាយ/មើល)` : `Female ${disabledFemale}`}</span>
            <span className="inline-flex items-center text-purple-800 font-bold group-hover:translate-x-0.5 transition-transform text-[10px]">
              {lang === 'km' ? 'បើករបាយការណ៍ ↗' : 'Open ↗'}
            </span>
          </div>
        </button>

        {/* 4. បញ្ជីឈ្មោះសិស្សកំព្រា (Orphan Students) */}
        <button
          type="button"
          onClick={() => onOpenReport('orphan_students')}
          className="p-2 sm:p-2.5 bg-white hover:bg-orange-50/80 active:bg-orange-100 rounded-lg border-2 border-orange-500 hover:border-orange-700 shadow-2xs hover:shadow-sm transition-all text-left cursor-pointer group flex flex-col justify-between"
          title="ចុចដើម្បីបើកផ្ទាំងរបាយការណ៍ បញ្ជីឈ្មោះសិស្សកំព្រា"
        >
          <div>
            <div className="flex items-center justify-between text-orange-900 mb-0.5">
              <span className="text-[11px] font-bold truncate">
                {lang === 'km' ? '៤. បញ្ជីសិស្សកំព្រា' : '4. Orphan Students'}
              </span>
              <ShieldAlert className="w-3.5 h-3.5 text-orange-700 group-hover:scale-110 transition-transform shrink-0" />
            </div>
            <div className="text-lg sm:text-xl font-bold text-slate-900 font-mono tabular-nums leading-tight">
              {orphanTotal}{' '}
              <span className="text-xs font-normal text-slate-600">{lang === 'km' ? 'នាក់' : 'std'}</span>
            </div>
          </div>
          <div className="pt-1 border-t border-slate-100 mt-1 flex items-center justify-between text-[10px] text-orange-950 font-medium">
            <span>{lang === 'km' ? `ស្រី ${orphanFemale} (ឪពុក/ម្ដាយ/ទាំងពីរ)` : `Female ${orphanFemale}`}</span>
            <span className="inline-flex items-center text-orange-800 font-bold group-hover:translate-x-0.5 transition-transform text-[10px]">
              {lang === 'km' ? 'បើករបាយការណ៍ ↗' : 'Open ↗'}
            </span>
          </div>
        </button>

        {/* 5. ពិនិត្យសុខភាព & BMI (Health & Screenings) */}
        <button
          type="button"
          onClick={() => onOpenReport('bmi_students')}
          className="p-2 sm:p-2.5 bg-white hover:bg-emerald-50/80 active:bg-emerald-100 rounded-lg border-2 border-emerald-500 hover:border-emerald-700 shadow-2xs hover:shadow-sm transition-all text-left cursor-pointer group flex flex-col justify-between col-span-2 sm:col-span-1"
          title="ចុចដើម្បីបើកផ្ទាំងរបាយការណ៍ សុខភាពសិស្ស BMI និងគំហើញ/ការស្តាប់"
        >
          <div>
            <div className="flex items-center justify-between text-emerald-900 mb-0.5">
              <span className="text-[11px] font-bold truncate">
                {lang === 'km' ? '៥. សុខភាព & BMI' : '5. Health & BMI'}
              </span>
              <Heart className="w-3.5 h-3.5 text-emerald-700 group-hover:scale-110 transition-transform shrink-0" />
            </div>
            <div className="text-lg sm:text-xl font-bold text-slate-900 font-mono tabular-nums leading-tight">
              {healthTotal}{' '}
              <span className="text-xs font-normal text-slate-600">{lang === 'km' ? 'នាក់' : 'std'}</span>
            </div>
          </div>
          <div className="pt-1 border-t border-slate-100 mt-1 flex items-center justify-between text-[10px] text-emerald-950 font-medium">
            <span>{lang === 'km' ? `ស្រី ${healthFemale} នាក់ (កត់ត្រា BMI)` : `Female ${healthFemale}`}</span>
            <span className="inline-flex items-center text-emerald-800 font-bold group-hover:translate-x-0.5 transition-transform text-[10px]">
              {lang === 'km' ? 'បើករបាយការណ៍ ↗' : 'Open ↗'}
            </span>
          </div>
        </button>
      </div>
    </div>
  );
};
