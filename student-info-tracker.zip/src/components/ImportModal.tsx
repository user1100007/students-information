import React, { useState } from 'react';
import {
  X,
  Upload,
  FileSpreadsheet,
  Check,
  AlertCircle,
  Columns,
  Sparkles,
  ClipboardPaste,
  FileText,
  ArrowRight,
  Split,
} from 'lucide-react';
import { StudentRecord, Language } from '../types/student';
import {
  parseUploadedFile,
  readRawSpreadsheet,
  parsePastedTableText,
  transformExtractedRowsToStudents,
  RawExtractedSheet,
  ColumnTransformOptions,
} from '../utils/exportImport';

interface ImportModalProps {
  isOpen: boolean;
  lang: Language;
  onClose: () => void;
  onImport: (newStudents: StudentRecord[], mode: 'append' | 'replace') => void;
}

const SIS_TARGET_FIELDS: { key: keyof StudentRecord | 'fullName' | 'ignore'; labelKm: string; labelEn: string }[] = [
  { key: 'ignore', labelKm: '— មិនបញ្ចូល (Ignore) —', labelEn: '— Ignore column —' },
  { key: 'fullName', labelKm: 'ឈ្មោះពេញ (បំបែក គោត្តនាម+នាម)', labelEn: 'Full Name (Auto-split)' },
  { key: 'lastName', labelKm: 'គោត្តនាម (ត្រកូល)', labelEn: 'Last Name' },
  { key: 'firstName', labelKm: 'នាម (ឈ្មោះខ្លួន)', labelEn: 'First Name' },
  { key: 'gender', labelKm: 'ភេទ', labelEn: 'Gender' },
  { key: 'dob', labelKm: 'ថ្ងៃខែឆ្នាំកំណើត', labelEn: 'Date of Birth' },
  { key: 'studentCode', labelKm: 'អត្តលេខ / លេខកូដសិស្ស', labelEn: 'Student ID' },
  { key: 'previousGrade', labelKm: 'ថ្នាក់រៀន', labelEn: 'Grade' },
  { key: 'phone', labelKm: 'លេខទូរស័ព្ទ', labelEn: 'Phone' },
  { key: 'disabilityType', labelKm: 'ពិការភាព', labelEn: 'Disability Type' },
  { key: 'equityFamily', labelKm: 'គ្រួសារក្រីក្រ (ក្រ១/ក្រ២)', labelEn: 'IDPoor Family' },
  { key: 'equityCard', labelKm: 'បណ្ណសមធម៌', labelEn: 'Equity Card' },
  { key: 'orphanStatus', labelKm: 'សិស្សកំព្រា', labelEn: 'Orphan Status' },
  { key: 'pobProvince', labelKm: 'ទីកន្លែងកំណើត (ខេត្ត)', labelEn: 'POB Province' },
  { key: 'curVillage', labelKm: 'អាសយដ្ឋាន (ភូមិ)', labelEn: 'Current Village' },
  { key: 'curCommune', labelKm: 'អាសយដ្ឋាន (ឃុំ/សង្កាត់)', labelEn: 'Current Commune' },
  { key: 'weightSem1', labelKm: 'ទម្ងន់ ឆមាសទី១ (kg)', labelEn: 'Weight Sem 1' },
  { key: 'heightSem1', labelKm: 'កម្ពស់ ឆមាសទី១ (cm)', labelEn: 'Height Sem 1' },
  { key: 'weightSem2', labelKm: 'ទម្ងន់ ឆមាសទី២ (kg)', labelEn: 'Weight Sem 2' },
  { key: 'heightSem2', labelKm: 'កម្ពស់ ឆមាសទី២ (cm)', labelEn: 'Height Sem 2' },
  { key: 'eyeLeft', labelKm: 'គំហើញភ្នែកឆ្វេង', labelEn: 'Eye Left' },
  { key: 'eyeRight', labelKm: 'គំហើញភ្នែកស្ដាំ', labelEn: 'Eye Right' },
  { key: 'earLeft', labelKm: 'ការស្ដាប់ត្រចៀកឆ្វេង', labelEn: 'Ear Left' },
  { key: 'earRight', labelKm: 'ការស្ដាប់ត្រចៀកស្ដាំ', labelEn: 'Ear Right' },
  { key: 'otherNotes', labelKm: 'ផ្សេងៗ / ចំណាំ', labelEn: 'Notes' },
];

function guessFieldMapping(header: string): keyof StudentRecord | 'fullName' | 'ignore' {
  const h = header.toLowerCase().replace(/[\s\-_]/g, '');
  if (h.includes('ឈ្មោះពេញ') || h.includes('fullname') || h.includes('name') || h.includes('គោត្តនាម-នាម') || h.includes('ឈ្មោះសិស្ស')) {
    return 'fullName';
  }
  if (h.includes('គោត្តនាម') || h.includes('lastname') || h.includes('surname')) return 'lastName';
  if (h.includes('នាម') || h.includes('firstname')) return 'firstName';
  if (h.includes('ភេទ') || h.includes('gender') || h.includes('sex')) return 'gender';
  if (h.includes('កំណើត') || h.includes('dob') || h.includes('birth')) return 'dob';
  if (h.includes('អត្តលេខ') || h.includes('code') || h.includes('id') || h.includes('កូដ')) return 'studentCode';
  if (h.includes('ថ្នាក់') || h.includes('grade') || h.includes('class')) return 'previousGrade';
  if (h.includes('ទូរស័ព្ទ') || h.includes('phone') || h.includes('tel')) return 'phone';
  if (h.includes('ពិការ') || h.includes('disab')) return 'disabilityType';
  if (h.includes('ក្រ') || h.includes('poor') || h.includes('សមធម៌')) return 'equityFamily';
  if (h.includes('កំព្រា') || h.includes('orphan')) return 'orphanStatus';
  if (h.includes('ទម្ងន់') || h.includes('weight')) return 'weightSem1';
  if (h.includes('កម្ពស់') || h.includes('height')) return 'heightSem1';
  if (h.includes('ភ្នែក') || h.includes('eye')) return 'eyeLeft';
  if (h.includes('ត្រចៀក') || h.includes('ear')) return 'earLeft';
  return 'ignore';
}

export const ImportModal: React.FC<ImportModalProps> = ({
  isOpen,
  lang,
  onClose,
  onImport,
}) => {
  const [activeTab, setActiveTab] = useState<'smart' | 'standard'>('smart');
  const [file, setFile] = useState<File | null>(null);
  const [pasteText, setPasteText] = useState('');
  const [rawSheet, setRawSheet] = useState<RawExtractedSheet | null>(null);

  // Column Splitting & Mapping Configuration
  const [autoSplitFullName, setAutoSplitFullName] = useState(true);
  const [autoStandardizeGender, setAutoStandardizeGender] = useState(true);
  const [autoCalculateFields, setAutoCalculateFields] = useState(true);
  const [columnMap, setColumnMap] = useState<Record<string, keyof StudentRecord | 'fullName' | 'ignore'>>({});

  const [parsedData, setParsedData] = useState<StudentRecord[]>([]);
  const [importMode, setImportMode] = useState<'append' | 'replace'>('append');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const selected = e.target.files?.[0];
    if (!selected) return;
    setFile(selected);
    setErrorMsg(null);
    setLoading(true);

    try {
      if (activeTab === 'standard') {
        const records = await parseUploadedFile(selected);
        if (records.length === 0) {
          setErrorMsg(
            lang === 'km'
              ? 'មិនមានទិន្នន័យសិស្សត្រឹមត្រូវក្នុងឯកសារនេះទេ'
              : 'No valid student records found in file.'
          );
        } else {
          setParsedData(records);
        }
      } else {
        const sheet = await readRawSpreadsheet(selected);
        setRawSheet(sheet);
        // Build initial guessed map
        const initialMap: Record<string, keyof StudentRecord | 'fullName' | 'ignore'> = {};
        sheet.headers.forEach((h) => {
          initialMap[h] = guessFieldMapping(h);
        });
        setColumnMap(initialMap);

        // Preview transformed students
        const preview = transformExtractedRowsToStudents(sheet, {
          autoSplitFullName,
          autoStandardizeGender,
          autoCalculateFields,
          columnMap: initialMap,
        });
        setParsedData(preview);
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'កំហុសក្នុងការអានឯកសារ / Error parsing spreadsheet');
    } finally {
      setLoading(false);
    }
  };

  const handleApplyPaste = () => {
    if (!pasteText.trim()) return;
    try {
      setErrorMsg(null);
      const sheet = parsePastedTableText(pasteText);
      setRawSheet(sheet);
      const initialMap: Record<string, keyof StudentRecord | 'fullName' | 'ignore'> = {};
      sheet.headers.forEach((h) => {
        initialMap[h] = guessFieldMapping(h);
      });
      setColumnMap(initialMap);

      const preview = transformExtractedRowsToStudents(sheet, {
        autoSplitFullName,
        autoStandardizeGender,
        autoCalculateFields,
        columnMap: initialMap,
      });
      setParsedData(preview);
    } catch (err: any) {
      setErrorMsg(err.message || 'កំហុសក្នុងការវិភាគទិន្នន័យ / Parse error');
    }
  };

  const updateMapping = (header: string, target: keyof StudentRecord | 'fullName' | 'ignore') => {
    const nextMap = { ...columnMap, [header]: target };
    setColumnMap(nextMap);
    if (rawSheet) {
      const updated = transformExtractedRowsToStudents(rawSheet, {
        autoSplitFullName,
        autoStandardizeGender,
        autoCalculateFields,
        columnMap: nextMap,
      });
      setParsedData(updated);
    }
  };

  const handleToggleOption = (key: 'split' | 'gender' | 'calc') => {
    let nextSplit = autoSplitFullName;
    let nextGender = autoStandardizeGender;
    let nextCalc = autoCalculateFields;

    if (key === 'split') {
      nextSplit = !autoSplitFullName;
      setAutoSplitFullName(nextSplit);
    } else if (key === 'gender') {
      nextGender = !autoStandardizeGender;
      setAutoStandardizeGender(nextGender);
    } else if (key === 'calc') {
      nextCalc = !autoCalculateFields;
      setAutoCalculateFields(nextCalc);
    }

    if (rawSheet) {
      const updated = transformExtractedRowsToStudents(rawSheet, {
        autoSplitFullName: nextSplit,
        autoStandardizeGender: nextGender,
        autoCalculateFields: nextCalc,
        columnMap,
      });
      setParsedData(updated);
    }
  };

  const handleConfirm = () => {
    if (parsedData.length === 0) return;
    onImport(parsedData, importMode);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-4xl overflow-hidden border border-slate-300 max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50/90 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-blue-100 text-blue-700 rounded-lg">
              <Upload className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <span>{lang === 'km' ? 'នាំចូលទិន្នន័យសិស្ស (Import Student Data)' : 'Import Student Data'}</span>
                <span className="text-[11px] bg-blue-100 text-blue-800 font-semibold px-2 py-0.5 rounded-full">
                  {lang === 'km' ? 'គាំទ្រប្រព័ន្ធចាស់ & បំបែកជួរឈរ' : 'Discrepancy & Splitting'}
                </span>
              </h2>
              <p className="text-xs text-slate-500">
                {lang === 'km'
                  ? 'នាំចូលពី Excel/CSV និងដោះស្រាយភាពខុសគ្នានៃជួរឈរ ព្រមទាំងបំបែកឈ្មោះពេញ និងគណនាស្វ័យប្រវត្តិ'
                  : 'Import from Excel/CSV with smart column discrepancy resolution and auto-calculation'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-200/60 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selection */}
        <div className="flex border-b border-slate-200 bg-slate-100/70 px-4 pt-2 shrink-0">
          <button
            onClick={() => setActiveTab('smart')}
            className={`px-4 py-2 text-xs font-bold border-b-2 cursor-pointer flex items-center gap-1.5 transition-colors ${
              activeTab === 'smart'
                ? 'border-blue-700 text-blue-800 bg-white rounded-t-lg shadow-xs'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Split className="w-4 h-4 text-blue-600" />
            <span>
              {lang === 'km'
                ? '១. បញ្ជីទាញចេញពីប្រព័ន្ធចាស់ (បំបែក & ផ្គូផ្គងជួរឈរ)'
                : '1. Extracted System (Split & Map Columns)'}
            </span>
          </button>
          <button
            onClick={() => setActiveTab('standard')}
            className={`px-4 py-2 text-xs font-bold border-b-2 cursor-pointer flex items-center gap-1.5 transition-colors ${
              activeTab === 'standard'
                ? 'border-blue-700 text-blue-800 bg-white rounded-t-lg shadow-xs'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            <span>
              {lang === 'km' ? '២. ឯកសារស្ដង់ដារ MoEYS (៦៥ ជួរឈរ)' : '2. Standard MoEYS 65-Col Template'}
            </span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 space-y-4 overflow-y-auto flex-1">
          {activeTab === 'smart' ? (
            <div className="space-y-4">
              {/* Splitting Options Bar */}
              <div className="p-3 bg-blue-50/80 border border-blue-200 rounded-xl space-y-2">
                <div className="flex items-center gap-2 text-xs font-bold text-blue-900">
                  <Sparkles className="w-4 h-4 text-blue-600" />
                  <span>{lang === 'km' ? 'ជម្រើសដោះស្រាយភាពខុសគ្នានៃជួរឈរ (Auto-Split & Calculation):' : 'Discrepancy & Splitting Automation:'}</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
                  <label className="flex items-center gap-2 cursor-pointer bg-white p-2 rounded-lg border border-blue-200 hover:bg-blue-50/50">
                    <input
                      type="checkbox"
                      checked={autoSplitFullName}
                      onChange={() => handleToggleOption('split')}
                      className="rounded text-blue-600 focus:ring-blue-500 w-4 h-4 cursor-pointer"
                    />
                    <span className="text-slate-800 font-medium">
                      {lang === 'km' ? 'បំបែក "គោត្តនាម-នាម" ស្វ័យប្រវត្តិ' : 'Auto-split Full Name (Last+First)'}
                    </span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer bg-white p-2 rounded-lg border border-blue-200 hover:bg-blue-50/50">
                    <input
                      type="checkbox"
                      checked={autoCalculateFields}
                      onChange={() => handleToggleOption('calc')}
                      className="rounded text-blue-600 focus:ring-blue-500 w-4 h-4 cursor-pointer"
                    />
                    <span className="text-slate-800 font-medium">
                      {lang === 'km' ? 'គណនាស្វ័យប្រវត្តិ អាយុ, BMI, ភ្នែក, ត្រចៀក' : 'Auto-compute Age, BMI, Ears & Eyes'}
                    </span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer bg-white p-2 rounded-lg border border-blue-200 hover:bg-blue-50/50">
                    <input
                      type="checkbox"
                      checked={autoStandardizeGender}
                      onChange={() => handleToggleOption('gender')}
                      className="rounded text-blue-600 focus:ring-blue-500 w-4 h-4 cursor-pointer"
                    />
                    <span className="text-slate-800 font-medium">
                      {lang === 'km' ? 'កែសម្រួលភេទ (ប្រុស/ស្រី) ស្វ័យប្រវត្តិ' : 'Standardize Gender (Male/Female)'}
                    </span>
                  </label>
                </div>
              </div>

              {/* Source Input Mode: File or Direct Paste */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Upload File */}
                <div className="border-2 border-dashed border-slate-300 hover:border-blue-500 rounded-xl p-4 text-center transition-colors bg-white">
                  <FileSpreadsheet className="w-8 h-8 text-blue-600 mx-auto mb-1.5" />
                  <label className="block text-xs font-bold text-blue-700 hover:text-blue-800 cursor-pointer">
                    <span>{lang === 'km' ? 'ជ្រើសរើសឯកសារ Excel / CSV' : 'Upload Extracted Excel / CSV'}</span>
                    <input
                      type="file"
                      accept=".xlsx, .xls, .csv"
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                  </label>
                  <p className="text-[11px] text-slate-400 mt-1">
                    {file ? `${file.name} (${(file.size / 1024).toFixed(1)} KB)` : (lang === 'km' ? 'ទាញទម្លាក់ ឬ ចុចដើម្បីជ្រើសឯកសារ' : 'Drag & drop or browse file')}
                  </p>
                </div>

                {/* Paste from Excel Clipboard */}
                <div className="border border-slate-300 rounded-xl p-3 bg-white flex flex-col">
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                      <ClipboardPaste className="w-3.5 h-3.5 text-blue-600" />
                      {lang === 'km' ? 'ឬ ចម្លង & បិទភ្ជាប់ពី Excel ដោយផ្ទាល់' : 'Or Paste directly from Excel'}
                    </span>
                    {pasteText && (
                      <button
                        onClick={handleApplyPaste}
                        className="text-[11px] font-bold text-blue-700 hover:text-blue-900 bg-blue-50 px-2 py-0.5 rounded cursor-pointer"
                      >
                        {lang === 'km' ? 'វិភាគទិន្នន័យ (Parse)' : 'Apply Parse'}
                      </button>
                    )}
                  </div>
                  <textarea
                    rows={2}
                    value={pasteText}
                    onChange={(e) => setPasteText(e.target.value)}
                    placeholder={
                      lang === 'km'
                        ? 'ចុច Copy ជួរដេកពី Excel ហើយ Paste នៅទីនេះ (មានជួរឈរ ឈ្មោះ, ភេទ, ថ្ងៃកំណើត...)'
                        : 'Copy table cells from Excel and paste here...'
                    }
                    className="w-full flex-1 p-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-blue-500 font-mono"
                  />
                  {pasteText && !rawSheet && (
                    <button
                      onClick={handleApplyPaste}
                      className="mt-2 w-full py-1 text-xs font-bold bg-blue-700 text-white rounded cursor-pointer hover:bg-blue-800"
                    >
                      {lang === 'km' ? 'បំប្លែងទិន្នន័យដែលបានបិទភ្ជាប់' : 'Transform Pasted Data'}
                    </button>
                  )}
                </div>
              </div>

              {/* Column Mapping Section if Raw Sheet Detected */}
              {rawSheet && rawSheet.headers.length > 0 && (
                <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Columns className="w-4 h-4 text-slate-700" />
                      <span className="text-xs font-bold text-slate-900">
                        {lang === 'km' ? 'ផ្គូផ្គងជួរឈរពីប្រព័ន្ធចាស់ ទៅប្រព័ន្ធថ្មី SIS (Column Mapping):' : 'Column Mapping:'}
                      </span>
                    </div>
                    <span className="text-[11px] text-slate-500 font-mono">
                      {rawSheet.headers.length} {lang === 'km' ? 'ជួរឈររកឃើញ' : 'cols detected'}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5 max-h-48 overflow-y-auto p-1 bg-white border border-slate-200 rounded-lg">
                    {rawSheet.headers.map((header) => {
                      const currentMapped = columnMap[header] || 'ignore';
                      return (
                        <div key={header} className="p-2 border border-slate-200 rounded-md bg-slate-50/60 text-xs">
                          <div className="font-bold text-slate-900 truncate mb-1" title={header}>
                            {header}
                          </div>
                          <div className="flex items-center gap-1">
                            <ArrowRight className="w-3 h-3 text-slate-400 shrink-0" />
                            <select
                              value={currentMapped}
                              onChange={(e) => updateMapping(header, e.target.value as any)}
                              className="w-full bg-white border border-slate-300 rounded px-1.5 py-1 text-xs text-blue-900 font-medium focus:ring-1 focus:ring-blue-500 focus:outline-hidden"
                            >
                              {SIS_TARGET_FIELDS.map((field) => (
                                <option key={field.key} value={field.key}>
                                  {lang === 'km' ? field.labelKm : field.labelEn}
                                </option>
                              ))}
                            </select>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          ) : (
            /* Standard MoEYS File Upload */
            <div className="space-y-4">
              <div className="border-2 border-dashed border-slate-300 hover:border-blue-500 rounded-xl p-8 text-center transition-colors bg-white">
                <FileSpreadsheet className="w-12 h-12 text-slate-400 mx-auto mb-2" />
                <label className="block text-sm font-semibold text-blue-700 hover:text-blue-800 cursor-pointer">
                  <span>{lang === 'km' ? 'ជ្រើសរើសឯកសារទម្រង់ ៦៥ ជួរឈរ MoEYS' : 'Choose 65-Col MoEYS Template File'}</span>
                  <input
                    type="file"
                    accept=".xlsx, .xls, .csv"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </label>
                <p className="text-xs text-slate-400 mt-1">
                  {lang === 'km'
                    ? 'គាំទ្រទម្រង់ស្តង់ដារក្រសួង .xlsx, .xls ឬ .csv'
                    : 'Supports standard MoEYS .xlsx, .xls and .csv files'}
                </p>
                {file && (
                  <div className="mt-3 text-xs font-medium text-slate-700 bg-slate-100 py-1.5 px-3 rounded-md inline-block">
                    {file.name} ({(file.size / 1024).toFixed(1)} KB)
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Loading status */}
          {loading && (
            <div className="py-4 text-center text-xs text-slate-500">
              {lang === 'km' ? 'កំពុងអាន និងបំប្លែងទិន្នន័យ...' : 'Reading and transforming data...'}
            </div>
          )}

          {/* Error Message */}
          {errorMsg && (
            <div className="p-3 bg-red-50 text-red-700 rounded-lg text-xs flex items-center gap-2 border border-red-200">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Live Preview of Transformed Student Records */}
          {parsedData.length > 0 && (
            <div className="space-y-3 pt-2 border-t border-slate-200">
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-slate-900">
                    {lang === 'km' ? 'លទ្ធផលបំប្លែងទិន្នន័យដែលទទួលបាន៖' : 'Transformed Student Records:'}
                  </span>
                  <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold font-mono">
                    {parsedData.length} {lang === 'km' ? 'នាក់' : 'students'}
                  </span>
                  {autoSplitFullName && (
                    <span className="text-[10px] bg-blue-100 text-blue-800 px-1.5 py-0.5 rounded font-medium">
                      ✓ បានបំបែក គោត្តនាម-នាម
                    </span>
                  )}
                  {autoCalculateFields && (
                    <span className="text-[10px] bg-purple-100 text-purple-800 px-1.5 py-0.5 rounded font-medium">
                      ✓ បានគណនា អាយុ & BMI
                    </span>
                  )}
                </div>
              </div>

              {/* Preview Table */}
              <div className="max-h-48 overflow-y-auto border border-slate-300 rounded-lg text-xs shadow-inner">
                <table className="min-w-full divide-y divide-slate-300">
                  <thead className="bg-slate-100 text-slate-700 font-bold sticky top-0">
                    <tr>
                      <th className="px-2.5 py-1.5 text-center">#</th>
                      <th className="px-2.5 py-1.5 text-center">{lang === 'km' ? 'អត្តលេខ' : 'ID'}</th>
                      <th className="px-2.5 py-1.5 text-left">{lang === 'km' ? 'គោត្តនាម' : 'Last Name'}</th>
                      <th className="px-2.5 py-1.5 text-left">{lang === 'km' ? 'នាម' : 'First Name'}</th>
                      <th className="px-2.5 py-1.5 text-center">{lang === 'km' ? 'ភេទ' : 'Gender'}</th>
                      <th className="px-2.5 py-1.5 text-center">{lang === 'km' ? 'ថ្ងៃខែឆ្នាំកំណើត' : 'DOB'}</th>
                      <th className="px-2.5 py-1.5 text-center">{lang === 'km' ? 'អាយុ' : 'Age'}</th>
                      <th className="px-2.5 py-1.5 text-center">{lang === 'km' ? 'BMI ឆ១' : 'BMI 1'}</th>
                      <th className="px-2.5 py-1.5 text-center">{lang === 'km' ? 'ភ្នែក' : 'Eye'}</th>
                      <th className="px-2.5 py-1.5 text-center">{lang === 'km' ? 'ត្រចៀក' : 'Ear'}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 bg-white">
                    {parsedData.slice(0, 15).map((s, i) => (
                      <tr key={i} className="hover:bg-slate-50">
                        <td className="px-2 py-1 text-slate-400 font-mono text-center">{i + 1}</td>
                        <td className="px-2 py-1 font-mono text-center font-bold text-slate-800">{s.studentCode || '—'}</td>
                        <td className="px-2 py-1 font-semibold text-blue-900">{s.lastName || '—'}</td>
                        <td className="px-2 py-1 font-semibold text-blue-900">{s.firstName || '—'}</td>
                        <td className="px-2 py-1 text-center font-bold">
                          <span className={s.gender === 'ស្រី' ? 'text-pink-700' : 'text-blue-700'}>
                            {s.gender}
                          </span>
                        </td>
                        <td className="px-2 py-1 text-center font-mono">{s.dob || '—'}</td>
                        <td className="px-2 py-1 text-center font-mono font-bold text-purple-700">{s.age || '—'}</td>
                        <td className="px-2 py-1 text-center font-mono text-[11px]">
                          {s.bmiSem1 ? `${s.bmiSem1} (${s.bmiStatusSem1 || ''})` : '—'}
                        </td>
                        <td className="px-2 py-1 text-center text-[11px]">{s.eyeResult || '—'}</td>
                        <td className="px-2 py-1 text-center text-[11px]">{s.earResult || '—'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {parsedData.length > 15 && (
                <div className="text-[11px] text-slate-500 text-center font-medium">
                  +{parsedData.length - 15} {lang === 'km' ? 'នាក់ទៀតនៅក្នុងបញ្ជី' : 'more students in list'}
                </div>
              )}

              {/* Import Mode Options (Append vs Replace) */}
              <div className="pt-2 border-t border-slate-200">
                <span className="block text-xs font-bold text-slate-800 mb-1.5">
                  {lang === 'km' ? 'វិធីសាស្ត្របញ្ចូលទិន្នន័យទៅក្នុងប្រព័ន្ធ៖' : 'Import Mode:'}
                </span>
                <div className="grid grid-cols-2 gap-3 text-xs">
                  <label
                    onClick={() => setImportMode('append')}
                    className={`p-2.5 rounded-lg border-2 cursor-pointer flex items-center justify-between ${
                      importMode === 'append'
                        ? 'border-blue-600 bg-blue-50/70 text-blue-950 font-bold'
                        : 'border-slate-300 text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <div>
                      <span className="block">
                        {lang === 'km' ? 'បន្ថែមលើទិន្នន័យបច្ចុប្បន្ន' : 'Append to existing'}
                      </span>
                      <span className="text-[11px] font-normal text-slate-500">
                        {lang === 'km' ? 'រក្សាសិស្សដែលមានស្រាប់ទុក' : 'Keeps existing records'}
                      </span>
                    </div>
                    {importMode === 'append' && <Check className="w-4 h-4 text-blue-600" />}
                  </label>

                  <label
                    onClick={() => setImportMode('replace')}
                    className={`p-2.5 rounded-lg border-2 cursor-pointer flex items-center justify-between ${
                      importMode === 'replace'
                        ? 'border-amber-600 bg-amber-50/70 text-amber-950 font-bold'
                        : 'border-slate-300 text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <div>
                      <span className="block">
                        {lang === 'km' ? 'ជំនួសទិន្នន័យចាស់ទាំងអស់' : 'Replace all existing'}
                      </span>
                      <span className="text-[11px] font-normal text-slate-500">
                        {lang === 'km' ? 'សម្អាតទិន្នន័យចាស់ ហើយដាក់បញ្ជីថ្មីនេះ' : 'Replaces whole table with imported list'}
                      </span>
                    </div>
                    {importMode === 'replace' && <Check className="w-4 h-4 text-amber-600" />}
                  </label>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between shrink-0">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-700 hover:text-slate-900 bg-white border border-slate-300 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
          >
            {lang === 'km' ? 'បោះបង់' : 'Cancel'}
          </button>
          <button
            onClick={handleConfirm}
            disabled={parsedData.length === 0}
            className="px-6 py-2 text-xs font-bold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-40 disabled:cursor-not-allowed rounded-lg transition-colors cursor-pointer shadow-sm flex items-center gap-1.5"
          >
            <Check className="w-4 h-4" />
            <span>
              {lang === 'km'
                ? `បញ្ចូលទិន្នន័យ (${parsedData.length} នាក់)`
                : `Confirm Import (${parsedData.length} Records)`}
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
