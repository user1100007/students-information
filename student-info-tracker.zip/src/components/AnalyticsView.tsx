import React from 'react';
import { Users, Heart, BookOpen, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { StudentRecord, Language } from '../types/student';
import { calculateBMI } from '../utils/exportImport';

interface AnalyticsViewProps {
  students: StudentRecord[];
  lang: Language;
}

export const AnalyticsView: React.FC<AnalyticsViewProps> = ({ students, lang }) => {
  const total = students.length;

  // Grade Breakdown
  const gradeCounts: Record<string, { total: number; female: number; male: number }> = {};
  students.forEach((s) => {
    const grade = s.previousGrade || (lang === 'km' ? 'មិនបានបញ្ជាក់' : 'Unspecified');
    if (!gradeCounts[grade]) {
      gradeCounts[grade] = { total: 0, female: 0, male: 0 };
    }
    gradeCounts[grade].total += 1;
    const isFemale = s.gender === 'ស្រី' || s.gender.toLowerCase() === 'female' || s.gender === 'f';
    if (isFemale) {
      gradeCounts[grade].female += 1;
    } else {
      gradeCounts[grade].male += 1;
    }
  });

  // Equity breakdown
  let poor1 = 0;
  let poor2 = 0;
  let nonPoor = 0;
  students.forEach((s) => {
    if (s.equityFamily.includes('ក្រ១') || s.equityFamily.includes('1')) poor1++;
    else if (s.equityFamily.includes('ក្រ២') || s.equityFamily.includes('2')) poor2++;
    else nonPoor++;
  });

  // BMI breakdown for Sem 1
  let bmiUnder = 0;
  let bmiNormal = 0;
  let bmiOver = 0;
  let bmiNotMeasured = 0;
  students.forEach((s) => {
    const res = calculateBMI(s.weightSem1, s.heightSem1);
    if (res.status === 'under') bmiUnder++;
    else if (res.status === 'normal') bmiNormal++;
    else if (res.status === 'over') bmiOver++;
    else bmiNotMeasured++;
  });

  // Learning Kits Received
  const readingKits = students.filter((s) => s.kitReading.includes('ទទួល')).length;
  const mathKits = students.filter((s) => s.kitMath.includes('ទទួល')).length;
  const khmerBooks = students.filter((s) => s.kitKhmerBook.includes('មាន')).length;
  const mathBooks = students.filter((s) => s.kitMathBook.includes('មាន')).length;

  return (
    <div className="space-y-6">
      {/* Overview Top Card */}
      <div className="p-6 bg-white rounded-2xl border border-slate-200/90 shadow-2xs">
        <h2 className="text-base font-bold text-slate-900 mb-1">
          {lang === 'km' ? 'ស្ថិតិ និងរបាយការណ៍សង្ខេបសាលារៀន' : 'School Summary & Enrolment Statistics'}
        </h2>
        <p className="text-xs text-slate-500">
          {lang === 'km'
            ? 'ទិន្នន័យវិភាគដោយស្វ័យប្រវត្តិចេញពីបញ្ជីឈ្មោះសិស្សទាំង ៦៥ ជួរឈរ'
            : 'Aggregated analytics generated automatically from the 65-column student records'}
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* 1. Grade & Gender Breakdown */}
        <div className="p-5 bg-white rounded-xl border border-slate-200/90 shadow-2xs">
          <div className="flex items-center gap-2 mb-4">
            <Users className="w-4 h-4 text-blue-700" />
            <h3 className="text-sm font-bold text-slate-900">
              {lang === 'km' ? 'ការបែងចែកសិស្សតាមកម្រិតថ្នាក់' : 'Enrolment by Grade & Gender'}
            </h3>
          </div>

          <div className="space-y-3">
            {Object.entries(gradeCounts).map(([grade, data]) => {
              const pct = total > 0 ? Math.round((data.total / total) * 100) : 0;
              return (
                <div key={grade} className="text-xs">
                  <div className="flex items-center justify-between text-slate-700 mb-1 font-medium">
                    <span>
                      {lang === 'km' ? `ថ្នាក់ ${grade}` : `Grade ${grade}`}
                    </span>
                    <span className="font-mono tabular-nums text-slate-500">
                      {data.total} {lang === 'km' ? 'នាក់' : 'students'} (
                      <span className="text-pink-600 font-semibold">{data.female} {lang === 'km' ? 'ស្រី' : 'F'}</span> /{' '}
                      <span className="text-blue-600 font-semibold">{data.male} {lang === 'km' ? 'ប្រុស' : 'M'}</span>)
                    </span>
                  </div>
                  <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden flex">
                    <div
                      className="bg-pink-400 h-2 transition-all"
                      style={{ width: `${(data.female / (data.total || 1)) * 100}%` }}
                    />
                    <div
                      className="bg-blue-500 h-2 transition-all"
                      style={{ width: `${(data.male / (data.total || 1)) * 100}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* 2. Equity & Social Protection */}
        <div className="p-5 bg-white rounded-xl border border-slate-200/90 shadow-2xs">
          <div className="flex items-center gap-2 mb-4">
            <ShieldCheck className="w-4 h-4 text-amber-600" />
            <h3 className="text-sm font-bold text-slate-900">
              {lang === 'km' ? 'ស្ថានភាពសមធម៌ និង បណ្ណក្រីក្រ (IDPoor)' : 'Equity & IDPoor Status'}
            </h3>
          </div>

          <div className="grid grid-cols-3 gap-3 mb-4">
            <div className="p-3 bg-amber-50/60 rounded-lg border border-amber-200/60 text-center">
              <span className="text-[11px] text-amber-800 font-medium block">
                {lang === 'km' ? 'កម្រិត ក្រ១' : 'IDPoor Level 1'}
              </span>
              <span className="text-xl font-bold font-mono text-amber-900 tabular-nums">{poor1}</span>
              <span className="text-[11px] text-amber-700 block mt-0.5">
                {total > 0 ? Math.round((poor1 / total) * 100) : 0}%
              </span>
            </div>

            <div className="p-3 bg-orange-50/60 rounded-lg border border-orange-200/60 text-center">
              <span className="text-[11px] text-orange-800 font-medium block">
                {lang === 'km' ? 'កម្រិត ក្រ២' : 'IDPoor Level 2'}
              </span>
              <span className="text-xl font-bold font-mono text-orange-900 tabular-nums">{poor2}</span>
              <span className="text-[11px] text-orange-700 block mt-0.5">
                {total > 0 ? Math.round((poor2 / total) * 100) : 0}%
              </span>
            </div>

            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-center">
              <span className="text-[11px] text-slate-600 font-medium block">
                {lang === 'km' ? 'មិនក្រីក្រ' : 'Non-Poor'}
              </span>
              <span className="text-xl font-bold font-mono text-slate-800 tabular-nums">{nonPoor}</span>
              <span className="text-[11px] text-slate-500 block mt-0.5">
                {total > 0 ? Math.round((nonPoor / total) * 100) : 0}%
              </span>
            </div>
          </div>

          <p className="text-xs text-slate-500">
            {lang === 'km'
              ? 'ទិន្នន័យសមធម៌ជួយកំណត់សិស្សដែលត្រូវទទួលបានអាហារូបករណ៍រដ្ឋ និងកញ្ចប់ឧបត្ថម្ភសង្គម។'
              : 'Used for scholarship eligibility and social welfare package delivery.'}
          </p>
        </div>

        {/* 3. Nutrition & BMI Status */}
        <div className="p-5 bg-white rounded-xl border border-slate-200/90 shadow-2xs">
          <div className="flex items-center gap-2 mb-4">
            <Heart className="w-4 h-4 text-emerald-600" />
            <h3 className="text-sm font-bold text-slate-900">
              {lang === 'km' ? 'ការលូតលាស់ & សន្ទស្សន៍ម៉ាសរាងកាយ (BMI) ឆមាស១' : 'Nutrition & BMI Status (Sem 1)'}
            </h3>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-xs">
            <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200">
              <span className="text-slate-500 block">{lang === 'km' ? 'កង្វះទម្ងន់' : 'Underweight'}</span>
              <span className="text-lg font-bold font-mono text-blue-700 tabular-nums">{bmiUnder}</span>
            </div>
            <div className="p-2.5 bg-emerald-50 rounded-lg border border-emerald-200">
              <span className="text-emerald-800 block">{lang === 'km' ? 'ទម្ងន់សមស្រប' : 'Normal'}</span>
              <span className="text-lg font-bold font-mono text-emerald-700 tabular-nums">{bmiNormal}</span>
            </div>
            <div className="p-2.5 bg-amber-50 rounded-lg border border-amber-200">
              <span className="text-amber-800 block">{lang === 'km' ? 'លើសទម្ងន់' : 'Overweight'}</span>
              <span className="text-lg font-bold font-mono text-amber-700 tabular-nums">{bmiOver}</span>
            </div>
            <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200">
              <span className="text-slate-400 block">{lang === 'km' ? 'មិនទាន់វាស់' : 'Unmeasured'}</span>
              <span className="text-lg font-bold font-mono text-slate-600 tabular-nums">{bmiNotMeasured}</span>
            </div>
          </div>
        </div>

        {/* 4. Learning Support Packages */}
        <div className="p-5 bg-white rounded-xl border border-slate-200/90 shadow-2xs">
          <div className="flex items-center gap-2 mb-4">
            <BookOpen className="w-4 h-4 text-indigo-600" />
            <h3 className="text-sm font-bold text-slate-900">
              {lang === 'km' ? 'ការបែងចែកកញ្ចប់សម្ភារជំនួយ' : 'Learning Support Packages Distributed'}
            </h3>
          </div>

          <div className="space-y-2.5 text-xs">
            <div>
              <div className="flex justify-between text-slate-700 mb-1">
                <span>{lang === 'km' ? 'កញ្ចប់អំណាន (Reading Kit)' : 'Reading Kits'}</span>
                <span className="font-mono font-medium">{readingKits} / {total}</span>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                <div
                  className="bg-indigo-600 h-2 rounded-full transition-all"
                  style={{ width: `${total > 0 ? (readingKits / total) * 100 : 0}%` }}
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-slate-700 mb-1">
                <span>{lang === 'km' ? 'កញ្ចប់គណិតវិទ្យា (Math Kit)' : 'Math Kits'}</span>
                <span className="font-mono font-medium">{mathKits} / {total}</span>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                <div
                  className="bg-blue-600 h-2 rounded-full transition-all"
                  style={{ width: `${total > 0 ? (mathKits / total) * 100 : 0}%` }}
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-slate-700 mb-1">
                <span>{lang === 'km' ? 'សៀវភៅជំនួយភាសាខ្មែរ' : 'Khmer Supplementary Books'}</span>
                <span className="font-mono font-medium">{khmerBooks} / {total}</span>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                <div
                  className="bg-teal-600 h-2 rounded-full transition-all"
                  style={{ width: `${total > 0 ? (khmerBooks / total) * 100 : 0}%` }}
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-slate-700 mb-1">
                <span>{lang === 'km' ? 'សៀវភៅជំនួយគណិតវិទ្យា' : 'Math Supplementary Books'}</span>
                <span className="font-mono font-medium">{mathBooks} / {total}</span>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                <div
                  className="bg-amber-600 h-2 rounded-full transition-all"
                  style={{ width: `${total > 0 ? (mathBooks / total) * 100 : 0}%` }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
