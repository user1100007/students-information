import React, { useState, useMemo } from 'react';
import {
  Search,
  Download,
  Upload,
  Printer,
  Trash2,
  Edit2,
  Eye,
  SlidersHorizontal,
  ChevronDown,
  RotateCcw,
  FileSpreadsheet,
  CheckSquare,
  Square,
  Sparkles,
  Maximize2,
  Minimize2,
  X,
  UserCheck,
  Copy,
  Check,
  FileText,
} from 'lucide-react';
import { StudentRecord, Language } from '../types/student';
import { GROUPS } from '../data/initialData';
import { calculateAge, computeBMI, evaluateEyes, evaluateHearing } from '../utils/calculations';
import { exportToExcel, exportToCsv, downloadTemplate } from '../utils/exportImport';

interface StudentTableProps {
  students: StudentRecord[];
  lang: Language;
  onViewStudent: (student: StudentRecord) => void;
  onEditStudent: (student: StudentRecord) => void;
  onUpdateStudent?: (student: StudentRecord) => void;
  onRecalculateAll?: () => void;
  onDeleteStudent: (studentId: string) => void;
  onDeleteMultiple: (studentIds: string[]) => void;
  onOpenImportModal: () => void;
  onOpenAddModal?: () => void;
  onResetData: () => void;
}

export const StudentTable: React.FC<StudentTableProps> = ({
  students,
  lang,
  onViewStudent,
  onEditStudent,
  onUpdateStudent,
  onRecalculateAll,
  onDeleteStudent,
  onDeleteMultiple,
  onOpenImportModal,
  onOpenAddModal,
}) => {
  // Search & Filter States
  const [searchTerm, setSearchTerm] = useState('');
  const [genderFilter, setGenderFilter] = useState<'all' | 'ស្រី' | 'ប្រុស'>('all');
  const [gradeFilter, setGradeFilter] = useState<string>('all');
  const [equityFilter, setEquityFilter] = useState<string>('all');
  const [orphanFilter, setOrphanFilter] = useState<string>('all');
  const [disabilityFilter, setDisabilityFilter] = useState<string>('all');
  const [ageFilter, setAgeFilter] = useState<string>('all');
  const [nutritionFilter, setNutritionFilter] = useState<string>('all');
  const [sensoryFilter, setSensoryFilter] = useState<string>('all');

  // Direct Inline Edit & Auto-Save
  const [isInlineEditMode, setIsInlineEditMode] = useState(true);
  const [autoSaveStatus, setAutoSaveStatus] = useState<string | null>(null);

  // Trigger temporary auto-save banner
  const triggerAutoSaveNotice = (msg?: string) => {
    setAutoSaveStatus(msg || (lang === 'km' ? 'បានរក្សាទុកដោយស្វ័យប្រវត្តិ ✓' : 'Auto-Saved ✓'));
    setTimeout(() => {
      setAutoSaveStatus(null);
    }, 2500);
  };

  // Handle cell change with real-time automatic calculation of Age, BMI, Ears & Eyes
  const handleCellChange = (student: StudentRecord, field: keyof StudentRecord, value: string) => {
    const updated: StudentRecord = { ...student, [field]: value };

    // 1. Auto-calculate Age if Date of Birth changes
    if (field === 'dob') {
      const a = calculateAge(value);
      if (a !== null) {
        updated.age = a;
      }
    }

    // 2. Auto-calculate Semester 1 BMI & Status
    if (field === 'weightSem1' || field === 'heightSem1') {
      const res = computeBMI(updated.weightSem1, updated.heightSem1);
      if (res.bmi) {
        updated.bmiSem1 = res.bmi;
        updated.bmiStatusSem1 = res.status;
      }
    }

    // 3. Auto-calculate Semester 2 BMI & Status
    if (field === 'weightSem2' || field === 'heightSem2') {
      const res = computeBMI(updated.weightSem2, updated.heightSem2);
      if (res.bmi) {
        updated.bmiSem2 = res.bmi;
        updated.bmiStatusSem2 = res.status;
      }
    }

    // 4. Auto-evaluate Eyes
    if (field === 'eyeLeft' || field === 'eyeRight') {
      updated.eyeResult = evaluateEyes(updated.eyeLeft, updated.eyeRight, updated.eyeResult);
    }

    // 5. Auto-evaluate Ears
    if (field === 'earLeft' || field === 'earRight') {
      updated.earResult = evaluateHearing(updated.earLeft, updated.earRight, updated.earResult);
    }

    if (onUpdateStudent) {
      onUpdateStudent(updated);
      triggerAutoSaveNotice();
    }
  };

  // Trigger one-click Auto-Calculation across all students
  const handleRecalculateAllClick = () => {
    if (onRecalculateAll) {
      onRecalculateAll();
      triggerAutoSaveNotice(
        lang === 'km'
          ? 'បានគណនា អាយុ, BMI, ភ្នែក, ត្រចៀក និងរក្សាទុកគ្រប់សិស្សទាំងអស់រួចរាល់! ⚡'
          : 'Auto-calculated Age, BMI, Ears & Eyes for all students! ⚡'
      );
    }
  };

  const handleResetFilters = () => {
    setSearchTerm('');
    setGenderFilter('all');
    setGradeFilter('all');
    setEquityFilter('all');
    setOrphanFilter('all');
    setDisabilityFilter('all');
    setAgeFilter('all');
    setNutritionFilter('all');
    setSensoryFilter('all');
  };

  // Selected row IDs
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  // Density & Borderline States
  const [density, setDensity] = useState<'ultra' | 'compact'>('ultra');
  const [borderContrast, setBorderContrast] = useState<'bold' | 'sharp'>('bold');
  const [isFullscreen, setIsFullscreen] = useState(false);

  // Visible groups toggle
  const [visibleGroupIds, setVisibleGroupIds] = useState<Record<string, boolean>>(() => {
    const initial: Record<string, boolean> = {};
    GROUPS.forEach((g) => {
      initial[g.id] = true;
    });
    return initial;
  });

  const [showGroupSelector, setShowGroupSelector] = useState(false);
  const [showExportMenu, setShowExportMenu] = useState(false);

  // Distinct grades for filter
  const distinctGrades = useMemo(() => {
    const grades = new Set<string>();
    students.forEach((s) => {
      if (s.previousGrade) grades.add(s.previousGrade);
    });
    return Array.from(grades).sort();
  }, [students]);

  // Filtered Students
  const filteredStudents = useMemo(() => {
    return students.filter((s) => {
      if (searchTerm.trim() !== '') {
        const query = searchTerm.toLowerCase().trim();
        const matches = Object.values(s).some(
          (val) => typeof val === 'string' && val.toLowerCase().includes(query)
        );
        if (!matches) return false;
      }

      // Gender filter
      if (genderFilter !== 'all') {
        const isFemale = s.gender === 'ស្រី' || s.gender.toLowerCase() === 'female' || s.gender === 'f';
        if (genderFilter === 'ស្រី' && !isFemale) return false;
        if (genderFilter === 'ប្រុស' && isFemale) return false;
      }

      // Grade filter
      if (gradeFilter !== 'all' && s.previousGrade !== gradeFilter) {
        return false;
      }

      // Equity filter
      if (equityFilter === 'poor') {
        const isPoor = s.equityFamily.includes('ក្រ') || s.equityCard.trim() !== '';
        if (!isPoor) return false;
      } else if (equityFilter === 'poor1') {
        if (!s.equityFamily.includes('ក្រ១')) return false;
      } else if (equityFilter === 'poor2') {
        if (!s.equityFamily.includes('ក្រ២')) return false;
      } else if (equityFilter === 'non_poor') {
        const isPoor = s.equityFamily.includes('ក្រ') || s.equityCard.trim() !== '';
        if (isPoor) return false;
      }

      // Orphan filter
      if (orphanFilter === 'orphan') {
        const isOrphan = s.orphanStatus && !s.orphanStatus.includes('មិនកំព្រា') && s.orphanStatus.trim() !== '';
        if (!isOrphan) return false;
      } else if (orphanFilter === 'father') {
        if (!s.orphanStatus || !s.orphanStatus.includes('កំព្រាឪពុក') || s.orphanStatus.includes('ម្ដាយ')) return false;
      } else if (orphanFilter === 'mother') {
        if (!s.orphanStatus || !s.orphanStatus.includes('កំព្រាម្ដាយ') || s.orphanStatus.includes('ឪពុក')) return false;
      } else if (orphanFilter === 'both') {
        if (!s.orphanStatus || (!s.orphanStatus.includes('កំព្រាឪពុកម្ដាយ') && !s.orphanStatus.includes('ទាំងពីរ'))) return false;
      } else if (orphanFilter === 'non_orphan') {
        if (s.orphanStatus && !s.orphanStatus.includes('មិនកំព្រា') && s.orphanStatus.trim() !== '') return false;
      }

      // Disability filter
      if (disabilityFilter === 'disabled') {
        if (!s.disabilityType || s.disabilityType.trim() === '' || s.disabilityType.includes('គ្មាន')) return false;
      } else if (disabilityFilter === 'speech') {
        if (!s.disabilityType || !s.disabilityType.includes('និយាយ')) return false;
      } else if (disabilityFilter === 'vision') {
        if (!s.disabilityType || !s.disabilityType.includes('មើល')) return false;
      } else if (disabilityFilter === 'hearing') {
        if (!s.disabilityType || !s.disabilityType.includes('ស្ដាប់')) return false;
      } else if (disabilityFilter === 'walking') {
        if (!s.disabilityType || !s.disabilityType.includes('ដើរ')) return false;
      }

      // Age filter
      if (ageFilter !== 'all') {
        const studentAge = s.age !== undefined && s.age !== '' ? Number(s.age) : (s.dob ? calculateAge(s.dob) : null);
        if (ageFilter === '12+') {
          if (!studentAge || studentAge < 12) return false;
        } else {
          if (studentAge !== Number(ageFilter)) return false;
        }
      }

      // Nutrition / BMI filter
      if (nutritionFilter !== 'all') {
        const status = s.bmiStatusSem1 || s.bmiStatusSem2 || '';
        if (!status.includes(nutritionFilter)) return false;
      }

      // Sensory filter
      if (sensoryFilter === 'eye') {
        if (!s.eyeResult || !s.eyeResult.includes('ខ្សោយ')) return false;
      } else if (sensoryFilter === 'ear') {
        if (!s.earResult || !s.earResult.includes('ខ្សោយ')) return false;
      }

      return true;
    });
  }, [students, searchTerm, genderFilter, gradeFilter, equityFilter, orphanFilter, disabilityFilter, ageFilter, nutritionFilter, sensoryFilter]);

  const [copiedSummary, setCopiedSummary] = useState(false);

  // --- DETAILED STATISTICAL SUMMARY AT BOTTOM OF TABLE (ផ្នែកខាងក្រោមនៃបញ្ជីរាយនាមសិស្ស) ---
  const statsSummary = useMemo(() => {
    const list = filteredStudents;
    const total = list.length;
    const isF = (s: StudentRecord) =>
      s.gender === 'ស្រី' || s.gender.toLowerCase() === 'female' || s.gender === 'f';
    const totalFemale = list.filter(isF).length;

    // 1. Age distribution for all ages
    const ageMap: Record<number, { total: number; female: number }> = {};
    list.forEach((s) => {
      let ageNum: number | null = null;
      if (s.age !== undefined && s.age !== '' && !isNaN(Number(s.age))) {
        ageNum = Number(s.age);
      } else if (s.dob) {
        ageNum = calculateAge(s.dob);
      }
      if (ageNum !== null && !isNaN(ageNum)) {
        if (!ageMap[ageNum]) ageMap[ageNum] = { total: 0, female: 0 };
        ageMap[ageNum].total += 1;
        if (isF(s)) ageMap[ageNum].female += 1;
      }
    });

    const ageList = Object.keys(ageMap)
      .map(Number)
      .sort((a, b) => a - b)
      .map((age) => ({
        age,
        total: ageMap[age].total,
        female: ageMap[age].female,
      }));

    // 2. Disability distribution
    const disabledList = list.filter(
      (s) => s.disabilityType && s.disabilityType.trim() !== '' && !s.disabilityType.includes('គ្មាន')
    );
    const disabledTotal = disabledList.length;
    const disabledFemale = disabledList.filter(isF).length;

    const speechList = list.filter((s) => s.disabilityType && s.disabilityType.includes('និយាយ'));
    const visionList = list.filter((s) => s.disabilityType && s.disabilityType.includes('មើល'));
    const otherDisabilityList = list.filter(
      (s) =>
        s.disabilityType &&
        s.disabilityType.trim() !== '' &&
        !s.disabilityType.includes('គ្មាន') &&
        !s.disabilityType.includes('និយាយ') &&
        !s.disabilityType.includes('មើល')
    );

    // 3. Poor family (Equity / IDPoor) distribution
    const poorList = list.filter(
      (s) => s.equityFamily.includes('ក្រ') || s.equityFamily.includes('ផ្សេងៗ') || (s.equityCard && s.equityCard.trim() !== '')
    );
    const poorTotal = poorList.length;
    const poorFemale = poorList.filter(isF).length;

    const poor1List = list.filter((s) => s.equityFamily.includes('ក្រ១'));
    const poor2List = list.filter((s) => s.equityFamily.includes('ក្រ២'));
    const poorOtherList = list.filter(
      (s) =>
        (s.equityFamily.includes('ផ្សេងៗ') || (s.equityCard && s.equityCard.trim() !== '')) &&
        !s.equityFamily.includes('ក្រ១') &&
        !s.equityFamily.includes('ក្រ២')
    );

    // 4. Orphan distribution
    const orphanList = list.filter(
      (s) => s.orphanStatus && s.orphanStatus.trim() !== '' && !s.orphanStatus.includes('មិនកំព្រា')
    );
    const orphanTotal = orphanList.length;
    const orphanFemale = orphanList.filter(isF).length;

    const orphanFatherList = list.filter(
      (s) => s.orphanStatus && s.orphanStatus.includes('កំព្រាឪពុក') && !s.orphanStatus.includes('ម្ដាយ')
    );
    const orphanMotherList = list.filter(
      (s) => s.orphanStatus && s.orphanStatus.includes('កំព្រាម្ដាយ') && !s.orphanStatus.includes('ឪពុក')
    );
    const orphanBothList = list.filter(
      (s) => s.orphanStatus && (s.orphanStatus.includes('កំព្រាឪពុកម្ដាយ') || s.orphanStatus.includes('ទាំងពីរ'))
    );

    return {
      total,
      totalFemale,
      ageList,
      disabled: {
        total: disabledTotal,
        female: disabledFemale,
        speech: { total: speechList.length, female: speechList.filter(isF).length },
        vision: { total: visionList.length, female: visionList.filter(isF).length },
        other: { total: otherDisabilityList.length, female: otherDisabilityList.filter(isF).length },
      },
      poor: {
        total: poorTotal,
        female: poorFemale,
        poor1: { total: poor1List.length, female: poor1List.filter(isF).length },
        poor2: { total: poor2List.length, female: poor2List.filter(isF).length },
        other: { total: poorOtherList.length, female: poorOtherList.filter(isF).length },
      },
      orphan: {
        total: orphanTotal,
        female: orphanFemale,
        father: { total: orphanFatherList.length, female: orphanFatherList.filter(isF).length },
        mother: { total: orphanMotherList.length, female: orphanMotherList.filter(isF).length },
        both: { total: orphanBothList.length, female: orphanBothList.filter(isF).length },
      },
    };
  }, [filteredStudents]);

  const generateSummaryText = () => {
    const lines: string[] = [];
    lines.push(`* សិស្សសរុប : ${statsSummary.total}នាក់ ស្រី ${statsSummary.totalFemale}នាក់`);
    statsSummary.ageList.forEach((item) => {
      lines.push(`- អាយុ ${item.age}ឆ្នាំ សរុប : ${item.total}នាក់ ស្រី ${item.female}នាក់`);
    });
    lines.push(`* សិស្សពិការ សរុប : ${statsSummary.disabled.total}នាក់ ស្រី ${statsSummary.disabled.female}នាក់`);
    lines.push(`- ពិបាកនិយាយ សរុប: ${statsSummary.disabled.speech.total}នាក់ ស្រី ${statsSummary.disabled.speech.female}នាក់`);
    lines.push(`- ពិបាកមើល សរុប : ${statsSummary.disabled.vision.total}នាក់ ស្រី ${statsSummary.disabled.vision.female}នាក់`);
    if (statsSummary.disabled.other.total > 0) {
      lines.push(`- ផ្សេងៗ សរុប : ${statsSummary.disabled.other.total}នាក់ ស្រី ${statsSummary.disabled.other.female}នាក់`);
    }
    lines.push(`* សិ្សមកពីក្រួសារក្រីក្រ សរុប : ${statsSummary.poor.total}នាក់ ស្រី ${statsSummary.poor.female}នាក់`);
    lines.push(`- ក្រ១ សរុប: ${statsSummary.poor.poor1.total}នាក់ ស្រី ${statsSummary.poor.poor1.female}នាក់`);
    lines.push(`- ក្រ២ សរុប : ${statsSummary.poor.poor2.total}នាក់ ស្រី ${statsSummary.poor.poor2.female}នាក់`);
    lines.push(`- ផ្សេងៗ សរុប : ${statsSummary.poor.other.total}នាក់ ស្រី ${statsSummary.poor.other.female}នាក់`);
    lines.push(`* សិស្សកំព្រា សរុប : ${statsSummary.orphan.total}នាក់ ស្រី ${statsSummary.orphan.female}នាក់`);
    lines.push(`- កំព្រាឪពុក សរុប: ${statsSummary.orphan.father.total}នាក់ ស្រី ${statsSummary.orphan.father.female}នាក់`);
    lines.push(`- កំព្រាម្ដាយ សរុប : ${statsSummary.orphan.mother.total}នាក់ ស្រី ${statsSummary.orphan.mother.female}នាក់`);
    lines.push(`- កំព្រាឪពុកម្ដាយ សរុប : ${statsSummary.orphan.both.total}នាក់ ស្រី ${statsSummary.orphan.both.female}នាក់`);
    return lines.join('\n');
  };

  const handleCopySummary = () => {
    navigator.clipboard.writeText(generateSummaryText());
    setCopiedSummary(true);
    setTimeout(() => setCopiedSummary(false), 2000);
  };

  // Selection handlers
  const handleSelectAll = () => {
    if (selectedIds.length === filteredStudents.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(filteredStudents.map((s) => s.id));
    }
  };

  const handleToggleSelect = (id: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleRowClick = (student: StudentRecord) => {
    setSelectedIds([student.id]);
  };

  const toggleGroup = (groupId: string) => {
    setVisibleGroupIds((prev) => ({
      ...prev,
      [groupId]: !prev[groupId],
    }));
  };

  const toggleAllGroups = (show: boolean) => {
    const updated: Record<string, boolean> = {};
    GROUPS.forEach((g) => {
      updated[g.id] = show;
    });
    setVisibleGroupIds(updated);
  };

  const handleExportExcel = (onlySelected = false) => {
    const listToExport = onlySelected
      ? students.filter((s) => selectedIds.includes(s.id))
      : filteredStudents;
    exportToExcel(listToExport, lang);
    setShowExportMenu(false);
  };

  const handleExportCsv = (onlySelected = false) => {
    const listToExport = onlySelected
      ? students.filter((s) => selectedIds.includes(s.id))
      : filteredStudents;
    exportToCsv(listToExport, lang);
    setShowExportMenu(false);
  };

  const activeGroups = useMemo(() => {
    return GROUPS.filter((g) => visibleGroupIds[g.id] !== false);
  }, [visibleGroupIds]);

  // Selected single student object
  const singleSelectedStudent = useMemo(() => {
    if (selectedIds.length === 1) {
      return students.find((s) => s.id === selectedIds[0]) || null;
    }
    return null;
  }, [selectedIds, students]);

  // Border and density classes
  const borderClass = borderContrast === 'bold' ? 'border-[#334155]' : 'border-[#64748b]';
  const cellPadding = density === 'ultra' ? 'py-0.5 px-1' : 'py-1 px-1.5';
  const headerPadding = density === 'ultra' ? 'py-0.5 px-1' : 'py-1 px-1.5';
  const fontSize = density === 'ultra' ? 'text-[11px]' : 'text-xs';

  return (
    <div
      className={`bg-white rounded-lg border-2 ${borderClass} shadow-xs overflow-hidden transition-all ${
        isFullscreen ? 'fixed inset-2 z-50 rounded-none' : ''
      }`}
    >
      {/* 1. Ultra-Compact Filter & Controls Bar */}
      <div className="p-2 border-b-2 border-slate-700 bg-slate-50 space-y-2 no-print">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-2">
          {/* Search Input */}
          <div className="relative flex-1 max-w-sm">
            <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder={
                lang === 'km'
                  ? 'ស្វែងរកសិស្ស (ឈ្មោះ, អត្តលេខ, ទីកន្លែង, ឪពុកម្ដាយ)...'
                  : 'Search by name, ID, address, parents...'
              }
              className="w-full pl-8 pr-6 py-1 text-xs bg-white border border-slate-400 rounded focus:outline-hidden focus:ring-1 focus:ring-blue-600"
            />
            {searchTerm && (
              <button
                onClick={() => setSearchTerm('')}
                className="absolute right-2 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                ✕
              </button>
            )}
          </div>

          {/* Action buttons & View adjustments */}
          <div className="flex items-center flex-wrap gap-1.5 text-xs">
            {/* Density Selector */}
            <div className="flex items-center border border-slate-400 rounded bg-white overflow-hidden">
              <button
                onClick={() => setDensity('ultra')}
                title="បន្ថយគម្លាតទទឹង កម្ពស់ តូចបំផុត"
                className={`px-2 py-0.5 font-medium transition-colors cursor-pointer ${
                  density === 'ultra'
                    ? 'bg-blue-700 text-white font-semibold'
                    : 'text-slate-700 hover:bg-slate-100'
                }`}
              >
                {lang === 'km' ? 'តូចបំផុត (Ultra)' : 'Ultra-Dense'}
              </button>
              <button
                onClick={() => setDensity('compact')}
                className={`px-2 py-0.5 font-medium transition-colors cursor-pointer ${
                  density === 'compact'
                    ? 'bg-blue-700 text-white font-semibold'
                    : 'text-slate-700 hover:bg-slate-100'
                }`}
              >
                {lang === 'km' ? 'ល្មម (Compact)' : 'Compact'}
              </button>
            </div>

            {/* Borderline Contrast Toggle */}
            <div className="flex items-center border border-slate-400 rounded bg-white overflow-hidden">
              <button
                onClick={() => setBorderContrast('bold')}
                title="បន្ទាត់ព្រំដែនដិតច្បាស់ខ្លាំង (High Contrast Borders)"
                className={`px-2 py-0.5 font-medium transition-colors cursor-pointer ${
                  borderContrast === 'bold'
                    ? 'bg-slate-800 text-white font-semibold'
                    : 'text-slate-700 hover:bg-slate-100'
                }`}
              >
                {lang === 'km' ? 'បន្ទាត់ដិតច្បាស់' : 'Bold Border'}
              </button>
              <button
                onClick={() => setBorderContrast('sharp')}
                className={`px-2 py-0.5 font-medium transition-colors cursor-pointer ${
                  borderContrast === 'sharp'
                    ? 'bg-slate-800 text-white font-semibold'
                    : 'text-slate-700 hover:bg-slate-100'
                }`}
              >
                {lang === 'km' ? 'បន្ទាត់ធម្មតា' : 'Clean'}
              </button>
            </div>

            {/* Column Groups Selector */}
            <div className="relative">
              <button
                onClick={() => setShowGroupSelector(!showGroupSelector)}
                className="flex items-center gap-1 px-2 py-1 text-slate-700 bg-white hover:bg-slate-100 border border-slate-400 rounded transition-colors cursor-pointer"
              >
                <SlidersHorizontal className="w-3 h-3 text-slate-600" />
                <span>{lang === 'km' ? 'ជួរឈរ (១៧ ផ្នែក)' : 'Columns'}</span>
                <ChevronDown className="w-3 h-3 text-slate-500" />
              </button>

              {showGroupSelector && (
                <div className="absolute right-0 mt-1 w-64 bg-white rounded-lg shadow-xl border-2 border-slate-600 p-2.5 z-40 max-h-80 overflow-y-auto">
                  <div className="flex items-center justify-between pb-1.5 mb-1.5 border-b border-slate-200">
                    <span className="text-xs font-bold text-slate-900">
                      {lang === 'km' ? 'បង្ហាញ / លាក់ផ្នែក' : 'Show / Hide Groups'}
                    </span>
                    <div className="flex items-center gap-2 text-[11px]">
                      <button
                        onClick={() => toggleAllGroups(true)}
                        className="text-blue-700 font-semibold hover:underline cursor-pointer"
                      >
                        {lang === 'km' ? 'ទាំងអស់' : 'All'}
                      </button>
                      <span>·</span>
                      <button
                        onClick={() => toggleAllGroups(false)}
                        className="text-slate-600 hover:underline cursor-pointer"
                      >
                        {lang === 'km' ? 'លាក់' : 'None'}
                      </button>
                    </div>
                  </div>
                  <div className="space-y-1">
                    {GROUPS.map((g) => (
                      <label
                        key={g.id}
                        className="flex items-center gap-1.5 text-[11px] text-slate-800 hover:bg-slate-100 p-1 rounded cursor-pointer select-none"
                      >
                        <input
                          type="checkbox"
                          checked={visibleGroupIds[g.id] !== false}
                          onChange={() => toggleGroup(g.id)}
                          className="rounded text-blue-600 focus:ring-blue-500 w-3 h-3 cursor-pointer"
                        />
                        <span className="truncate">
                          {lang === 'km' ? g.titleKm : g.titleEn}{' '}
                          <span className="text-slate-500 font-mono">({g.columns.length})</span>
                        </span>
                      </label>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Export Dropdown */}
            <div className="relative">
              <button
                onClick={() => setShowExportMenu(!showExportMenu)}
                className="flex items-center gap-1 px-2 py-1 text-slate-700 bg-white hover:bg-slate-100 border border-slate-400 rounded transition-colors cursor-pointer"
              >
                <Download className="w-3 h-3 text-slate-600" />
                <span>{lang === 'km' ? 'ទាញយក' : 'Export'}</span>
                <ChevronDown className="w-3 h-3 text-slate-500" />
              </button>

              {showExportMenu && (
                <div className="absolute right-0 mt-1 w-52 bg-white rounded-lg shadow-xl border-2 border-slate-600 py-1 z-40">
                  <button
                    onClick={() => handleExportExcel(false)}
                    className="w-full text-left px-3 py-1.5 text-xs text-slate-800 hover:bg-slate-100 flex items-center gap-1.5 cursor-pointer"
                  >
                    <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
                    <span>{lang === 'km' ? 'ទាញយកជា Excel (.xlsx)' : 'Export to Excel (.xlsx)'}</span>
                  </button>
                  <button
                    onClick={() => handleExportCsv(false)}
                    className="w-full text-left px-3 py-1.5 text-xs text-slate-800 hover:bg-slate-100 flex items-center gap-1.5 cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5 text-blue-600" />
                    <span>{lang === 'km' ? 'ទាញយកជា CSV (.csv)' : 'Export to CSV'}</span>
                  </button>
                  <div className="my-1 border-t border-slate-200" />
                  <button
                    onClick={() => downloadTemplate(lang)}
                    className="w-full text-left px-3 py-1.5 text-xs text-slate-800 hover:bg-slate-100 flex items-center gap-1.5 cursor-pointer"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                    <span>{lang === 'km' ? 'ទាញយកគំរូ Excel' : 'Download Template'}</span>
                  </button>
                </div>
              )}
            </div>

            {/* In-Table Edit Mode Toggle */}
            <button
              onClick={() => setIsInlineEditMode(!isInlineEditMode)}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-bold transition-all cursor-pointer ${
                isInlineEditMode
                  ? 'bg-amber-500 text-slate-950 border border-amber-600 shadow-xs'
                  : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-400'
              }`}
              title="បើក/បិទ ការកែសម្រួលផ្ទាល់ក្នុងតារាង និងរក្សាទុកស្វ័យប្រវត្តិ"
            >
              <Edit2 className="w-3.5 h-3.5" />
              <span>{lang === 'km' ? '✍️ កែក្នុងតារាង (Auto-Save)' : '✍️ Direct Edit (Auto-Save)'}</span>
              {isInlineEditMode && <span className="w-2 h-2 rounded-full bg-slate-950 animate-pulse"></span>}
            </button>

            {/* Recalculate All Button */}
            <button
              onClick={handleRecalculateAllClick}
              className="flex items-center gap-1 px-2.5 py-1 text-slate-800 bg-purple-50 hover:bg-purple-100 border border-purple-300 rounded transition-colors text-xs font-semibold cursor-pointer"
              title="គណនាស្វ័យប្រវត្តិនូវ អាយុ, BMI, ភ្នែក, ត្រចៀក សម្រាប់សិស្សទាំងអស់"
            >
              <Sparkles className="w-3.5 h-3.5 text-purple-700" />
              <span>{lang === 'km' ? '⚡ គណនាស្វ័យប្រវត្តិតាមរូបមន្ត' : '⚡ Auto-Calculate All'}</span>
            </button>

            {/* Auto-Save Live Badge */}
            {autoSaveStatus && (
              <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-100 border border-emerald-400 text-emerald-900 text-xs font-bold shadow-xs animate-in fade-in duration-150">
                <span className="w-2 h-2 rounded-full bg-emerald-600 animate-ping"></span>
                <span>{autoSaveStatus}</span>
              </div>
            )}

            {/* Import Button */}
            <button
              onClick={onOpenImportModal}
              className="flex items-center gap-1 px-2 py-1 text-slate-700 bg-white hover:bg-slate-100 border border-slate-400 rounded transition-colors cursor-pointer"
              title="Import Excel or CSV data"
            >
              <Upload className="w-3 h-3 text-slate-600" />
              <span>{lang === 'km' ? 'នាំចូល' : 'Import'}</span>
            </button>

            {/* Print Button */}
            <button
              onClick={() => window.print()}
              className="flex items-center gap-1 px-2 py-1 text-slate-700 bg-white hover:bg-slate-100 border border-slate-400 rounded transition-colors cursor-pointer"
              title="Print table"
            >
              <Printer className="w-3 h-3 text-slate-600" />
              <span>{lang === 'km' ? 'បោះពុម្ព' : 'Print'}</span>
            </button>

            {/* Fullscreen Toggle */}
            <button
              onClick={() => setIsFullscreen(!isFullscreen)}
              className="p-1 text-slate-700 bg-white hover:bg-slate-100 border border-slate-400 rounded transition-colors cursor-pointer"
              title={isFullscreen ? 'ចេញពីទំហំធំ' : 'ពង្រីកពេញអេក្រង់'}
            >
              {isFullscreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
            </button>

            {/* Reset Button */}
            <button
              onClick={onResetData}
              className="p-1 text-slate-500 hover:text-slate-800 bg-white hover:bg-slate-100 border border-slate-400 rounded transition-colors cursor-pointer"
              title="Reset to default sample data"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Enhanced Multi-Filter Bar: Gender, Grade, Age, Disability, IDPoor, Orphan, BMI, Sensory */}
        <div className="p-2 bg-slate-50 border border-slate-300 rounded-lg flex items-center flex-wrap gap-2 text-xs text-slate-700">
          {/* Gender Filter */}
          <div className="flex items-center border border-slate-400 rounded bg-white overflow-hidden shadow-2xs">
            <button
              onClick={() => setGenderFilter('all')}
              className={`px-2 py-0.5 cursor-pointer ${
                genderFilter === 'all' ? 'bg-slate-800 text-white font-semibold' : 'hover:bg-slate-100'
              }`}
            >
              {lang === 'km' ? 'ភេទទាំងអស់' : 'All'}
            </button>
            <button
              onClick={() => setGenderFilter('ស្រី')}
              className={`px-2 py-0.5 cursor-pointer ${
                genderFilter === 'ស្រី' ? 'bg-pink-700 text-white font-semibold' : 'hover:bg-slate-100'
              }`}
            >
              {lang === 'km' ? 'ស្រី' : 'F'}
            </button>
            <button
              onClick={() => setGenderFilter('ប្រុស')}
              className={`px-2 py-0.5 cursor-pointer ${
                genderFilter === 'ប្រុស' ? 'bg-blue-700 text-white font-semibold' : 'hover:bg-slate-100'
              }`}
            >
              {lang === 'km' ? 'ប្រុស' : 'M'}
            </button>
          </div>

          {/* Grade Filter */}
          {distinctGrades.length > 0 && (
            <div className="flex items-center gap-1">
              <span className="text-slate-600 font-medium">{lang === 'km' ? 'ថ្នាក់៖' : 'Grade:'}</span>
              <select
                value={gradeFilter}
                onChange={(e) => setGradeFilter(e.target.value)}
                className="bg-white border border-slate-400 rounded px-1.5 py-0.5 text-xs text-slate-800 focus:outline-hidden cursor-pointer"
              >
                <option value="all">{lang === 'km' ? 'ទាំងអស់' : 'All'}</option>
                {distinctGrades.map((g) => (
                  <option key={g} value={g}>
                    {g}
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* Age Filter */}
          <div className="flex items-center gap-1">
            <span className="text-slate-600 font-medium">{lang === 'km' ? 'អាយុ៖' : 'Age:'}</span>
            <select
              value={ageFilter}
              onChange={(e) => setAgeFilter(e.target.value)}
              className="bg-white border border-slate-400 rounded px-1.5 py-0.5 text-xs text-slate-800 focus:outline-hidden cursor-pointer"
            >
              <option value="all">{lang === 'km' ? 'គ្រប់អាយុ' : 'All Ages'}</option>
              <option value="6">6 ឆ្នាំ</option>
              <option value="7">7 ឆ្នាំ</option>
              <option value="8">8 ឆ្នាំ</option>
              <option value="9">9 ឆ្នាំ</option>
              <option value="10">10 ឆ្នាំ</option>
              <option value="11">11 ឆ្នាំ</option>
              <option value="12+">12+ ឆ្នាំ</option>
            </select>
          </div>

          {/* Disability Filter */}
          <div className="flex items-center gap-1">
            <span className="text-slate-600 font-medium">{lang === 'km' ? 'ពិការភាព៖' : 'Disability:'}</span>
            <select
              value={disabilityFilter}
              onChange={(e) => setDisabilityFilter(e.target.value)}
              className="bg-white border border-slate-400 rounded px-1.5 py-0.5 text-xs text-purple-900 font-medium focus:outline-hidden cursor-pointer"
            >
              <option value="all">{lang === 'km' ? 'ទាំងអស់' : 'All'}</option>
              <option value="disabled">{lang === 'km' ? 'សិស្សពិការទាំងអស់' : 'All Disabled'}</option>
              <option value="speech">{lang === 'km' ? 'ពិបាកនិយាយ' : 'Speech'}</option>
              <option value="vision">{lang === 'km' ? 'ពិបាកមើល' : 'Vision'}</option>
              <option value="hearing">{lang === 'km' ? 'ពិបាកស្ដាប់' : 'Hearing'}</option>
              <option value="walking">{lang === 'km' ? 'ពិបាកដើរ' : 'Walking'}</option>
            </select>
          </div>

          {/* Equity / IDPoor Filter */}
          <div className="flex items-center gap-1">
            <span className="text-slate-600 font-medium">{lang === 'km' ? 'សមធម៌៖' : 'Equity:'}</span>
            <select
              value={equityFilter}
              onChange={(e) => setEquityFilter(e.target.value)}
              className="bg-white border border-slate-400 rounded px-1.5 py-0.5 text-xs text-amber-900 font-medium focus:outline-hidden cursor-pointer"
            >
              <option value="all">{lang === 'km' ? 'ទាំងអស់' : 'All'}</option>
              <option value="poor">{lang === 'km' ? 'ក្រីក្រ (ក្រ១ & ក្រ២)' : 'IDPoor 1 & 2'}</option>
              <option value="poor1">{lang === 'km' ? 'ក្រ១' : 'Poor 1'}</option>
              <option value="poor2">{lang === 'km' ? 'ក្រ២' : 'Poor 2'}</option>
              <option value="non_poor">{lang === 'km' ? 'មិនក្រីក្រ' : 'Non-Poor'}</option>
            </select>
          </div>

          {/* Orphan Filter */}
          <div className="flex items-center gap-1">
            <span className="text-slate-600 font-medium">{lang === 'km' ? 'កំព្រា៖' : 'Orphan:'}</span>
            <select
              value={orphanFilter}
              onChange={(e) => setOrphanFilter(e.target.value)}
              className="bg-white border border-slate-400 rounded px-1.5 py-0.5 text-xs text-rose-900 font-medium focus:outline-hidden cursor-pointer"
            >
              <option value="all">{lang === 'km' ? 'ទាំងអស់' : 'All'}</option>
              <option value="orphan">{lang === 'km' ? 'សិស្សកំព្រាទាំងអស់' : 'All Orphans'}</option>
              <option value="father">{lang === 'km' ? 'កំព្រាឪពុក' : 'Fatherless'}</option>
              <option value="mother">{lang === 'km' ? 'កំព្រាម្ដាយ' : 'Motherless'}</option>
              <option value="both">{lang === 'km' ? 'កំព្រាឪពុកម្ដាយ' : 'Both Parents'}</option>
              <option value="non_orphan">{lang === 'km' ? 'មិនកំព្រា' : 'Non-Orphan'}</option>
            </select>
          </div>

          {/* BMI / Nutrition Filter */}
          <div className="flex items-center gap-1">
            <span className="text-slate-600 font-medium">{lang === 'km' ? 'BMI៖' : 'BMI:'}</span>
            <select
              value={nutritionFilter}
              onChange={(e) => setNutritionFilter(e.target.value)}
              className="bg-white border border-slate-400 rounded px-1.5 py-0.5 text-xs text-blue-900 font-medium focus:outline-hidden cursor-pointer"
            >
              <option value="all">{lang === 'km' ? 'គ្រប់ទម្ងន់' : 'All Status'}</option>
              <option value="ស្គមខ្លាំង">{lang === 'km' ? 'ស្គមខ្លាំង' : 'Severely Under'}</option>
              <option value="ស្គម">{lang === 'km' ? 'ស្គម' : 'Underweight'}</option>
              <option value="ទម្ងន់ធម្មតា">{lang === 'km' ? 'ទម្ងន់ធម្មតា' : 'Normal'}</option>
              <option value="លើសទម្ងន់">{lang === 'km' ? 'លើសទម្ងន់' : 'Overweight'}</option>
              <option value="ធាត់">{lang === 'km' ? 'ធាត់' : 'Obese'}</option>
            </select>
          </div>

          {/* Sensory Filter (Eyes / Ears) */}
          <div className="flex items-center gap-1">
            <span className="text-slate-600 font-medium">{lang === 'km' ? 'ពិនិត្យសុខភាព៖' : 'Sensory:'}</span>
            <select
              value={sensoryFilter}
              onChange={(e) => setSensoryFilter(e.target.value)}
              className="bg-white border border-slate-400 rounded px-1.5 py-0.5 text-xs text-slate-800 focus:outline-hidden cursor-pointer"
            >
              <option value="all">{lang === 'km' ? 'ទាំងអស់' : 'All'}</option>
              <option value="eye">{lang === 'km' ? 'ខ្សោយគំហើញ (ភ្នែក)' : 'Vision Impaired'}</option>
              <option value="ear">{lang === 'km' ? 'ខ្សោយការស្ដាប់ (ត្រចៀក)' : 'Hearing Impaired'}</option>
            </select>
          </div>

          {/* Reset All Filters Button */}
          {(searchTerm || genderFilter !== 'all' || gradeFilter !== 'all' || equityFilter !== 'all' || orphanFilter !== 'all' || disabilityFilter !== 'all' || ageFilter !== 'all' || nutritionFilter !== 'all' || sensoryFilter !== 'all') && (
            <button
              onClick={handleResetFilters}
              className="inline-flex items-center gap-1 px-2 py-0.5 text-xs font-semibold bg-rose-50 text-rose-700 hover:bg-rose-100 border border-rose-300 rounded cursor-pointer transition-colors"
            >
              <X className="w-3 h-3" />
              <span>{lang === 'km' ? 'សម្អាតចម្រោះ' : 'Clear'}</span>
            </button>
          )}
        </div>

        {/* 2. DEDICATED ACTION BAR FOR SELECTED ROW(S) (ខាងក្រៅតារាង គ្របដណ្ដប់លើជួរដេកដែលបានជ្រើស) */}
        {selectedIds.length > 0 && (
          <div className="p-2 bg-gradient-to-r from-blue-50 to-indigo-50 border-2 border-blue-500 rounded-lg flex flex-wrap items-center justify-between gap-2 shadow-sm animate-in fade-in duration-150">
            {/* If Single Student Selected */}
            {singleSelectedStudent ? (
              <div className="flex items-center gap-2 text-xs">
                <div className="w-5 h-5 rounded-full bg-blue-700 text-white flex items-center justify-center font-bold text-[10px]">
                  ✓
                </div>
                <div className="text-slate-900">
                  <span className="text-slate-500 mr-1">{lang === 'km' ? 'សិស្សបានជ្រើស៖' : 'Selected:'}</span>
                  <strong className="text-blue-900 font-bold text-sm">
                    {singleSelectedStudent.lastName} {singleSelectedStudent.firstName}
                  </strong>{' '}
                  <span className="text-slate-600 font-mono">({singleSelectedStudent.studentCode || 'N/A'})</span>
                  <span className="mx-1.5 text-slate-400">·</span>
                  <span className={singleSelectedStudent.gender === 'ស្រី' ? 'text-pink-700 font-semibold' : 'text-blue-700 font-semibold'}>
                    {singleSelectedStudent.gender}
                  </span>
                  {singleSelectedStudent.previousGrade && (
                    <>
                      <span className="mx-1.5 text-slate-400">·</span>
                      <span className="text-slate-700 font-medium">ថ្នាក់ {singleSelectedStudent.previousGrade}</span>
                    </>
                  )}
                </div>
              </div>
            ) : (
              /* If Multiple Students Selected */
              <div className="flex items-center gap-2 text-xs text-blue-950 font-semibold">
                <CheckSquare className="w-4 h-4 text-blue-700" />
                <span>
                  {lang === 'km' ? 'បានជ្រើសរើសសរុប៖' : 'Selected Total:'}{' '}
                  <strong className="font-mono text-sm text-blue-900 tabular-nums">{selectedIds.length}</strong>{' '}
                  {lang === 'km' ? 'នាក់' : 'students'}
                </span>
              </div>
            )}

            {/* ACTION BUTTONS (មើល, កែ, លុប, បោះពុម្ព, បោះបង់) */}
            <div className="flex items-center gap-1.5">
              {singleSelectedStudent && (
                <>
                  <button
                    onClick={() => onViewStudent(singleSelectedStudent)}
                    className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded transition-colors shadow-2xs cursor-pointer"
                    title="មើលព័ត៌មានលម្អិតសិស្ស"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>{lang === 'km' ? 'មើលជីវប្រវត្តិ' : 'View Dossier'}</span>
                  </button>

                  <button
                    onClick={() => onEditStudent(singleSelectedStudent)}
                    className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold text-white bg-amber-600 hover:bg-amber-700 rounded transition-colors shadow-2xs cursor-pointer"
                    title="កែប្រែព័ត៌មានសិស្ស"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                    <span>{lang === 'km' ? 'កែប្រែ' : 'Edit'}</span>
                  </button>

                  <button
                    onClick={() => onViewStudent(singleSelectedStudent)}
                    className="inline-flex items-center gap-1 px-2 py-1 text-xs font-medium text-slate-800 bg-white hover:bg-slate-100 border border-slate-300 rounded transition-colors cursor-pointer"
                    title="បោះពុម្ពសន្លឹកជីវប្រវត្តិ"
                  >
                    <Printer className="w-3.5 h-3.5 text-slate-600" />
                    <span>{lang === 'km' ? 'បោះពុម្ព' : 'Print'}</span>
                  </button>
                </>
              )}

              {/* Batch Actions for Multiple */}
              {selectedIds.length > 1 && (
                <button
                  onClick={() => handleExportExcel(true)}
                  className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold text-slate-800 bg-white hover:bg-slate-100 border border-slate-300 rounded transition-colors cursor-pointer"
                >
                  <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{lang === 'km' ? 'ទាញយក Excel' : 'Export Excel'}</span>
                </button>
              )}

              {/* Delete Button */}
              <button
                onClick={() => {
                  if (singleSelectedStudent) {
                    if (
                      confirm(
                        lang === 'km'
                          ? `តើអ្នកប្រាកដថាលុបសិស្ស ${singleSelectedStudent.lastName} ${singleSelectedStudent.firstName} មែនទេ?`
                          : `Are you sure you want to delete ${singleSelectedStudent.lastName} ${singleSelectedStudent.firstName}?`
                      )
                    ) {
                      onDeleteStudent(singleSelectedStudent.id);
                      setSelectedIds([]);
                    }
                  } else {
                    if (
                      confirm(
                        lang === 'km'
                          ? `តើអ្នកប្រាកដថាលុបសិស្សទាំង ${selectedIds.length} នាក់នេះមែនទេ?`
                          : `Delete ${selectedIds.length} selected students?`
                      )
                    ) {
                      onDeleteMultiple(selectedIds);
                      setSelectedIds([]);
                    }
                  }
                }}
                className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold text-white bg-red-600 hover:bg-red-700 rounded transition-colors shadow-2xs cursor-pointer"
                title="លុបចេញពីប្រព័ន្ធ"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>
                  {singleSelectedStudent
                    ? lang === 'km'
                      ? 'លុបសិស្ស'
                      : 'Delete'
                    : lang === 'km'
                    ? `លុបទាំង (${selectedIds.length})`
                    : `Delete (${selectedIds.length})`}
                </span>
              </button>

              {/* Deselect / Cancel */}
              <button
                onClick={() => setSelectedIds([])}
                className="p-1 text-slate-500 hover:text-slate-800 hover:bg-slate-200/60 rounded transition-colors cursor-pointer"
                title="ដោះជម្រើស"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* 3. Main Scrollable Table with Fixed Core Columns on LEFT of Solid RED VERTICAL LINE */}
      <div
        className={`table-container overflow-x-auto custom-scrollbar relative ${
          isFullscreen ? 'max-h-[calc(100vh-140px)]' : 'max-h-[calc(100vh-270px)]'
        }`}
      >
        <table className={`min-w-full border-collapse ${fontSize} text-center sis-compact-table`}>
          {/* Tier 1 Header: Group Headers */}
          <thead className="sticky top-0 z-20 font-bold bg-slate-200 text-slate-900 select-none">
            <tr className="border-b-2 border-slate-700">
              {/* Sticky Columns Master Group Header (Covering: Checkbox, #, ID, Name, Gender)
                  Total Width: 24 + 26 + 48 + 92 + 38 = 228px.
                  Bounded on right with prominent RED line! */}
              <th
                colSpan={5}
                style={{ width: '228px', minWidth: '228px', maxWidth: '228px', left: 0 }}
                className={`sticky left-0 z-30 bg-slate-300 text-slate-950 text-center border-b-2 border-slate-700 border-r-[3.5px] border-red-600 shadow-[1px_0_0_0_#dc2626] ${headerPadding}`}
              >
                {lang === 'km' ? 'ព័ត៌មានស្នូលសិស្ស (ជាប់ខាងឆ្វេង)' : 'Core Student ID & Gender'}
              </th>

              {/* Dynamic Group Headers for all other 16 Groups */}
              {activeGroups.map((group) => {
                const displayColCount =
                  group.id === 'student_info'
                    ? group.columns.filter(
                        (c) => !['studentCode', 'lastName', 'firstName', 'gender'].includes(c.id)
                      ).length
                    : group.columns.length;

                if (displayColCount === 0) return null;

                return (
                  <th
                    key={group.id}
                    colSpan={displayColCount}
                    className={`border-r border-b-2 border-slate-600 bg-slate-200 text-slate-900 whitespace-nowrap ${headerPadding}`}
                  >
                    {lang === 'km' ? group.titleKm : group.titleEn}
                  </th>
                );
              })}
            </tr>

            {/* Tier 2 Header: Individual Column Headers */}
            <tr className="bg-slate-100 text-slate-900 font-semibold border-b-2 border-slate-600">
              {/* Sticky Col 1: Select Checkbox (Width: 24px, Left: 0) */}
              <th
                style={{ width: '24px', minWidth: '24px', maxWidth: '24px', left: 0 }}
                className={`sticky left-0 z-30 bg-slate-200 text-center border-r border-slate-500 ${headerPadding}`}
              >
                <button
                  onClick={handleSelectAll}
                  className="cursor-pointer text-slate-700 hover:text-black inline-flex items-center justify-center"
                  title="ជ្រើសទាំងអស់"
                >
                  {selectedIds.length === filteredStudents.length && filteredStudents.length > 0 ? (
                    <CheckSquare className="w-3.5 h-3.5 text-blue-700" />
                  ) : (
                    <Square className="w-3.5 h-3.5" />
                  )}
                </button>
              </th>

              {/* Sticky Col 2: Index (Width: 26px, Left: 24px) */}
              <th
                style={{ width: '26px', minWidth: '26px', maxWidth: '26px', left: '24px' }}
                className={`sticky left-[24px] z-30 bg-slate-200 text-center border-r border-slate-500 font-mono ${headerPadding}`}
              >
                #
              </th>

              {/* Sticky Col 3: Student ID (Width: 48px, Left: 50px) */}
              <th
                style={{ width: '48px', minWidth: '48px', maxWidth: '48px', left: '50px' }}
                className={`sticky left-[50px] z-30 bg-slate-200 text-center border-r border-slate-500 font-mono ${headerPadding}`}
              >
                {lang === 'km' ? 'អត្តលេខ' : 'ID'}
              </th>

              {/* Sticky Col 4: Full Name (Width: 92px, Left: 98px) */}
              <th
                style={{ width: '92px', minWidth: '92px', maxWidth: '92px', left: '98px' }}
                className={`sticky left-[98px] z-30 bg-slate-200 text-left border-r border-slate-500 truncate ${headerPadding}`}
              >
                {lang === 'km' ? 'គោត្តនាម នាម' : 'Full Name'}
              </th>

              {/* Sticky Col 5: Gender (Width: 38px, Left: 190px)
                  THIS IS ON THE LEFT SIDE OF THE RED VERTICAL LINE! */}
              <th
                style={{ width: '38px', minWidth: '38px', maxWidth: '38px', left: '190px' }}
                className={`sticky left-[190px] z-30 bg-slate-200 text-center border-r-[3.5px] border-red-600 shadow-[1px_0_0_0_#dc2626] text-red-950 font-bold ${headerPadding}`}
              >
                {lang === 'km' ? 'ភេទ' : 'Gender'}
              </th>

              {/* Remaining 60 Columns from Active Groups (All on RIGHT side of RED LINE) */}
              {activeGroups.map((group) => {
                return group.columns.map((col) => {
                  if (
                    group.id === 'student_info' &&
                    ['studentCode', 'lastName', 'firstName', 'gender'].includes(col.id)
                  ) {
                    return null;
                  }

                  return (
                    <th
                      key={col.id}
                      className={`border-r border-slate-500 whitespace-nowrap min-w-[3.75rem] text-slate-800 ${headerPadding}`}
                      title={lang === 'km' ? `${group.titleKm} - ${col.labelKm}` : `${group.titleEn} - ${col.labelEn}`}
                    >
                      {lang === 'km' ? col.labelKm : col.labelEn}
                    </th>
                  );
                });
              })}
            </tr>
          </thead>

          {/* Table Body */}
          <tbody className="divide-y divide-slate-400">
            {filteredStudents.length === 0 ? (
              <tr>
                <td
                  colSpan={65}
                  className="px-4 py-8 text-center text-slate-500 bg-white"
                >
                  <p className="font-semibold text-xs text-slate-700">
                    {lang === 'km' ? 'រកមិនឃើញទិន្នន័យសិស្សទេ' : 'No student records found'}
                  </p>
                </td>
              </tr>
            ) : (
              filteredStudents.map((student, idx) => {
                const isSelected = selectedIds.includes(student.id);
                const isFemale =
                  student.gender === 'ស្រី' ||
                  student.gender.toLowerCase() === 'female' ||
                  student.gender === 'f';
                const rowBg = isSelected
                  ? 'bg-blue-100 ring-1 ring-blue-500 ring-inset'
                  : idx % 2 === 1
                  ? 'bg-slate-50'
                  : 'bg-white';

                return (
                  <tr
                    key={student.id}
                    onClick={() => handleRowClick(student)}
                    onDoubleClick={() => onViewStudent(student)}
                    className={`hover:bg-slate-200/80 transition-colors cursor-pointer select-none ${rowBg}`}
                  >
                    {/* Sticky 1: Select Checkbox (Left: 0, Width: 24px) */}
                    <td
                      style={{ width: '24px', minWidth: '24px', maxWidth: '24px', left: 0 }}
                      className={`sticky left-0 z-10 bg-inherit text-center border-r border-slate-500 ${cellPadding}`}
                      onClick={(e) => handleToggleSelect(student.id, e)}
                    >
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={(e) => handleToggleSelect(student.id, e as any)}
                        className="rounded text-blue-600 focus:ring-blue-500 w-3 h-3 cursor-pointer"
                      />
                    </td>

                    {/* Sticky 2: Index (Left: 24px, Width: 26px) */}
                    <td
                      style={{ width: '26px', minWidth: '26px', maxWidth: '26px', left: '24px' }}
                      className={`sticky left-[24px] z-10 bg-inherit text-center border-r border-slate-500 font-mono tabular-nums text-slate-600 ${cellPadding}`}
                    >
                      {idx + 1}
                    </td>

                    {/* Sticky 3: Student ID (Left: 50px, Width: 48px) */}
                    <td
                      style={{ width: '48px', minWidth: '48px', maxWidth: '48px', left: '50px' }}
                      className={`sticky left-[50px] z-10 bg-inherit text-center border-r border-slate-500 font-mono font-bold text-slate-900 ${cellPadding}`}
                    >
                      {isInlineEditMode ? (
                        <input
                          type="text"
                          value={student.studentCode || ''}
                          onChange={(e) => handleCellChange(student, 'studentCode', e.target.value)}
                          className="w-full bg-transparent hover:bg-yellow-100/60 focus:bg-white focus:ring-1 focus:ring-blue-600 focus:outline-hidden font-mono font-bold text-center text-xs"
                          title="អត្តលេខ"
                        />
                      ) : (
                        student.studentCode || '—'
                      )}
                    </td>

                    {/* Sticky 4: Full Name (Left: 98px, Width: 92px) */}
                    <td
                      style={{ width: '92px', minWidth: '92px', maxWidth: '92px', left: '98px' }}
                      className={`sticky left-[98px] z-10 bg-inherit text-left border-r border-slate-500 whitespace-nowrap truncate ${cellPadding}`}
                    >
                      {isInlineEditMode ? (
                        <div className="flex items-center gap-0.5">
                          <input
                            type="text"
                            value={student.lastName || ''}
                            onChange={(e) => handleCellChange(student, 'lastName', e.target.value)}
                            placeholder="ត្រកូល"
                            className="w-1/2 bg-transparent hover:bg-yellow-100/60 focus:bg-white focus:ring-1 focus:ring-blue-600 focus:outline-hidden font-bold text-blue-900 text-xs px-0.5 rounded truncate"
                            title="គោត្តនាម"
                          />
                          <input
                            type="text"
                            value={student.firstName || ''}
                            onChange={(e) => handleCellChange(student, 'firstName', e.target.value)}
                            placeholder="ឈ្មោះ"
                            className="w-1/2 bg-transparent hover:bg-yellow-100/60 focus:bg-white focus:ring-1 focus:ring-blue-600 focus:outline-hidden font-bold text-blue-900 text-xs px-0.5 rounded truncate"
                            title="នាម"
                          />
                        </div>
                      ) : (
                        <span
                          className="text-blue-900 font-bold hover:underline truncate block"
                          title={`${student.lastName} ${student.firstName}`}
                        >
                          {student.lastName} {student.firstName}
                        </span>
                      )}
                    </td>

                    {/* Sticky 5: Gender (Left: 190px, Width: 38px)
                        ON LEFT OF SOLID RED VERTICAL LINE! */}
                    <td
                      style={{ width: '38px', minWidth: '38px', maxWidth: '38px', left: '190px' }}
                      className={`sticky left-[190px] z-10 bg-inherit text-center border-r-[3.5px] border-red-600 shadow-[1px_0_0_0_#dc2626] font-bold ${cellPadding}`}
                    >
                      {isInlineEditMode ? (
                        <select
                          value={student.gender || 'ប្រុស'}
                          onChange={(e) => handleCellChange(student, 'gender', e.target.value)}
                          className={`bg-transparent hover:bg-yellow-100/60 focus:bg-white focus:ring-1 focus:ring-blue-600 focus:outline-hidden font-bold text-center text-xs cursor-pointer ${
                            isFemale ? 'text-pink-700' : 'text-blue-700'
                          }`}
                        >
                          <option value="ស្រី">ស្រី</option>
                          <option value="ប្រុស">ប្រុស</option>
                        </select>
                      ) : (
                        <span className={isFemale ? 'text-pink-700' : 'text-blue-700'}>
                          {student.gender}
                        </span>
                      )}
                    </td>

                    {/* Remaining 60 Columns (All scroll freely on the right of the RED LINE) */}
                    {activeGroups.map((group) => {
                      return group.columns.map((col) => {
                        if (
                          group.id === 'student_info' &&
                          ['studentCode', 'lastName', 'firstName', 'gender'].includes(col.id)
                        ) {
                          return null;
                        }

                        const rawValue = (student[col.key] as string) || '';
                        let displayVal = rawValue;
                        if (col.id === 'age') {
                          displayVal = student.age ? String(student.age) : (calculateAge(student.dob) ? String(calculateAge(student.dob)) : '');
                        } else if (col.id === 'orphanStatus' && !displayVal) {
                          displayVal = 'មិនកំព្រា';
                        }

                        const isNumeric = col.type === 'number';

                        // Specialized inline editors
                        return (
                          <td
                            key={col.id}
                            className={`border-r border-slate-500 whitespace-nowrap text-slate-800 ${cellPadding} ${
                              isNumeric ? 'text-right font-mono tabular-nums font-medium' : 'text-center'
                            }`}
                            title={displayVal || rawValue}
                          >
                            {isInlineEditMode ? (
                              col.id === 'age' ? (
                                <span className="font-mono font-bold text-purple-800 bg-purple-50 px-1 py-0.5 rounded border border-purple-200">
                                  {displayVal || '—'}
                                </span>
                              ) : col.id === 'dob' ? (
                                <input
                                  type="text"
                                  value={student.dob || ''}
                                  onChange={(e) => handleCellChange(student, 'dob', e.target.value)}
                                  placeholder="ថ្ងៃ-ខែ-ឆ្នាំ"
                                  className="w-full bg-transparent hover:bg-yellow-100/60 focus:bg-white focus:ring-1 focus:ring-blue-600 focus:outline-hidden font-mono text-center text-xs px-0.5 rounded"
                                  title="ថ្ងៃខែឆ្នាំកំណើត (គណនាអាយុស្វ័យប្រវត្តិ)"
                                />
                              ) : col.id === 'disabilityType' ? (
                                <select
                                  value={student.disabilityType || 'គ្មាន'}
                                  onChange={(e) => handleCellChange(student, 'disabilityType', e.target.value)}
                                  className="bg-transparent hover:bg-yellow-100/60 focus:bg-white focus:ring-1 focus:ring-blue-600 focus:outline-hidden text-xs text-purple-900 font-semibold cursor-pointer px-0.5 rounded"
                                >
                                  <option value="គ្មាន">គ្មាន</option>
                                  <option value="ពិបាកនិយាយ">ពិបាកនិយាយ</option>
                                  <option value="ពិបាកមើល">ពិបាកមើល</option>
                                  <option value="ពិបាកស្ដាប់">ពិបាកស្ដាប់</option>
                                  <option value="ពិបាកដើរ">ពិបាកដើរ</option>
                                  <option value="ពិការជើង">ពិការជើង</option>
                                  <option value="ពិការដៃ">ពិការដៃ</option>
                                </select>
                              ) : col.id === 'equityFamily' ? (
                                <select
                                  value={student.equityFamily || 'មិនក្រ'}
                                  onChange={(e) => handleCellChange(student, 'equityFamily', e.target.value)}
                                  className="bg-transparent hover:bg-yellow-100/60 focus:bg-white focus:ring-1 focus:ring-blue-600 focus:outline-hidden text-xs text-amber-900 font-semibold cursor-pointer px-0.5 rounded"
                                >
                                  <option value="មិនក្រ">មិនក្រ</option>
                                  <option value="ក្រ១">ក្រ១</option>
                                  <option value="ក្រ២">ក្រ២</option>
                                  <option value="ផ្សេងៗ">ផ្សេងៗ</option>
                                </select>
                              ) : col.id === 'orphanStatus' ? (
                                <select
                                  value={student.orphanStatus || 'មិនកំព្រា'}
                                  onChange={(e) => handleCellChange(student, 'orphanStatus', e.target.value)}
                                  className="bg-transparent hover:bg-yellow-100/60 focus:bg-white focus:ring-1 focus:ring-blue-600 focus:outline-hidden text-xs text-rose-900 font-semibold cursor-pointer px-0.5 rounded"
                                >
                                  <option value="មិនកំព្រា">មិនកំព្រា</option>
                                  <option value="កំព្រាឪពុក">កំព្រាឪពុក</option>
                                  <option value="កំព្រាម្ដាយ">កំព្រាម្ដាយ</option>
                                  <option value="កំព្រាឪពុកម្ដាយ">កំព្រាឪពុកម្ដាយ</option>
                                </select>
                              ) : col.id === 'weightSem1' || col.id === 'heightSem1' || col.id === 'weightSem2' || col.id === 'heightSem2' ? (
                                <input
                                  type="text"
                                  value={(student[col.key] as string) || ''}
                                  onChange={(e) => handleCellChange(student, col.key, e.target.value)}
                                  placeholder="0"
                                  className="w-full bg-transparent hover:bg-yellow-100/60 focus:bg-white focus:ring-1 focus:ring-blue-600 focus:outline-hidden font-mono text-center text-xs px-0.5 rounded"
                                  title="កម្ពស់/ទម្ងន់ (គណនា BMI ស្វ័យប្រវត្តិ)"
                                />
                              ) : col.id === 'bmiStatusSem1' || col.id === 'bmiStatusSem2' ? (
                                <span className={`text-[11px] font-bold px-1 rounded ${
                                  (student[col.key] as string) === 'ទម្ងន់ធម្មតា' ? 'bg-emerald-100 text-emerald-800' :
                                  (student[col.key] as string) ? 'bg-amber-100 text-amber-800' : 'text-slate-400'
                                }`}>
                                  {(student[col.key] as string) || '—'}
                                </span>
                              ) : col.id === 'eyeResult' || col.id === 'earResult' ? (
                                <span className={`text-[11px] font-bold px-1 rounded ${
                                  ((student[col.key] as string) || '').includes('ខ្សោយ') ? 'bg-rose-100 text-rose-800' :
                                  (student[col.key] as string) ? 'bg-emerald-100 text-emerald-800' : 'text-slate-400'
                                }`}>
                                  {(student[col.key] as string) || '—'}
                                </span>
                              ) : (
                                <input
                                  type="text"
                                  value={(student[col.key] as string) || ''}
                                  onChange={(e) => handleCellChange(student, col.key, e.target.value)}
                                  placeholder="—"
                                  className="w-full bg-transparent hover:bg-yellow-100/60 focus:bg-white focus:ring-1 focus:ring-blue-600 focus:outline-hidden text-center text-xs px-0.5 rounded truncate"
                                />
                              )
                            ) : (
                              displayVal || <span className="text-slate-300 font-mono">—</span>
                            )}
                          </td>
                        );
                      });
                    })}
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* 4. Compact Footer with Instructions & Status */}
      <div className="px-3 py-1.5 border-t-2 border-slate-700 bg-slate-100 flex flex-wrap items-center justify-between text-[11px] text-slate-700 font-medium gap-2">
        <div className="flex items-center gap-2">
          <span>
            {lang === 'km' ? 'សរុប៖' : 'Total:'}{' '}
            <strong className="text-slate-900 font-mono tabular-nums">{filteredStudents.length}</strong>{' '}
            {lang === 'km' ? 'នាក់' : 'students'}
          </span>
          <span>·</span>
          <span>
            {lang === 'km' ? 'ផ្នែកសកម្ម៖' : 'Active:'}{' '}
            <strong className="text-slate-900 font-mono tabular-nums">
              {activeGroups.length} / {GROUPS.length}
            </strong>
          </span>
          <span>·</span>
          <span className="text-slate-500 hidden sm:inline">
            {lang === 'km' ? 'ចុចលើជួរដេកដើម្បីជ្រើសរើស · ចុចពីរដងដើម្បីមើលជីវប្រវត្តិ' : 'Click row to select · Double-click to view'}
          </span>
        </div>

        <div className="flex items-center gap-2 text-slate-600">
          <span className="inline-flex items-center gap-1">
            <span className="w-2.5 h-2.5 bg-red-600 rounded-2xs inline-block"></span>
            <span className="text-slate-800 font-semibold">{lang === 'km' ? 'បន្ទាត់ក្រហម៖ ព្រំដែនព័ត៌មានស្នូល' : 'Red Line: Core Info Boundary'}</span>
          </span>
          <span>·</span>
          <span className="font-semibold text-slate-900">
            {density === 'ultra' ? (lang === 'km' ? 'តូចបំផុត (Ultra)' : 'Ultra-Dense') : (lang === 'km' ? 'ល្មម' : 'Compact')}
          </span>
        </div>
      </div>

      {/* 5. OFFICIAL STATISTICAL SUMMARY AT BOTTOM OF STUDENT ROSTER (ផ្នែកខាងក្រោមនៃបញ្ជីរាយនាមសិស្ស) */}
      <div className="mt-3 border-2 border-slate-700 bg-white rounded-lg shadow-sm overflow-hidden">
        {/* Header Bar */}
        <div className="bg-slate-800 text-white px-3 py-2 flex flex-wrap items-center justify-between gap-2 border-b-2 border-slate-700">
          <div className="flex items-center gap-2">
            <FileText className="w-4 h-4 text-amber-400" />
            <h3 className="font-bold text-xs sm:text-sm tracking-wide">
              {lang === 'km'
                ? 'ស្ថិតិសរុបផ្នែកខាងក្រោមបញ្ជីរាយនាមសិស្ស (Summary of Student Roster)'
                : 'Official Student Roster Statistical Summary'}
            </h3>
            <span className="text-[11px] text-slate-300 bg-slate-700 px-2 py-0.5 rounded font-mono">
              {lang === 'km' ? `សរុប ${statsSummary.total} នាក់` : `Total ${statsSummary.total}`}
            </span>
          </div>

          <div className="flex items-center gap-1.5 no-print">
            <button
              onClick={handleCopySummary}
              className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold bg-amber-500 hover:bg-amber-600 text-slate-950 rounded transition-colors cursor-pointer shadow-2xs"
              title="ចម្លងទម្រង់អត្ថបទសង្ខេបទៅ Clipboard"
            >
              {copiedSummary ? <Check className="w-3.5 h-3.5 text-emerald-950" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedSummary ? (lang === 'km' ? 'បានចម្លងរួចរាល់ ✓' : 'Copied!') : (lang === 'km' ? 'ចម្លងទម្រង់អត្ថបទ' : 'Copy Text')}</span>
            </button>
            <button
              onClick={() => window.print()}
              className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium bg-slate-700 hover:bg-slate-600 text-white rounded transition-colors cursor-pointer"
              title="បោះពុម្ពតារាងរួមទាំងស្ថិតិសង្ខេប"
            >
              <Printer className="w-3.5 h-3.5 text-slate-300" />
              <span>{lang === 'km' ? 'បោះពុម្ព' : 'Print'}</span>
            </button>
          </div>
        </div>

        {/* 4 Official Breakdown Columns Grid with Strong High-Contrast Borders */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 divide-y md:divide-y-0 md:divide-x-2 divide-slate-400 bg-slate-50">
          {/* Column 1: សិស្សសរុប និងអាយុ */}
          <div className="p-3 bg-white flex flex-col justify-between">
            <div>
              {/* Category Header */}
              <div className="pb-1.5 mb-2 border-b-2 border-blue-600 flex items-center justify-between">
                <span className="font-bold text-xs sm:text-sm text-blue-950">
                  {lang === 'km' ? '* សិស្សសរុប គ្រប់អាយុ' : '* Total Students & Ages'}
                </span>
                <span className="w-2 h-2 rounded-full bg-blue-600"></span>
              </div>

              {/* Master Total */}
              <div className="p-2 bg-blue-50 border border-blue-300 rounded mb-2.5">
                <div className="font-bold text-xs sm:text-sm text-blue-950">
                  * សិស្សសរុប : <span className="font-mono text-sm text-blue-900 font-extrabold">{statsSummary.total}</span> នាក់{' '}
                  <span className="text-pink-700 font-bold ml-1">
                    ស្រី <span className="font-mono text-sm font-extrabold">{statsSummary.totalFemale}</span> នាក់
                  </span>
                </div>
              </div>

              {/* Age Items */}
              <div className="space-y-1.5 text-xs text-slate-800">
                <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-1">
                  {lang === 'km' ? 'បំបែកតាមគ្រប់កម្រិតអាយុ៖' : 'Breakdown by Age:'}
                </div>
                {statsSummary.ageList.length === 0 ? (
                  <div className="text-slate-400 italic text-[11px]">— គ្មានទិន្នន័យអាយុ —</div>
                ) : (
                  statsSummary.ageList.map((item) => (
                    <div
                      key={item.age}
                      className="flex items-center justify-between py-0.5 px-1.5 rounded hover:bg-slate-100 transition-colors border-b border-slate-200"
                    >
                      <span className="font-medium text-slate-900">
                        - អាយុ <strong className="font-mono">{item.age}</strong> ឆ្នាំ សរុប :
                      </span>
                      <span className="font-mono font-bold text-slate-950">
                        {item.total} នាក់{' '}
                        <span className="text-pink-700 font-semibold ml-1">
                          (ស្រី {item.female} នាក់)
                        </span>
                      </span>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>

          {/* Column 2: សិស្សពិការ */}
          <div className="p-3 bg-white flex flex-col justify-between">
            <div>
              {/* Category Header */}
              <div className="pb-1.5 mb-2 border-b-2 border-purple-600 flex items-center justify-between">
                <span className="font-bold text-xs sm:text-sm text-purple-950">
                  {lang === 'km' ? '* សិស្សមានពិការភាព' : '* Students with Disabilities'}
                </span>
                <span className="text-xs">♿</span>
              </div>

              {/* Master Total */}
              <div className="p-2 bg-purple-50 border border-purple-300 rounded mb-2.5">
                <div className="font-bold text-xs sm:text-sm text-purple-950">
                  * សិស្សពិការ សរុប : <span className="font-mono text-sm text-purple-900 font-extrabold">{statsSummary.disabled.total}</span> នាក់{' '}
                  <span className="text-pink-700 font-bold ml-1">
                    ស្រី <span className="font-mono text-sm font-extrabold">{statsSummary.disabled.female}</span> នាក់
                  </span>
                </div>
              </div>

              {/* Sub-items */}
              <div className="space-y-1.5 text-xs text-slate-800">
                <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-1">
                  {lang === 'km' ? 'ប្រភេទពិការភាពចម្បង៖' : 'Disability Categories:'}
                </div>
                <div className="flex items-center justify-between py-0.5 px-1.5 rounded hover:bg-slate-100 transition-colors border-b border-slate-200">
                  <span className="font-medium text-slate-900">- ពិបាកនិយាយ សរុប:</span>
                  <span className="font-mono font-bold text-slate-950">
                    {statsSummary.disabled.speech.total} នាក់{' '}
                    <span className="text-pink-700 font-semibold ml-1">
                      (ស្រី {statsSummary.disabled.speech.female} នាក់)
                    </span>
                  </span>
                </div>

                <div className="flex items-center justify-between py-0.5 px-1.5 rounded hover:bg-slate-100 transition-colors border-b border-slate-200">
                  <span className="font-medium text-slate-900">- ពិបាកមើល សរុប :</span>
                  <span className="font-mono font-bold text-slate-950">
                    {statsSummary.disabled.vision.total} នាក់{' '}
                    <span className="text-pink-700 font-semibold ml-1">
                      (ស្រី {statsSummary.disabled.vision.female} នាក់)
                    </span>
                  </span>
                </div>

                {statsSummary.disabled.other.total > 0 && (
                  <div className="flex items-center justify-between py-0.5 px-1.5 rounded hover:bg-slate-100 transition-colors border-b border-slate-200">
                    <span className="font-medium text-slate-900">- ផ្សេងៗ សរុប :</span>
                    <span className="font-mono font-bold text-slate-950">
                      {statsSummary.disabled.other.total} នាក់{' '}
                      <span className="text-pink-700 font-semibold ml-1">
                        (ស្រី {statsSummary.disabled.other.female} នាក់)
                      </span>
                    </span>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Column 3: សិស្សមកពីគ្រួសារក្រីក្រ */}
          <div className="p-3 bg-white flex flex-col justify-between">
            <div>
              {/* Category Header */}
              <div className="pb-1.5 mb-2 border-b-2 border-amber-600 flex items-center justify-between">
                <span className="font-bold text-xs sm:text-sm text-amber-950">
                  {lang === 'km' ? '* សិស្សមកពីគ្រួសារក្រីក្រ' : '* Poor Families (IDPoor)'}
                </span>
                <span className="w-2 h-2 rounded-full bg-amber-600"></span>
              </div>

              {/* Master Total */}
              <div className="p-2 bg-amber-50 border border-amber-300 rounded mb-2.5">
                <div className="font-bold text-xs sm:text-sm text-amber-950">
                  * សិ្សមកពីក្រួសារក្រីក្រ សរុប : <span className="font-mono text-sm text-amber-900 font-extrabold">{statsSummary.poor.total}</span> នាក់{' '}
                  <span className="text-pink-700 font-bold ml-1">
                    ស្រី <span className="font-mono text-sm font-extrabold">{statsSummary.poor.female}</span> នាក់
                  </span>
                </div>
              </div>

              {/* Sub-items */}
              <div className="space-y-1.5 text-xs text-slate-800">
                <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-1">
                  {lang === 'km' ? 'កម្រិតសមធម៌ក្រីក្រ៖' : 'Equity Categories:'}
                </div>
                <div className="flex items-center justify-between py-0.5 px-1.5 rounded hover:bg-slate-100 transition-colors border-b border-slate-200">
                  <span className="font-medium text-slate-900">- ក្រ១ សរុប:</span>
                  <span className="font-mono font-bold text-slate-950">
                    {statsSummary.poor.poor1.total} នាក់{' '}
                    <span className="text-pink-700 font-semibold ml-1">
                      (ស្រី {statsSummary.poor.poor1.female} នាក់)
                    </span>
                  </span>
                </div>

                <div className="flex items-center justify-between py-0.5 px-1.5 rounded hover:bg-slate-100 transition-colors border-b border-slate-200">
                  <span className="font-medium text-slate-900">- ក្រ២ សរុប :</span>
                  <span className="font-mono font-bold text-slate-950">
                    {statsSummary.poor.poor2.total} នាក់{' '}
                    <span className="text-pink-700 font-semibold ml-1">
                      (ស្រី {statsSummary.poor.poor2.female} នាក់)
                    </span>
                  </span>
                </div>

                <div className="flex items-center justify-between py-0.5 px-1.5 rounded hover:bg-slate-100 transition-colors border-b border-slate-200">
                  <span className="font-medium text-slate-900">- ផ្សេងៗ សរុប :</span>
                  <span className="font-mono font-bold text-slate-950">
                    {statsSummary.poor.other.total} នាក់{' '}
                    <span className="text-pink-700 font-semibold ml-1">
                      (ស្រី {statsSummary.poor.other.female} នាក់)
                    </span>
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Column 4: សិស្សកំព្រា */}
          <div className="p-3 bg-white flex flex-col justify-between">
            <div>
              {/* Category Header */}
              <div className="pb-1.5 mb-2 border-b-2 border-orange-600 flex items-center justify-between">
                <span className="font-bold text-xs sm:text-sm text-orange-950">
                  {lang === 'km' ? '* សិស្សកំព្រា' : '* Orphaned Students'}
                </span>
                <span className="w-2 h-2 rounded-full bg-orange-600"></span>
              </div>

              {/* Master Total */}
              <div className="p-2 bg-orange-50 border border-orange-300 rounded mb-2.5">
                <div className="font-bold text-xs sm:text-sm text-orange-950">
                  * សិស្សកំព្រា សរុប : <span className="font-mono text-sm text-orange-900 font-extrabold">{statsSummary.orphan.total}</span> នាក់{' '}
                  <span className="text-pink-700 font-bold ml-1">
                    ស្រី <span className="font-mono text-sm font-extrabold">{statsSummary.orphan.female}</span> នាក់
                  </span>
                </div>
              </div>

              {/* Sub-items */}
              <div className="space-y-1.5 text-xs text-slate-800">
                <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-1">
                  {lang === 'km' ? 'ស្ថានភាពកំព្រា៖' : 'Orphan Breakdown:'}
                </div>
                <div className="flex items-center justify-between py-0.5 px-1.5 rounded hover:bg-slate-100 transition-colors border-b border-slate-200">
                  <span className="font-medium text-slate-900">- កំព្រាឪពុក សរុប:</span>
                  <span className="font-mono font-bold text-slate-950">
                    {statsSummary.orphan.father.total} នាក់{' '}
                    <span className="text-pink-700 font-semibold ml-1">
                      (ស្រី {statsSummary.orphan.father.female} នាក់)
                    </span>
                  </span>
                </div>

                <div className="flex items-center justify-between py-0.5 px-1.5 rounded hover:bg-slate-100 transition-colors border-b border-slate-200">
                  <span className="font-medium text-slate-900">- កំព្រាម្ដាយ សរុប :</span>
                  <span className="font-mono font-bold text-slate-950">
                    {statsSummary.orphan.mother.total} នាក់{' '}
                    <span className="text-pink-700 font-semibold ml-1">
                      (ស្រី {statsSummary.orphan.mother.female} នាក់)
                    </span>
                  </span>
                </div>

                <div className="flex items-center justify-between py-0.5 px-1.5 rounded hover:bg-slate-100 transition-colors border-b border-slate-200">
                  <span className="font-medium text-slate-900">- កំព្រាឪពុកម្ដាយ សរុប :</span>
                  <span className="font-mono font-bold text-slate-950">
                    {statsSummary.orphan.both.total} នាក់{' '}
                    <span className="text-pink-700 font-semibold ml-1">
                      (ស្រី {statsSummary.orphan.both.female} នាក់)
                    </span>
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
