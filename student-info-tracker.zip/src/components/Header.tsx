import React from 'react';
import { Plus, Globe, Cloud, CloudUpload, LogIn, LogOut, User as UserIcon } from 'lucide-react';
import { Language } from '../types/student';
import { User } from '../firebase';

interface HeaderProps {
  lang: Language;
  onToggleLang: () => void;
  activeTab: 'table' | 'analytics' | 'health' | 'guidelines';
  onSelectTab: (tab: 'table' | 'analytics' | 'health' | 'guidelines') => void;
  onOpenAddModal: () => void;
  user: User | null;
  onOpenAuthModal: () => void;
  onSignOut: () => void;
  onSyncToCloud: () => void;
  isSyncing: boolean;
  lastCloudSyncTime: string | null;
}

export const Header: React.FC<HeaderProps> = ({
  lang,
  onToggleLang,
  activeTab,
  onSelectTab,
  onOpenAddModal,
  user,
  onOpenAuthModal,
  onSignOut,
  onSyncToCloud,
  isSyncing,
  lastCloudSyncTime,
}) => {
  return (
    <header className="no-print bg-white border-b border-slate-200 sticky top-0 z-30 shadow-2xs">
      <div className="max-w-[1720px] mx-auto px-3 sm:px-5 lg:px-6">
        <div className="flex items-center justify-between gap-4 h-16">
          {/* Zone 1: Brand wordmark */}
          <a
            href="#root"
            onClick={(e) => {
              e.preventDefault();
              onSelectTab('table');
            }}
            className="flex items-center gap-2.5 text-slate-900 font-bold tracking-tight text-lg whitespace-nowrap shrink-0 group"
          >
            <div className="w-8 h-8 rounded-lg bg-blue-700 flex items-center justify-center text-white text-sm font-semibold shadow-xs">
              ស
            </div>
            <div className="leading-tight">
              <span className="text-base text-blue-900 font-bold">ព័ត៌មានសិស្ស</span>
              <span className="text-xs font-semibold text-slate-600 block">Student Information System</span>
            </div>
          </a>

          {/* Zone 2: Navigation tabs */}
          <nav className="hidden lg:flex items-center gap-6 text-sm font-medium text-slate-600">
            <button
              onClick={() => onSelectTab('table')}
              className={`hover:text-blue-700 transition-colors whitespace-nowrap shrink-0 pb-1 border-b-2 cursor-pointer ${
                activeTab === 'table' ? 'border-blue-700 text-blue-700 font-semibold' : 'border-transparent'
              }`}
            >
              {lang === 'km' ? 'តារាងព័ត៌មាន (៦៥ ជួរ)' : 'All Records (65 Columns)'}
            </button>
            <button
              onClick={() => onSelectTab('analytics')}
              className={`hover:text-blue-700 transition-colors whitespace-nowrap shrink-0 pb-1 border-b-2 cursor-pointer ${
                activeTab === 'analytics' ? 'border-blue-700 text-blue-700 font-semibold' : 'border-transparent'
              }`}
            >
              {lang === 'km' ? 'ស្ថិតិទូទៅ' : 'School Analytics'}
            </button>
            <button
              onClick={() => onSelectTab('health')}
              className={`hover:text-blue-700 transition-colors whitespace-nowrap shrink-0 pb-1 border-b-2 cursor-pointer ${
                activeTab === 'health' ? 'border-blue-700 text-blue-700 font-semibold' : 'border-transparent'
              }`}
            >
              {lang === 'km' ? 'សុខភាព & សមធម៌' : 'Health & Equity'}
            </button>
            <button
              onClick={() => onSelectTab('guidelines')}
              className={`hover:text-blue-700 transition-colors whitespace-nowrap shrink-0 pb-1 border-b-2 cursor-pointer ${
                activeTab === 'guidelines' ? 'border-blue-700 text-blue-700 font-semibold' : 'border-transparent'
              }`}
            >
              {lang === 'km' ? 'សេចក្ដីណែនាំ' : 'MoEYS Standards'}
            </button>
          </nav>

          {/* Zone 3: Cloud Sync, Auth & Actions */}
          <div className="flex items-center gap-2.5 shrink-0">
            {/* Cloud Sync Button */}
            <button
              onClick={onSyncToCloud}
              disabled={isSyncing}
              className={`flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold rounded-lg border transition-all cursor-pointer ${
                isSyncing
                  ? 'bg-amber-50 text-amber-800 border-amber-300 animate-pulse'
                  : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border-emerald-300'
              }`}
              title={
                lastCloudSyncTime
                  ? `${lang === 'km' ? 'សមកាលកម្មចុងក្រោយ៖' : 'Last Synced:'} ${lastCloudSyncTime}`
                  : lang === 'km'
                  ? 'រក្សាទុកទិន្នន័យលើ Cloud Firestore'
                  : 'Sync data to Cloud Firestore'
              }
            >
              {isSyncing ? (
                <span className="w-3.5 h-3.5 border-2 border-amber-600 border-t-transparent rounded-full animate-spin"></span>
              ) : (
                <CloudUpload className="w-3.5 h-3.5 text-emerald-700" />
              )}
              <span className="hidden sm:inline">
                {isSyncing
                  ? lang === 'km'
                    ? 'កំពុងសមកាលកម្ម...'
                    : 'Syncing...'
                  : lang === 'km'
                  ? 'Cloud Firestore'
                  : 'Cloud Sync'}
              </span>
            </button>

            {/* Firebase Auth Profile / Login */}
            {user ? (
              <div className="flex items-center gap-1.5 pl-1.5 border-l border-slate-200">
                <div className="flex items-center gap-1.5 px-2 py-1 bg-slate-100 rounded-lg text-xs font-medium text-slate-800">
                  <div className="w-5 h-5 rounded-full bg-blue-700 text-white flex items-center justify-center text-[10px] font-bold">
                    {user.displayName ? user.displayName.charAt(0).toUpperCase() : user.email ? user.email.charAt(0).toUpperCase() : 'U'}
                  </div>
                  <span className="max-w-[110px] truncate hidden md:inline">
                    {user.displayName || (user.isAnonymous ? (lang === 'km' ? 'សាកល្បង (Guest)' : 'Guest') : user.email?.split('@')[0])}
                  </span>
                </div>
                <button
                  onClick={onSignOut}
                  className="p-1.5 text-slate-500 hover:text-red-700 hover:bg-red-50 rounded-lg transition-colors cursor-pointer"
                  title={lang === 'km' ? 'ចាកចេញពីគណនី' : 'Sign Out'}
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <button
                onClick={onOpenAuthModal}
                className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-lg transition-colors cursor-pointer"
                title="Firebase Auth Login"
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>{lang === 'km' ? 'ចូលប្រព័ន្ធ' : 'Sign In'}</span>
              </button>
            )}

            {/* Language Switcher */}
            <button
              onClick={onToggleLang}
              className="flex items-center gap-1 px-2 py-1.5 text-xs font-medium text-slate-700 hover:text-blue-700 hover:bg-slate-100 rounded-md transition-colors cursor-pointer border border-slate-200"
              title="Toggle Khmer / English"
            >
              <Globe className="w-3.5 h-3.5 text-slate-500" />
              <span className="font-semibold">{lang === 'km' ? 'ខ្មែរ' : 'EN'}</span>
            </button>

            {/* Add Student CTA */}
            <button
              onClick={onOpenAddModal}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-blue-700 rounded-lg hover:bg-blue-800 transition-colors shadow-xs whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{lang === 'km' ? 'បញ្ចូលសិស្ស' : 'Add Student'}</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
