import React, { useState, useEffect } from 'react';
import { X, Save, Copy, Check } from 'lucide-react';
import { StudentRecord, Language } from '../types/student';
import { CAMBODIA_PROVINCES } from '../data/initialData';

interface StudentFormModalProps {
  isOpen: boolean;
  student: StudentRecord | null;
  lang: Language;
  onClose: () => void;
  onSave: (student: StudentRecord) => void;
  nextStudentCode?: string;
}

export const StudentFormModal: React.FC<StudentFormModalProps> = ({
  isOpen,
  student,
  lang,
  onClose,
  onSave,
  nextStudentCode = '0008',
}) => {
  const [formData, setFormData] = useState<StudentRecord>({
    id: '',
    studentCode: '',
    lastName: '',
    firstName: '',
    gender: 'ស្រី',
    dob: '',
    phone: '',
    nationality: 'ខ្មែរ',
    pobProvince: 'បន្ទាយមានជ័យ',
    pobDistrict: '',
    pobCommune: '',
    pobVillage: '',
    curProvince: 'បន្ទាយមានជ័យ',
    curDistrict: '',
    curCommune: '',
    curVillage: '',
    academicYear: '2025-2026',
    previousGrade: '2B',
    enrollmentDate: new Date().toISOString().split('T')[0],
    disabilityType: '',
    kitReading: 'បានទទួល',
    kitMath: 'បានទទួល',
    kitKhmerBook: 'មាន',
    kitMathBook: 'មាន',
    equityFamily: 'មិនក្រីក្រ',
    equityCard: '',
    ethnicMinority: '',
    specialTrait: '',
    weightSem1: '',
    heightSem1: '',
    weightSem2: '',
    heightSem2: '',
    eyeLeft: '6/6',
    eyeRight: '6/6',
    eyeBoth: '6/6',
    eyeResult: 'ធម្មតា',
    eyePrescription: '',
    eyeDevice: '',
    earLeft: '71dB',
    earRight: '71dB',
    earBoth: '71dB',
    earResult: 'ត្រចៀកល្អប្រសើរ',
    earPrescription: '',
    earDevice: '',
    vaccineList: 'COVID-19, BCG',
    fatherLastName: '',
    fatherFirstName: '',
    fatherPhone: '',
    fatherOccupation: '',
    fatherProvince: '',
    fatherDistrict: '',
    fatherCommune: '',
    fatherVillage: '',
    motherLastName: '',
    motherFirstName: '',
    motherPhone: '',
    motherOccupation: '',
    motherProvince: '',
    motherDistrict: '',
    motherCommune: '',
    motherVillage: '',
    guardianType: 'ឪពុក',
    guardianLastName: '',
    guardianFirstName: '',
    guardianGender: 'ប្រុស',
    guardianPhone: '',
    guardianOccupation: '',
    guardianAddress: '',
  });

  const [activeTab, setActiveTab] = useState<'personal' | 'address' | 'academic' | 'health' | 'equity' | 'parents'>('personal');
  const [copiedAddressNotice, setCopiedAddressNotice] = useState(false);

  useEffect(() => {
    if (student) {
      setFormData(student);
    } else {
      setFormData({
        id: `std-${Date.now()}`,
        studentCode: nextStudentCode,
        lastName: '',
        firstName: '',
        gender: 'ស្រី',
        dob: '',
        phone: '',
        nationality: 'ខ្មែរ',
        pobProvince: 'បន្ទាយមានជ័យ',
        pobDistrict: '',
        pobCommune: '',
        pobVillage: '',
        curProvince: 'បន្ទាយមានជ័យ',
        curDistrict: '',
        curCommune: '',
        curVillage: '',
        academicYear: '2025-2026',
        previousGrade: '2B',
        enrollmentDate: new Date().toISOString().split('T')[0],
        disabilityType: '',
        kitReading: 'បានទទួល',
        kitMath: 'បានទទួល',
        kitKhmerBook: 'មាន',
        kitMathBook: 'មាន',
        equityFamily: 'មិនក្រីក្រ',
        equityCard: '',
        ethnicMinority: '',
        specialTrait: '',
        weightSem1: '',
        heightSem1: '',
        weightSem2: '',
        heightSem2: '',
        eyeLeft: '6/6',
        eyeRight: '6/6',
        eyeBoth: '6/6',
        eyeResult: 'ធម្មតា',
        eyePrescription: '',
        eyeDevice: '',
        earLeft: '71dB',
        earRight: '71dB',
        earBoth: '71dB',
        earResult: 'ត្រចៀកល្អប្រសើរ',
        earPrescription: '',
        earDevice: '',
        vaccineList: 'COVID-19, BCG',
        fatherLastName: '',
        fatherFirstName: '',
        fatherPhone: '',
        fatherOccupation: '',
        fatherProvince: '',
        fatherDistrict: '',
        fatherCommune: '',
        fatherVillage: '',
        motherLastName: '',
        motherFirstName: '',
        motherPhone: '',
        motherOccupation: '',
        motherProvince: '',
        motherDistrict: '',
        motherCommune: '',
        motherVillage: '',
        guardianType: 'ឪពុក',
        guardianLastName: '',
        guardianFirstName: '',
        guardianGender: 'ប្រុស',
        guardianPhone: '',
        guardianOccupation: '',
        guardianAddress: '',
      });
    }
    setActiveTab('personal');
  }, [student, isOpen, nextStudentCode]);

  if (!isOpen) return null;

  const handleChange = (key: keyof StudentRecord, value: string) => {
    setFormData((prev) => ({
      ...prev,
      [key]: value,
    }));
  };

  const handleCopyPobToCur = () => {
    setFormData((prev) => ({
      ...prev,
      curProvince: prev.pobProvince,
      curDistrict: prev.pobDistrict,
      curCommune: prev.pobCommune,
      curVillage: prev.pobVillage,
    }));
    setCopiedAddressNotice(true);
    setTimeout(() => setCopiedAddressNotice(false), 2000);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.lastName.trim() || !formData.firstName.trim()) {
      alert(lang === 'km' ? 'សូមបំពេញគោត្តនាម និង នាម របស់សិស្ស!' : 'Please enter student last name and first name!');
      setActiveTab('personal');
      return;
    }
    onSave(formData);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-4xl max-h-[92vh] flex flex-col overflow-hidden border border-slate-200">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50/70">
          <div>
            <h2 className="text-lg font-bold text-slate-900">
              {student
                ? lang === 'km'
                  ? 'កែប្រែព័ត៌មានសិស្ស'
                  : 'Edit Student Record'
                : lang === 'km'
                ? 'បញ្ចូលសិស្សថ្មី'
                : 'Add New Student'}
            </h2>
            <p className="text-xs text-slate-500">
              {lang === 'km'
                ? 'បំពេញទិន្នន័យ ៦៥ ជួរឈរ តាមស្ដង់ដារ MoEYS'
                : 'Fill all 65 standard MoEYS data columns'}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-200/60 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Navigation Tabs */}
        <div className="flex items-center overflow-x-auto border-b border-slate-200 bg-slate-100/60 px-4 py-1.5 gap-1 text-xs">
          <button
            type="button"
            onClick={() => setActiveTab('personal')}
            className={`px-3 py-1.5 rounded-md font-medium whitespace-nowrap transition-colors cursor-pointer ${
              activeTab === 'personal'
                ? 'bg-white text-blue-700 shadow-2xs font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {lang === 'km' ? '១. ព័ត៌មានផ្ទាល់ខ្លួន' : '1. Personal'}
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('address')}
            className={`px-3 py-1.5 rounded-md font-medium whitespace-nowrap transition-colors cursor-pointer ${
              activeTab === 'address'
                ? 'bg-white text-blue-700 shadow-2xs font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {lang === 'km' ? '២. ទីកន្លែងកំណើត & អាសយដ្ឋាន' : '2. Addresses'}
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('academic')}
            className={`px-3 py-1.5 rounded-md font-medium whitespace-nowrap transition-colors cursor-pointer ${
              activeTab === 'academic'
                ? 'bg-white text-blue-700 shadow-2xs font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {lang === 'km' ? '៣. ការសិក្សា & កញ្ចប់ជំនួយ' : '3. Academic & Kits'}
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('health')}
            className={`px-3 py-1.5 rounded-md font-medium whitespace-nowrap transition-colors cursor-pointer ${
              activeTab === 'health'
                ? 'bg-white text-blue-700 shadow-2xs font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {lang === 'km' ? '៤. សុខភាព, ភ្នែក, ត្រចៀក' : '4. Health & Screenings'}
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('equity')}
            className={`px-3 py-1.5 rounded-md font-medium whitespace-nowrap transition-colors cursor-pointer ${
              activeTab === 'equity'
                ? 'bg-white text-blue-700 shadow-2xs font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {lang === 'km' ? '៥. សមធម៌ / ក្រីក្រ' : '5. Equity'}
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('parents')}
            className={`px-3 py-1.5 rounded-md font-medium whitespace-nowrap transition-colors cursor-pointer ${
              activeTab === 'parents'
                ? 'bg-white text-blue-700 shadow-2xs font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {lang === 'km' ? '៦. ឪពុកម្ដាយ & អាណាព្យាបាល' : '6. Family'}
          </button>
        </div>

        {/* Scrollable Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-6">
          {/* TAB 1: Personal Info */}
          {activeTab === 'personal' && (
            <div className="space-y-4">
              <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                {lang === 'km' ? 'ព័ត៌មានសិស្ស (Student Info)' : 'Student Core Info'}
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">
                    {lang === 'km' ? 'អត្តលេខសិស្ស' : 'Student ID'}
                  </label>
                  <input
                    type="text"
                    value={formData.studentCode}
                    onChange={(e) => handleChange('studentCode', e.target.value)}
                    placeholder="0001"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-blue-500 font-mono"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">
                    {lang === 'km' ? 'គោត្តនាម *' : 'Last Name *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.lastName}
                    onChange={(e) => handleChange('lastName', e.target.value)}
                    placeholder="ឧ. កើន"
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-blue-500 font-semibold"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">
                    {lang === 'km' ? 'នាម *' : 'First Name *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.firstName}
                    onChange={(e) => handleChange('firstName', e.target.value)}
                    placeholder="ឧ. វីរះនិច្ច"
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-blue-500 font-semibold"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">
                    {lang === 'km' ? 'ភេទ *' : 'Gender *'}
                  </label>
                  <select
                    value={formData.gender}
                    onChange={(e) => handleChange('gender', e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-blue-500 cursor-pointer"
                  >
                    <option value="ស្រី">{lang === 'km' ? 'ស្រី (Female)' : 'Female'}</option>
                    <option value="ប្រុស">{lang === 'km' ? 'ប្រុស (Male)' : 'Male'}</option>
                  </select>
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">
                    {lang === 'km' ? 'ថ្ងៃខែឆ្នាំកំណើត' : 'Date of Birth'}
                  </label>
                  <input
                    type="text"
                    value={formData.dob}
                    onChange={(e) => handleChange('dob', e.target.value)}
                    placeholder="19-3-2019"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-blue-500 font-mono"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">
                    {lang === 'km' ? 'លេខទូរស័ព្ទ' : 'Phone'}
                  </label>
                  <input
                    type="text"
                    value={formData.phone}
                    onChange={(e) => handleChange('phone', e.target.value)}
                    placeholder="012 345 678"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-blue-500 font-mono"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">
                    {lang === 'km' ? 'សញ្ជាតិ' : 'Nationality'}
                  </label>
                  <input
                    type="text"
                    value={formData.nationality}
                    onChange={(e) => handleChange('nationality', e.target.value)}
                    placeholder="ខ្មែរ"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">
                    {lang === 'km' ? 'ជនជាតិភាគតិច' : 'Ethnic Minority'}
                  </label>
                  <input
                    type="text"
                    value={formData.ethnicMinority}
                    onChange={(e) => handleChange('ethnicMinority', e.target.value)}
                    placeholder="គ្មាន ឬ ទំពូន, ចារ៉ាយ..."
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">
                    {lang === 'km' ? 'លក្ខណៈពិសេស' : 'Special Trait/Talent'}
                  </label>
                  <input
                    type="text"
                    value={formData.specialTrait}
                    onChange={(e) => handleChange('specialTrait', e.target.value)}
                    placeholder="កីឡា / គំនូរ / សិល្បៈ"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-blue-500"
                  />
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: Addresses */}
          {activeTab === 'address' && (
            <div className="space-y-6">
              {/* Place of Birth */}
              <div>
                <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2">
                  {lang === 'km' ? 'ទីកន្លែងកំណើត (Place of Birth)' : 'Place of Birth'}
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
                  <div>
                    <label className="block text-slate-600 mb-1">{lang === 'km' ? 'ខេត្ត/ក្រុង' : 'Province/City'}</label>
                    <input
                      type="text"
                      list="cambodia-provinces"
                      value={formData.pobProvince}
                      onChange={(e) => handleChange('pobProvince', e.target.value)}
                      placeholder="បន្ទាយមានជ័យ"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 mb-1">{lang === 'km' ? 'ស្រុក/ខណ្ឌ' : 'District'}</label>
                    <input
                      type="text"
                      value={formData.pobDistrict}
                      onChange={(e) => handleChange('pobDistrict', e.target.value)}
                      placeholder="ភ្នំស្រុក"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 mb-1">{lang === 'km' ? 'ឃុំ/សង្កាត់' : 'Commune'}</label>
                    <input
                      type="text"
                      value={formData.pobCommune}
                      onChange={(e) => handleChange('pobCommune', e.target.value)}
                      placeholder="ស្ពានស្រែង"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 mb-1">{lang === 'km' ? 'ភូមិ' : 'Village'}</label>
                    <input
                      type="text"
                      value={formData.pobVillage}
                      onChange={(e) => handleChange('pobVillage', e.target.value)}
                      placeholder="មុខឈ្នាង"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg"
                    />
                  </div>
                </div>
              </div>

              {/* Current Address + Copy Action */}
              <div className="pt-4 border-t border-slate-200">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                    {lang === 'km' ? 'អាសយដ្ឋានបច្ចុប្បន្ន (Current Address)' : 'Current Address'}
                  </h3>
                  <button
                    type="button"
                    onClick={handleCopyPobToCur}
                    className="flex items-center gap-1.5 px-2.5 py-1 text-xs text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-md transition-colors cursor-pointer border border-blue-200"
                  >
                    {copiedAddressNotice ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{lang === 'km' ? 'ចម្លងដូចទីកន្លែងកំណើត' : 'Copy from Birthplace'}</span>
                  </button>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
                  <div>
                    <label className="block text-slate-600 mb-1">{lang === 'km' ? 'ខេត្ត/ក្រុង' : 'Province/City'}</label>
                    <input
                      type="text"
                      list="cambodia-provinces"
                      value={formData.curProvince}
                      onChange={(e) => handleChange('curProvince', e.target.value)}
                      placeholder="បន្ទាយមានជ័យ"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 mb-1">{lang === 'km' ? 'ស្រុក/ខណ្ឌ' : 'District'}</label>
                    <input
                      type="text"
                      value={formData.curDistrict}
                      onChange={(e) => handleChange('curDistrict', e.target.value)}
                      placeholder="ភ្នំស្រុក"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 mb-1">{lang === 'km' ? 'ឃុំ/សង្កាត់' : 'Commune'}</label>
                    <input
                      type="text"
                      value={formData.curCommune}
                      onChange={(e) => handleChange('curCommune', e.target.value)}
                      placeholder="ស្ពានស្រែង"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 mb-1">{lang === 'km' ? 'ភូមិ' : 'Village'}</label>
                    <input
                      type="text"
                      value={formData.curVillage}
                      onChange={(e) => handleChange('curVillage', e.target.value)}
                      placeholder="មុខឈ្នាង"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: Academic & Support Kits */}
          {activeTab === 'academic' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2">
                  {lang === 'km' ? 'ព័ត៌មានសិក្សា (Academic)' : 'Academic Information'}
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
                  <div>
                    <label className="block text-slate-600 mb-1">{lang === 'km' ? 'ឆ្នាំសិក្សា' : 'Academic Year'}</label>
                    <input
                      type="text"
                      value={formData.academicYear}
                      onChange={(e) => handleChange('academicYear', e.target.value)}
                      placeholder="2025-2026"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 mb-1">{lang === 'km' ? 'ថ្នាក់ឆ្នាំមុន' : 'Previous Grade'}</label>
                    <input
                      type="text"
                      value={formData.previousGrade}
                      onChange={(e) => handleChange('previousGrade', e.target.value)}
                      placeholder="2B"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 mb-1">{lang === 'km' ? 'ថ្ងៃចុះឈ្មោះចូលរៀន' : 'Enrollment Date'}</label>
                    <input
                      type="text"
                      value={formData.enrollmentDate}
                      onChange={(e) => handleChange('enrollmentDate', e.target.value)}
                      placeholder="2025-11-1"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 mb-1">{lang === 'km' ? 'ប្រភេទពិការភាព' : 'Disability'}</label>
                    <input
                      type="text"
                      value={formData.disabilityType}
                      onChange={(e) => handleChange('disabilityType', e.target.value)}
                      placeholder="គ្មាន ឬ បញ្ជាក់"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg"
                    />
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-200">
                <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2">
                  {lang === 'km' ? 'កញ្ចប់សម្ភារជំនួយ (Support Packages)' : 'Learning Support Packages'}
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
                  <div>
                    <label className="block text-slate-600 mb-1">{lang === 'km' ? 'កញ្ចប់អំណាន' : 'Reading Kit'}</label>
                    <select
                      value={formData.kitReading}
                      onChange={(e) => handleChange('kitReading', e.target.value)}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg"
                    >
                      <option value="បានទទួល">{lang === 'km' ? 'បានទទួល' : 'Received'}</option>
                      <option value="មិនបានទទួល">{lang === 'km' ? 'មិនបានទទួល' : 'Not received'}</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-slate-600 mb-1">{lang === 'km' ? 'កញ្ចប់គណិត' : 'Math Kit'}</label>
                    <select
                      value={formData.kitMath}
                      onChange={(e) => handleChange('kitMath', e.target.value)}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg"
                    >
                      <option value="បានទទួល">{lang === 'km' ? 'បានទទួល' : 'Received'}</option>
                      <option value="មិនបានទទួល">{lang === 'km' ? 'មិនបានទទួល' : 'Not received'}</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-slate-600 mb-1">{lang === 'km' ? 'សៀវភៅជំនួយភាសាខ្មែរ' : 'Khmer Book'}</label>
                    <select
                      value={formData.kitKhmerBook}
                      onChange={(e) => handleChange('kitKhmerBook', e.target.value)}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg"
                    >
                      <option value="មាន">{lang === 'km' ? 'មាន' : 'Yes'}</option>
                      <option value="គ្មាន">{lang === 'km' ? 'គ្មាន' : 'No'}</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-slate-600 mb-1">{lang === 'km' ? 'សៀវភៅជំនួយគណិត' : 'Math Book'}</label>
                    <select
                      value={formData.kitMathBook}
                      onChange={(e) => handleChange('kitMathBook', e.target.value)}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg"
                    >
                      <option value="មាន">{lang === 'km' ? 'មាន' : 'Yes'}</option>
                      <option value="គ្មាន">{lang === 'km' ? 'គ្មាន' : 'No'}</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: Health, BMI & Screenings */}
          {activeTab === 'health' && (
            <div className="space-y-6">
              {/* BMI Sem 1 & 2 */}
              <div>
                <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2">
                  {lang === 'km' ? 'ទម្ងន់ & កម្ពស់ (Physical Growth)' : 'Physical Growth & BMI'}
                </h3>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                  <div>
                    <label className="block text-slate-600 mb-1">{lang === 'km' ? 'ទម្ងន់ ឆមាស១ (kg)' : 'Sem 1 Weight (kg)'}</label>
                    <input
                      type="text"
                      value={formData.weightSem1}
                      onChange={(e) => handleChange('weightSem1', e.target.value)}
                      placeholder="20.00"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 mb-1">{lang === 'km' ? 'កម្ពស់ ឆមាស១ (cm)' : 'Sem 1 Height (cm)'}</label>
                    <input
                      type="text"
                      value={formData.heightSem1}
                      onChange={(e) => handleChange('heightSem1', e.target.value)}
                      placeholder="119.0"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 mb-1">{lang === 'km' ? 'ទម្ងន់ ឆមាស២ (kg)' : 'Sem 2 Weight (kg)'}</label>
                    <input
                      type="text"
                      value={formData.weightSem2}
                      onChange={(e) => handleChange('weightSem2', e.target.value)}
                      placeholder="21.50"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 mb-1">{lang === 'km' ? 'កម្ពស់ ឆមាស២ (cm)' : 'Sem 2 Height (cm)'}</label>
                    <input
                      type="text"
                      value={formData.heightSem2}
                      onChange={(e) => handleChange('heightSem2', e.target.value)}
                      placeholder="121.0"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg font-mono"
                    />
                  </div>
                </div>
              </div>

              {/* Vision */}
              <div className="pt-4 border-t border-slate-200">
                <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2">
                  {lang === 'km' ? 'ភ្នែក (Vision Screening)' : 'Vision Screening'}
                </h3>
                <div className="grid grid-cols-2 sm:grid-cols-6 gap-3 text-xs">
                  <div>
                    <label className="block text-slate-600 mb-1">{lang === 'km' ? 'ឆ្វេង' : 'Left'}</label>
                    <input
                      type="text"
                      value={formData.eyeLeft}
                      onChange={(e) => handleChange('eyeLeft', e.target.value)}
                      placeholder="6/6"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg font-mono text-center"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 mb-1">{lang === 'km' ? 'ស្ដាំ' : 'Right'}</label>
                    <input
                      type="text"
                      value={formData.eyeRight}
                      onChange={(e) => handleChange('eyeRight', e.target.value)}
                      placeholder="6/6"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg font-mono text-center"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 mb-1">{lang === 'km' ? 'ទាំងពីរ' : 'Both'}</label>
                    <input
                      type="text"
                      value={formData.eyeBoth}
                      onChange={(e) => handleChange('eyeBoth', e.target.value)}
                      placeholder="6/6"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg font-mono text-center"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 mb-1">{lang === 'km' ? 'លទ្ធផល' : 'Result'}</label>
                    <input
                      type="text"
                      value={formData.eyeResult}
                      onChange={(e) => handleChange('eyeResult', e.target.value)}
                      placeholder="ធម្មតា"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 mb-1">{lang === 'km' ? 'វេជ្ជបញ្ជា' : 'Rx'}</label>
                    <input
                      type="text"
                      value={formData.eyePrescription}
                      onChange={(e) => handleChange('eyePrescription', e.target.value)}
                      placeholder="វេជ្ជបញ្ជា"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 mb-1">{lang === 'km' ? 'ឧបករណ៍' : 'Device'}</label>
                    <input
                      type="text"
                      value={formData.eyeDevice}
                      onChange={(e) => handleChange('eyeDevice', e.target.value)}
                      placeholder="វ៉ែនតា / គ្មាន"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg"
                    />
                  </div>
                </div>
              </div>

              {/* Hearing */}
              <div className="pt-4 border-t border-slate-200">
                <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2">
                  {lang === 'km' ? 'ត្រចៀក (Hearing Screening)' : 'Hearing Screening'}
                </h3>
                <div className="grid grid-cols-2 sm:grid-cols-6 gap-3 text-xs">
                  <div>
                    <label className="block text-slate-600 mb-1">{lang === 'km' ? 'ឆ្វេង' : 'Left'}</label>
                    <input
                      type="text"
                      value={formData.earLeft}
                      onChange={(e) => handleChange('earLeft', e.target.value)}
                      placeholder="71dB"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg font-mono text-center"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 mb-1">{lang === 'km' ? 'ស្ដាំ' : 'Right'}</label>
                    <input
                      type="text"
                      value={formData.earRight}
                      onChange={(e) => handleChange('earRight', e.target.value)}
                      placeholder="71dB"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg font-mono text-center"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 mb-1">{lang === 'km' ? 'ទាំងពីរ' : 'Both'}</label>
                    <input
                      type="text"
                      value={formData.earBoth}
                      onChange={(e) => handleChange('earBoth', e.target.value)}
                      placeholder="71dB"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg font-mono text-center"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 mb-1">{lang === 'km' ? 'លទ្ធផល' : 'Result'}</label>
                    <input
                      type="text"
                      value={formData.earResult}
                      onChange={(e) => handleChange('earResult', e.target.value)}
                      placeholder="ត្រចៀកល្អប្រសើរ"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 mb-1">{lang === 'km' ? 'វេជ្ជបញ្ជា' : 'Rx'}</label>
                    <input
                      type="text"
                      value={formData.earPrescription}
                      onChange={(e) => handleChange('earPrescription', e.target.value)}
                      placeholder="វេជ្ជបញ្ជា"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 mb-1">{lang === 'km' ? 'ឧបករណ៍' : 'Device'}</label>
                    <input
                      type="text"
                      value={formData.earDevice}
                      onChange={(e) => handleChange('earDevice', e.target.value)}
                      placeholder="គ្មាន"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg"
                    />
                  </div>
                </div>
              </div>

              {/* Vaccine */}
              <div className="pt-4 border-t border-slate-200">
                <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2">
                  {lang === 'km' ? 'វ៉ាក់សាំង (Vaccination Records)' : 'Vaccination Records'}
                </h3>
                <div>
                  <input
                    type="text"
                    value={formData.vaccineList}
                    onChange={(e) => handleChange('vaccineList', e.target.value)}
                    placeholder="COVID-19, BCG, ស្អូច..."
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs"
                  />
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: Equity */}
          {activeTab === 'equity' && (
            <div className="space-y-4">
              <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                {lang === 'km' ? 'សមធម៌ និង ភាពក្រីក្រ (Equity & IDPoor)' : 'Equity & IDPoor Status'}
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">
                    {lang === 'km' ? 'គ្រួសារក្រីក្រ (Poor Family Status)' : 'IDPoor Level'}
                  </label>
                  <select
                    value={formData.equityFamily}
                    onChange={(e) => handleChange('equityFamily', e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg"
                  >
                    <option value="មិនក្រីក្រ">{lang === 'km' ? 'មិនក្រីក្រ (Non-Poor)' : 'Non-Poor'}</option>
                    <option value="ក្រ១">{lang === 'km' ? 'ក្រ១ (IDPoor Level 1 - ក្រីក្រខ្លាំង)' : 'IDPoor Level 1 (Very Poor)'}</option>
                    <option value="ក្រ២">{lang === 'km' ? 'ក្រ២ (IDPoor Level 2 - ក្រីក្រមធ្យម)' : 'IDPoor Level 2 (Medium Poor)'}</option>
                  </select>
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">
                    {lang === 'km' ? 'លេខបណ្ណសមធម៌' : 'Equity Card ID'}
                  </label>
                  <input
                    type="text"
                    value={formData.equityCard}
                    onChange={(e) => handleChange('equityCard', e.target.value)}
                    placeholder="EQ-0401-98214"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg font-mono"
                  />
                </div>
              </div>
            </div>
          )}

          {/* TAB 6: Parents & Guardian */}
          {activeTab === 'parents' && (
            <div className="space-y-6">
              {/* Father */}
              <div>
                <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2">
                  {lang === 'km' ? 'ព័ត៌មានឪពុក (Father)' : 'Father Information'}
                </h3>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                  <div>
                    <label className="block text-slate-600 mb-1">{lang === 'km' ? 'គោត្តនាម' : 'Last Name'}</label>
                    <input
                      type="text"
                      value={formData.fatherLastName}
                      onChange={(e) => handleChange('fatherLastName', e.target.value)}
                      placeholder="អ៊ុន"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 mb-1">{lang === 'km' ? 'នាម' : 'First Name'}</label>
                    <input
                      type="text"
                      value={formData.fatherFirstName}
                      onChange={(e) => handleChange('fatherFirstName', e.target.value)}
                      placeholder="ប៊ុនទុង"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 mb-1">{lang === 'km' ? 'ទូរស័ព្ទ' : 'Phone'}</label>
                    <input
                      type="text"
                      value={formData.fatherPhone}
                      onChange={(e) => handleChange('fatherPhone', e.target.value)}
                      placeholder="012 345 678"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 mb-1">{lang === 'km' ? 'មុខរបរ' : 'Occupation'}</label>
                    <input
                      type="text"
                      value={formData.fatherOccupation}
                      onChange={(e) => handleChange('fatherOccupation', e.target.value)}
                      placeholder="គ្រូបង្រៀន"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg"
                    />
                  </div>
                </div>
              </div>

              {/* Mother */}
              <div className="pt-4 border-t border-slate-200">
                <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2">
                  {lang === 'km' ? 'ព័ត៌មានម្ដាយ (Mother)' : 'Mother Information'}
                </h3>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                  <div>
                    <label className="block text-slate-600 mb-1">{lang === 'km' ? 'គោត្តនាម' : 'Last Name'}</label>
                    <input
                      type="text"
                      value={formData.motherLastName}
                      onChange={(e) => handleChange('motherLastName', e.target.value)}
                      placeholder="រ៉ម"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 mb-1">{lang === 'km' ? 'នាម' : 'First Name'}</label>
                    <input
                      type="text"
                      value={formData.motherFirstName}
                      onChange={(e) => handleChange('motherFirstName', e.target.value)}
                      placeholder="សុផាត់"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 mb-1">{lang === 'km' ? 'ទូរស័ព្ទ' : 'Phone'}</label>
                    <input
                      type="text"
                      value={formData.motherPhone}
                      onChange={(e) => handleChange('motherPhone', e.target.value)}
                      placeholder="012 987 654"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 mb-1">{lang === 'km' ? 'មុខរបរ' : 'Occupation'}</label>
                    <input
                      type="text"
                      value={formData.motherOccupation}
                      onChange={(e) => handleChange('motherOccupation', e.target.value)}
                      placeholder="កសិករ"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg"
                    />
                  </div>
                </div>
              </div>

              {/* Guardian */}
              <div className="pt-4 border-t border-slate-200">
                <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2">
                  {lang === 'km' ? 'អាណាព្យាបាល (Guardian)' : 'Guardian Information'}
                </h3>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                  <div>
                    <label className="block text-slate-600 mb-1">{lang === 'km' ? 'ប្រភេទ' : 'Relation'}</label>
                    <input
                      type="text"
                      value={formData.guardianType}
                      onChange={(e) => handleChange('guardianType', e.target.value)}
                      placeholder="ឪពុក / ម្ដាយ / មីង..."
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 mb-1">{lang === 'km' ? 'គោត្តនាម' : 'Last Name'}</label>
                    <input
                      type="text"
                      value={formData.guardianLastName}
                      onChange={(e) => handleChange('guardianLastName', e.target.value)}
                      placeholder="គោត្តនាម"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 mb-1">{lang === 'km' ? 'នាម' : 'First Name'}</label>
                    <input
                      type="text"
                      value={formData.guardianFirstName}
                      onChange={(e) => handleChange('guardianFirstName', e.target.value)}
                      placeholder="នាម"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 mb-1">{lang === 'km' ? 'ទូរស័ព្ទ' : 'Phone'}</label>
                    <input
                      type="text"
                      value={formData.guardianPhone}
                      onChange={(e) => handleChange('guardianPhone', e.target.value)}
                      placeholder="012 345 678"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg font-mono"
                    />
                  </div>
                  <div className="sm:col-span-4">
                    <label className="block text-slate-600 mb-1">{lang === 'km' ? 'អាសយដ្ឋានអាណាព្យាបាល' : 'Guardian Address'}</label>
                    <input
                      type="text"
                      value={formData.guardianAddress}
                      onChange={(e) => handleChange('guardianAddress', e.target.value)}
                      placeholder="ភូមិ... ឃុំ... ស្រុក... ខេត្ត..."
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Datalist for provinces */}
          <datalist id="cambodia-provinces">
            {CAMBODIA_PROVINCES.map((p) => (
              <option key={p} value={p} />
            ))}
          </datalist>

          {/* Modal Footer Actions */}
          <div className="pt-4 border-t border-slate-200 flex items-center justify-between">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-700 hover:text-slate-900 bg-white border border-slate-200 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
            >
              {lang === 'km' ? 'បោះបង់' : 'Cancel'}
            </button>
            <button
              type="submit"
              className="inline-flex items-center gap-1.5 px-5 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors shadow-xs cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>{lang === 'km' ? 'រក្សាទុកទិន្នន័យ' : 'Save Record'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
