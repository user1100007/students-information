import React, { useRef } from 'react';
import {
  X,
  Printer,
  Edit2,
  Calendar,
  Phone,
  MapPin,
  Heart,
  Eye,
  Volume2,
  ShieldAlert,
  User,
  Users,
  Award,
} from 'lucide-react';
import { StudentRecord, Language } from '../types/student';
import { calculateBMI } from '../utils/exportImport';

interface StudentDetailModalProps {
  student: StudentRecord | null;
  lang: Language;
  onClose: () => void;
  onEdit: (student: StudentRecord) => void;
}

export const StudentDetailModal: React.FC<StudentDetailModalProps> = ({
  student,
  lang,
  onClose,
  onEdit,
}) => {
  const printAreaRef = useRef<HTMLDivElement>(null);

  if (!student) return null;

  const handlePrintDossier = () => {
    window.print();
  };

  const bmiSem1 = calculateBMI(student.weightSem1, student.heightSem1);
  const bmiSem2 = calculateBMI(student.weightSem2, student.heightSem2);

  const isFemale =
    student.gender === 'ស្រី' ||
    student.gender.toLowerCase() === 'female' ||
    student.gender === 'f';

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-4xl max-h-[92vh] flex flex-col overflow-hidden border border-slate-200">
        {/* Modal Header */}
        <div className="no-print p-4 sm:p-6 border-b border-slate-200 flex items-center justify-between gap-4 bg-slate-50/70">
          <div className="flex items-center gap-3">
            <div
              className={`w-12 h-12 rounded-xl flex items-center justify-center text-lg font-bold ${
                isFemale ? 'bg-pink-100 text-pink-700' : 'bg-blue-100 text-blue-700'
              }`}
            >
              {student.lastName.charAt(0) || 'ស'}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-bold text-slate-900">
                  {student.lastName} {student.firstName}
                </h2>
                <span className="text-xs font-mono font-medium bg-slate-200 text-slate-700 px-2 py-0.5 rounded">
                  {student.studentCode || 'N/A'}
                </span>
              </div>
              <div className="text-xs text-slate-500 flex items-center gap-2 mt-0.5">
                <span>{student.gender}</span>
                <span aria-hidden="true">·</span>
                <span>{student.academicYear || '2025-2026'}</span>
                {student.previousGrade && (
                  <>
                    <span aria-hidden="true">·</span>
                    <span>{lang === 'km' ? `ថ្នាក់ ${student.previousGrade}` : `Grade ${student.previousGrade}`}</span>
                  </>
                )}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrintDossier}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 hover:text-slate-900 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>{lang === 'km' ? 'បោះពុម្ពជីវប្រវត្តិ' : 'Print Profile'}</span>
            </button>
            <button
              onClick={() => onEdit(student)}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-blue-700 rounded-lg hover:bg-blue-800 transition-colors cursor-pointer"
            >
              <Edit2 className="w-3.5 h-3.5" />
              <span>{lang === 'km' ? 'កែប្រែ' : 'Edit'}</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-200/60 transition-colors cursor-pointer ml-1"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Scrollable Body */}
        <div ref={printAreaRef} className="p-5 sm:p-7 overflow-y-auto space-y-6">
          {/* Printable Official Heading */}
          <div className="hidden print:block text-center border-b pb-4 mb-4">
            <div className="font-bold text-base">ព្រះរាជាណាចក្រកម្ពុជា</div>
            <div className="text-sm">ជាតិ សាសនា ព្រះមហាក្សត្រ</div>
            <div className="text-xs text-slate-600 mt-2">ក្រសួងអប់រំ យុវជន និងកីឡា · ព័ត៌មានសិស្ស</div>
            <div className="text-lg font-bold mt-2">សន្លឹកជីវប្រវត្តិសិស្ស</div>
          </div>

          {/* Section 1: Core Details */}
          <div>
            <h3 className="text-xs font-bold text-blue-900 uppercase tracking-wider mb-3 flex items-center gap-1.5 border-b pb-1">
              <User className="w-4 h-4 text-blue-700" />
              <span>{lang === 'km' ? 'ព័ត៌មានទូទៅរបស់សិស្ស' : 'Core Identification'}</span>
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
              <div>
                <span className="text-slate-400 block">{lang === 'km' ? 'អត្តលេខ' : 'Student ID'}</span>
                <span className="font-mono font-semibold text-slate-800">{student.studentCode || '—'}</span>
              </div>
              <div>
                <span className="text-slate-400 block">{lang === 'km' ? 'ឈ្មោះពេញ' : 'Full Name'}</span>
                <span className="font-semibold text-slate-900">{student.lastName} {student.firstName}</span>
              </div>
              <div>
                <span className="text-slate-400 block">{lang === 'km' ? 'ភេទ' : 'Gender'}</span>
                <span className="text-slate-800 font-medium">{student.gender || '—'}</span>
              </div>
              <div>
                <span className="text-slate-400 block">{lang === 'km' ? 'ថ្ងៃខែឆ្នាំកំណើត' : 'Date of Birth'}</span>
                <span className="text-slate-800 font-mono">{student.dob || '—'}</span>
              </div>
              <div>
                <span className="text-slate-400 block">{lang === 'km' ? 'ទូរស័ព្ទ' : 'Phone'}</span>
                <span className="text-slate-800 font-mono">
                  {student.phone ? (
                    <a href={`tel:${student.phone}`} className="text-blue-600 hover:underline">
                      {student.phone}
                    </a>
                  ) : (
                    '—'
                  )}
                </span>
              </div>
              <div>
                <span className="text-slate-400 block">{lang === 'km' ? 'សញ្ជាតិ' : 'Nationality'}</span>
                <span className="text-slate-800">{student.nationality || 'ខ្មែរ'}</span>
              </div>
              <div>
                <span className="text-slate-400 block">{lang === 'km' ? 'ជនជាតិភាគតិច' : 'Ethnic Minority'}</span>
                <span className="text-slate-800">{student.ethnicMinority || 'គ្មាន'}</span>
              </div>
              <div>
                <span className="text-slate-400 block">{lang === 'km' ? 'លក្ខណៈពិសេស' : 'Special Talent'}</span>
                <span className="text-slate-800">{student.specialTrait || 'គ្មាន'}</span>
              </div>
            </div>
          </div>

          {/* Section 2: Addresses */}
          <div>
            <h3 className="text-xs font-bold text-blue-900 uppercase tracking-wider mb-3 flex items-center gap-1.5 border-b pb-1">
              <MapPin className="w-4 h-4 text-blue-700" />
              <span>{lang === 'km' ? 'ទីកន្លែងកំណើត និង អាសយដ្ឋានបច្ចុប្បន្ន' : 'Place of Birth & Current Address'}</span>
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200/80">
                <span className="font-semibold text-slate-800 block mb-1">
                  {lang === 'km' ? 'ទីកន្លែងកំណើត' : 'Place of Birth'}
                </span>
                <div className="text-slate-600 space-y-0.5">
                  <div>ភូមិ {student.pobVillage || '—'} ឃុំ/សង្កាត់ {student.pobCommune || '—'}</div>
                  <div>ស្រុក/ខណ្ឌ {student.pobDistrict || '—'} ខេត្ត/ក្រុង {student.pobProvince || '—'}</div>
                </div>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200/80">
                <span className="font-semibold text-slate-800 block mb-1">
                  {lang === 'km' ? 'អាសយដ្ឋានបច្ចុប្បន្ន' : 'Current Residence'}
                </span>
                <div className="text-slate-600 space-y-0.5">
                  <div>ភូមិ {student.curVillage || '—'} ឃុំ/សង្កាត់ {student.curCommune || '—'}</div>
                  <div>ស្រុក/ខណ្ឌ {student.curDistrict || '—'} ខេត្ត/ក្រុង {student.curProvince || '—'}</div>
                </div>
              </div>
            </div>
          </div>

          {/* Section 3: Academic & Equity */}
          <div>
            <h3 className="text-xs font-bold text-blue-900 uppercase tracking-wider mb-3 flex items-center gap-1.5 border-b pb-1">
              <Award className="w-4 h-4 text-blue-700" />
              <span>{lang === 'km' ? 'ព័ត៌មានសិក្សា និង សមធម៌សង្គម' : 'Academic & Equity Support'}</span>
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
              <div>
                <span className="text-slate-400 block">{lang === 'km' ? 'ឆ្នាំសិក្សា' : 'Academic Year'}</span>
                <span className="font-mono text-slate-800">{student.academicYear || '—'}</span>
              </div>
              <div>
                <span className="text-slate-400 block">{lang === 'km' ? 'ថ្នាក់ឆ្នាំមុន' : 'Previous Grade'}</span>
                <span className="font-semibold text-slate-800">{student.previousGrade || '—'}</span>
              </div>
              <div>
                <span className="text-slate-400 block">{lang === 'km' ? 'ថ្ងៃចុះឈ្មោះ' : 'Enrollment Date'}</span>
                <span className="font-mono text-slate-800">{student.enrollmentDate || '—'}</span>
              </div>
              <div>
                <span className="text-slate-400 block">{lang === 'km' ? 'ពិការភាព' : 'Disability'}</span>
                <span className="text-slate-800">{student.disabilityType || 'គ្មាន'}</span>
              </div>
              <div>
                <span className="text-slate-400 block">{lang === 'km' ? 'គ្រួសារក្រីក្រ' : 'Equity Status'}</span>
                <span className="font-semibold text-amber-700">{student.equityFamily || 'មិនក្រីក្រ'}</span>
              </div>
              <div>
                <span className="text-slate-400 block">{lang === 'km' ? 'បណ្ណសមធម៌' : 'Equity Card ID'}</span>
                <span className="font-mono text-slate-800">{student.equityCard || '—'}</span>
              </div>
              <div>
                <span className="text-slate-400 block">{lang === 'km' ? 'កញ្ចប់អំណាន/គណិត' : 'Learning Kits'}</span>
                <span className="text-slate-800">
                  {student.kitReading || student.kitMath ? 'បានទទួល' : 'មិនបានទទួល'}
                </span>
              </div>
              <div>
                <span className="text-slate-400 block">{lang === 'km' ? 'សៀវភៅជំនួយ' : 'Supplementary Books'}</span>
                <span className="text-slate-800">
                  {student.kitKhmerBook || student.kitMathBook ? 'មាន' : 'គ្មាន'}
                </span>
              </div>
            </div>
          </div>

          {/* Section 4: Health, BMI & Screenings */}
          <div>
            <h3 className="text-xs font-bold text-blue-900 uppercase tracking-wider mb-3 flex items-center gap-1.5 border-b pb-1">
              <Heart className="w-4 h-4 text-blue-700" />
              <span>{lang === 'km' ? 'ការតាមដានសុខភាព និងការលូតលាស់' : 'Health & Growth Tracking'}</span>
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              {/* Semester 1 Growth */}
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200/80">
                <span className="font-semibold text-slate-800 block mb-2">
                  {lang === 'km' ? 'ឆមាសទី១ (Semester 1)' : 'Semester 1 Physical'}
                </span>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <span className="text-slate-400 block">{lang === 'km' ? 'ទម្ងន់' : 'Weight'}:</span>
                    <span className="font-mono font-medium text-slate-800">
                      {student.weightSem1 ? `${student.weightSem1} kg` : '—'}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-400 block">{lang === 'km' ? 'កម្ពស់' : 'Height'}:</span>
                    <span className="font-mono font-medium text-slate-800">
                      {student.heightSem1 ? `${student.heightSem1} cm` : '—'}
                    </span>
                  </div>
                  {bmiSem1.bmi && (
                    <div className="col-span-2 pt-1 border-t border-slate-200 mt-1">
                      <span className="text-slate-500">BMI: </span>
                      <strong className="font-mono">{bmiSem1.bmi}</strong>
                      <span className="text-slate-500 ml-1">({lang === 'km' ? bmiSem1.labelKm : bmiSem1.labelEn})</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Semester 2 Growth */}
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200/80">
                <span className="font-semibold text-slate-800 block mb-2">
                  {lang === 'km' ? 'ឆមាសទី២ (Semester 2)' : 'Semester 2 Physical'}
                </span>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <span className="text-slate-400 block">{lang === 'km' ? 'ទម្ងន់' : 'Weight'}:</span>
                    <span className="font-mono font-medium text-slate-800">
                      {student.weightSem2 ? `${student.weightSem2} kg` : '—'}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-400 block">{lang === 'km' ? 'កម្ពស់' : 'Height'}:</span>
                    <span className="font-mono font-medium text-slate-800">
                      {student.heightSem2 ? `${student.heightSem2} cm` : '—'}
                    </span>
                  </div>
                  {bmiSem2.bmi && (
                    <div className="col-span-2 pt-1 border-t border-slate-200 mt-1">
                      <span className="text-slate-500">BMI: </span>
                      <strong className="font-mono">{bmiSem2.bmi}</strong>
                      <span className="text-slate-500 ml-1">({lang === 'km' ? bmiSem2.labelKm : bmiSem2.labelEn})</span>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Vision & Hearing */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs mt-3">
              {/* Vision */}
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200/80">
                <div className="flex items-center gap-1.5 font-semibold text-slate-800 mb-2">
                  <Eye className="w-3.5 h-3.5 text-blue-600" />
                  <span>{lang === 'km' ? 'ពិនិត្យភ្នែក' : 'Vision'}</span>
                </div>
                <div className="space-y-1 text-slate-600">
                  <div>ឆ្វេង: <strong className="font-mono">{student.eyeLeft || '—'}</strong> | ស្ដាំ: <strong className="font-mono">{student.eyeRight || '—'}</strong></div>
                  <div>លទ្ធផល: {student.eyeResult || '—'}</div>
                  {student.eyeDevice && <div>ឧបករណ៍: {student.eyeDevice}</div>}
                </div>
              </div>

              {/* Hearing */}
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200/80">
                <div className="flex items-center gap-1.5 font-semibold text-slate-800 mb-2">
                  <Volume2 className="w-3.5 h-3.5 text-purple-600" />
                  <span>{lang === 'km' ? 'ពិនិត្យត្រចៀក' : 'Hearing'}</span>
                </div>
                <div className="space-y-1 text-slate-600">
                  <div>ឆ្វេង: <strong className="font-mono">{student.earLeft || '—'}</strong> | ស្ដាំ: <strong className="font-mono">{student.earRight || '—'}</strong></div>
                  <div>លទ្ធផល: {student.earResult || '—'}</div>
                  {student.earDevice && <div>ឧបករណ៍: {student.earDevice}</div>}
                </div>
              </div>

              {/* Vaccines */}
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200/80">
                <div className="flex items-center gap-1.5 font-semibold text-slate-800 mb-2">
                  <ShieldAlert className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{lang === 'km' ? 'វ៉ាក់សាំង' : 'Vaccines'}</span>
                </div>
                <div className="text-slate-600">
                  {student.vaccineList ? student.vaccineList : 'មិនទាន់មានទិន្នន័យ'}
                </div>
              </div>
            </div>
          </div>

          {/* Section 5: Parents & Guardian */}
          <div>
            <h3 className="text-xs font-bold text-blue-900 uppercase tracking-wider mb-3 flex items-center gap-1.5 border-b pb-1">
              <Users className="w-4 h-4 text-blue-700" />
              <span>{lang === 'km' ? 'ព័ត៌មានឪពុក ម្ដាយ និងអាណាព្យាបាល' : 'Parents & Guardian Contacts'}</span>
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
              {/* Father */}
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200/80">
                <span className="font-semibold text-slate-800 block mb-1">
                  {lang === 'km' ? 'ឪពុក' : 'Father'}
                </span>
                <div className="space-y-1 text-slate-600">
                  <div>ឈ្មោះ: <strong>{student.fatherLastName} {student.fatherFirstName || '—'}</strong></div>
                  <div>មុខរបរ: {student.fatherOccupation || '—'}</div>
                  <div>ទូរស័ព្ទ: {student.fatherPhone ? <a href={`tel:${student.fatherPhone}`} className="text-blue-600 hover:underline">{student.fatherPhone}</a> : '—'}</div>
                </div>
              </div>

              {/* Mother */}
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200/80">
                <span className="font-semibold text-slate-800 block mb-1">
                  {lang === 'km' ? 'ម្ដាយ' : 'Mother'}
                </span>
                <div className="space-y-1 text-slate-600">
                  <div>ឈ្មោះ: <strong>{student.motherLastName} {student.motherFirstName || '—'}</strong></div>
                  <div>មុខរបរ: {student.motherOccupation || '—'}</div>
                  <div>ទូរស័ព្ទ: {student.motherPhone ? <a href={`tel:${student.motherPhone}`} className="text-blue-600 hover:underline">{student.motherPhone}</a> : '—'}</div>
                </div>
              </div>

              {/* Guardian */}
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200/80">
                <span className="font-semibold text-slate-800 block mb-1">
                  {lang === 'km' ? 'អាណាព្យាបាល' : 'Guardian'}
                </span>
                <div className="space-y-1 text-slate-600">
                  <div>ប្រភេទ: {student.guardianType || '—'}</div>
                  <div>ឈ្មោះ: <strong>{student.guardianLastName} {student.guardianFirstName || '—'}</strong></div>
                  <div>ទូរស័ព្ទ: {student.guardianPhone ? <a href={`tel:${student.guardianPhone}`} className="text-blue-600 hover:underline">{student.guardianPhone}</a> : '—'}</div>
                  {student.guardianAddress && <div className="text-slate-500 text-[11px] mt-1">{student.guardianAddress}</div>}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="no-print p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-700 hover:text-slate-900 bg-white border border-slate-200 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
          >
            {lang === 'km' ? 'បិទ' : 'Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
