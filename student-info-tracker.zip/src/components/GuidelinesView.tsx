import React from 'react';
import { BookOpen, Download, FileSpreadsheet, CheckCircle2 } from 'lucide-react';
import { GROUPS } from '../data/initialData';
import { Language } from '../types/student';
import { downloadTemplate } from '../utils/exportImport';

interface GuidelinesViewProps {
  lang: Language;
}

export const GuidelinesView: React.FC<GuidelinesViewProps> = ({ lang }) => {
  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Banner */}
      <div className="p-6 bg-white rounded-2xl border border-slate-200/90 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-slate-900 mb-1">
            {lang === 'km' ? 'សេចក្ដីណែនាំអំពីទម្រង់ព័ត៌មានសិស្ស (MoEYS SIS)' : 'MoEYS Student Information Guidelines'}
          </h2>
          <p className="text-xs text-slate-500">
            {lang === 'km'
              ? 'ស្តង់ដារគ្រប់គ្រងទិន្នន័យសិស្សបឋម និងមធ្យមសិក្សា ១៧ ផ្នែក និង ៦៥ ជួរឈរ'
              : 'Standardized 17 groups and 65 columns for primary and secondary education'}
          </p>
        </div>

        <button
          onClick={() => downloadTemplate(lang)}
          className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg transition-colors shadow-xs cursor-pointer shrink-0"
        >
          <FileSpreadsheet className="w-4 h-4" />
          <span>{lang === 'km' ? 'ទាញយកគំរូ Excel ស្ដង់ដារ' : 'Download Excel Template'}</span>
        </button>
      </div>

      {/* 17 Groups Table */}
      <div className="bg-white rounded-xl border border-slate-200/90 shadow-2xs p-5">
        <h3 className="text-sm font-bold text-slate-900 mb-4 flex items-center gap-2">
          <BookOpen className="w-4 h-4 text-blue-700" />
          <span>{lang === 'km' ? 'តារាងសង្ខេបផ្នែកទាំង ១៧ និង ៦៥ ជួរឈរ' : 'Summary of 17 Groups (65 Columns)'}</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          {GROUPS.map((group, idx) => (
            <div key={group.id} className="p-3 bg-slate-50 rounded-lg border border-slate-200">
              <div className="flex items-center justify-between font-semibold text-slate-800 mb-2">
                <span>
                  {idx + 1}. {lang === 'km' ? group.titleKm : group.titleEn}
                </span>
                <span className="font-mono text-slate-500 font-normal">
                  {group.columns.length} {lang === 'km' ? 'ជួរឈរ' : 'cols'}
                </span>
              </div>
              <div className="flex flex-wrap gap-1">
                {group.columns.map((col) => (
                  <span
                    key={col.id}
                    className="bg-white border border-slate-200 px-2 py-0.5 rounded text-[11px] text-slate-600"
                  >
                    {lang === 'km' ? col.labelKm : col.labelEn}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Explanatory notes */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
        <div className="p-4 bg-white rounded-xl border border-slate-200/90 shadow-2xs">
          <h4 className="font-bold text-slate-900 mb-1 flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-blue-600" />
            <span>{lang === 'km' ? 'ការពិនិត្យភ្នែក (Vision)' : 'Eye Testing (Snellen)'}</span>
          </h4>
          <p className="text-slate-600 leading-relaxed">
            {lang === 'km'
              ? 'ស្តង់ដារ 6/6 បង្ហាញថាគំហើញធម្មតា។ ប្រសិនបើ 6/9 ឬ 6/12 ឡើងទៅ សាលាត្រូវណែនាំអាណាព្យាបាលបញ្ជូនសិស្សទៅពិនិត្យបន្ថែមនៅមន្ទីរពេទ្យភ្នែក។'
              : 'Standard 6/6 indicates normal vision. Values like 6/9 or 6/12 recommend eye clinic referral.'}
          </p>
        </div>

        <div className="p-4 bg-white rounded-xl border border-slate-200/90 shadow-2xs">
          <h4 className="font-bold text-slate-900 mb-1 flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-amber-600" />
            <span>{lang === 'km' ? 'បណ្ណសមធម៌ (IDPoor)' : 'Equity & IDPoor'}</span>
          </h4>
          <p className="text-slate-600 leading-relaxed">
            {lang === 'km'
              ? 'ក្រ១ (ក្រីក្រខ្លាំង) និង ក្រ២ (ក្រីក្រមធ្យម) ត្រូវបានកំណត់ដោយក្រសួងផែនការ។ សិស្សមានបណ្ណនេះទទួលបានអាហារូបករណ៍រដ្ឋ និងកញ្ចប់អាហារូបត្ថម្ភ។'
              : 'Poor 1 (very poor) and Poor 2 (medium poor) certified by Ministry of Planning for scholarship eligibility.'}
          </p>
        </div>

        <div className="p-4 bg-white rounded-xl border border-slate-200/90 shadow-2xs">
          <h4 className="font-bold text-slate-900 mb-1 flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            <span>{lang === 'km' ? 'ទម្ងន់ និង កម្ពស់ (BMI)' : 'Growth Tracking (BMI)'}</span>
          </h4>
          <p className="text-slate-600 leading-relaxed">
            {lang === 'km'
              ? 'វាស់វែង ២ ដងក្នុងមួយឆ្នាំសិក្សា (ឆមាសទី១ និងឆមាសទី២) ដើម្បីតាមដានអាហារូបត្ថម្ភ និងការលូតលាស់រាងកាយរបស់កុមារ។'
              : 'Measured twice per academic year (Semester 1 and Semester 2) to monitor child nutritional health.'}
          </p>
        </div>
      </div>
    </div>
  );
};
