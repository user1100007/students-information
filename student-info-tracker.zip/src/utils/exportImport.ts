import * as XLSX from 'xlsx';
import { StudentRecord, Language } from '../types/student';
import { GROUPS, studentToRawArray, rawArrayToStudent } from '../data/initialData';

// Generates an Excel workbook with merged group headers matching MoEYS format
export function exportToExcel(students: StudentRecord[], lang: Language = 'km', filename = 'students_information.xlsx') {
  // Row 1: Group headers with blanks for merged columns
  const groupHeaderRow: string[] = [];
  const columnHeaderRow: string[] = [];
  const merges: XLSX.Range[] = [];

  let colIdx = 0;
  for (const group of GROUPS) {
    const title = lang === 'km' ? group.titleKm : group.titleEn;
    groupHeaderRow.push(title);
    for (let i = 1; i < group.columns.length; i++) {
      groupHeaderRow.push('');
    }
    if (group.columns.length > 1) {
      merges.push({
        s: { r: 0, c: colIdx },
        e: { r: 0, c: colIdx + group.columns.length - 1 },
      });
    }
    colIdx += group.columns.length;

    for (const col of group.columns) {
      columnHeaderRow.push(lang === 'km' ? col.labelKm : col.labelEn);
    }
  }

  // Data rows
  const dataRows = students.map((std) => studentToRawArray(std));

  const allRows = [groupHeaderRow, columnHeaderRow, ...dataRows];

  const ws = XLSX.utils.aoa_to_sheet(allRows);
  ws['!merges'] = merges;

  // Auto-fit column widths
  const colWidths = columnHeaderRow.map((header) => ({
    wch: Math.max(header.length + 4, 12),
  }));
  ws['!cols'] = colWidths;

  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, lang === 'km' ? 'ព័ត៌មានសិស្ស' : 'Students');

  XLSX.writeFile(wb, filename);
}

// Exports CSV with UTF-8 BOM so Khmer unicode appears cleanly in MS Excel
export function exportToCsv(students: StudentRecord[], lang: Language = 'km', filename = 'students_information.csv') {
  const columnHeaders = GROUPS.flatMap((g) => g.columns.map((c) => lang === 'km' ? `${g.titleKm} - ${c.labelKm}` : `${g.titleEn} - ${c.labelEn}`));
  
  const rows = students.map((std) => {
    return studentToRawArray(std).map((val) => {
      const clean = (val || '').replace(/"/g, '""');
      return `"${clean}"`;
    }).join(',');
  });

  const headerLine = columnHeaders.map((h) => `"${h.replace(/"/g, '""')}"`).join(',');
  const csvContent = '\uFEFF' + [headerLine, ...rows].join('\r\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

// Generates a blank Excel template for school teachers to fill in
export function downloadTemplate(lang: Language = 'km') {
  const groupHeaderRow: string[] = [];
  const columnHeaderRow: string[] = [];
  const merges: XLSX.Range[] = [];

  let colIdx = 0;
  for (const group of GROUPS) {
    const title = lang === 'km' ? group.titleKm : group.titleEn;
    groupHeaderRow.push(title);
    for (let i = 1; i < group.columns.length; i++) {
      groupHeaderRow.push('');
    }
    if (group.columns.length > 1) {
      merges.push({
        s: { r: 0, c: colIdx },
        e: { r: 0, c: colIdx + group.columns.length - 1 },
      });
    }
    colIdx += group.columns.length;

    for (const col of group.columns) {
      columnHeaderRow.push(lang === 'km' ? col.labelKm : col.labelEn);
    }
  }

  // Add 1 sample empty row with instructions
  const sampleEmptyRow = columnHeaderRow.map((_, i) => (i === 0 ? '0001' : i === 1 ? 'គោត្តនាម' : i === 2 ? 'នាម' : ''));

  const ws = XLSX.utils.aoa_to_sheet([groupHeaderRow, columnHeaderRow, sampleEmptyRow]);
  ws['!merges'] = merges;
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Template');
  XLSX.writeFile(wb, 'students_template.xlsx');
}

// Parses an uploaded Excel or CSV file
export async function parseUploadedFile(file: File): Promise<StudentRecord[]> {
  const arrayBuffer = await file.arrayBuffer();
  const wb = XLSX.read(arrayBuffer, { type: 'array' });
  const firstSheetName = wb.SheetNames[0];
  const worksheet = wb.Sheets[firstSheetName];

  const rawRows = XLSX.utils.sheet_to_json<string[]>(worksheet, { header: 1 });
  if (rawRows.length < 2) {
    throw new Error('ឯកសារមិនមានទិន្នន័យគ្រប់គ្រាន់ទេ / File does not contain enough data.');
  }

  // Determine whether row 0 is group header and row 1 is column header
  let dataStartIndex = 1;
  const firstRow = rawRows[0] || [];
  const secondRow = rawRows[1] || [];

  // If first row contains group names like "ព័ត៌មានសិស្ស" or "Student Information", data begins on row 2
  if (firstRow.some((cell) => typeof cell === 'string' && (cell.includes('ព័ត៌មានសិស្ស') || cell.includes('Student')))) {
    dataStartIndex = 2;
  } else if (secondRow.some((cell) => typeof cell === 'string' && (cell.includes('អត្តលេខ') || cell.includes('Student ID')))) {
    dataStartIndex = 2;
  }

  const results: StudentRecord[] = [];
  for (let r = dataStartIndex; r < rawRows.length; r++) {
    const row = rawRows[r];
    if (!row || row.length === 0 || row.every((c) => !c || String(c).trim() === '')) {
      continue;
    }
    const student = rawArrayToStudent(row.map((c) => (c !== undefined && c !== null ? String(c) : '')));
    if (student.lastName || student.firstName || student.studentCode) {
      results.push(student);
    }
  }

  return results;
}

// Calculate BMI helper
export function calculateBMI(weightKg: string, heightCm: string): { bmi: number | null; labelKm: string; labelEn: string; status: 'under' | 'normal' | 'over' | 'unknown' } {
  const w = parseFloat(weightKg);
  const h = parseFloat(heightCm) / 100; // convert cm to meters
  if (isNaN(w) || isNaN(h) || w <= 0 || h <= 0) {
    return { bmi: null, labelKm: 'មិនទាន់វាស់វែង', labelEn: 'Not measured', status: 'unknown' };
  }
  const bmiVal = Math.round((w / (h * h)) * 10) / 10;
  if (bmiVal < 14) {
    return { bmi: bmiVal, labelKm: 'កង្វះទម្ងន់ (Underweight)', labelEn: 'Underweight', status: 'under' };
  } else if (bmiVal <= 18.5) {
    return { bmi: bmiVal, labelKm: 'ទម្ងន់សមស្រប (Normal)', labelEn: 'Normal weight', status: 'normal' };
  } else {
    return { bmi: bmiVal, labelKm: 'លើសទម្ងន់ (Overweight)', labelEn: 'Overweight', status: 'over' };
  }
}

export interface RawExtractedSheet {
  headers: string[];
  rows: string[][];
}

/**
 * Reads any uploaded spreadsheet and extracts raw headers & rows for smart column mapping.
 */
export async function readRawSpreadsheet(file: File): Promise<RawExtractedSheet> {
  const arrayBuffer = await file.arrayBuffer();
  const wb = XLSX.read(arrayBuffer, { type: 'array' });
  const sheetName = wb.SheetNames[0];
  const worksheet = wb.Sheets[sheetName];
  const rawRows = XLSX.utils.sheet_to_json<string[]>(worksheet, { header: 1 });

  if (rawRows.length === 0) {
    throw new Error('ឯកសារទទេ មិនមានទិន្នន័យ / Empty spreadsheet file');
  }

  // Find header row (the first row with multiple non-empty text cells)
  let headerIdx = 0;
  for (let i = 0; i < Math.min(rawRows.length, 5); i++) {
    const row = rawRows[i] || [];
    const textCount = row.filter((c) => typeof c === 'string' && c.trim().length > 0).length;
    if (textCount >= 3) {
      headerIdx = i;
      break;
    }
  }

  const headerRow = (rawRows[headerIdx] || []).map((h, i) => (h ? String(h).trim() : `ជួរឈរ ${i + 1}`));
  const dataRows: string[][] = [];

  for (let r = headerIdx + 1; r < rawRows.length; r++) {
    const row = rawRows[r];
    if (!row || row.length === 0 || row.every((c) => !c || String(c).trim() === '')) {
      continue;
    }
    const cleanRow = headerRow.map((_, colIdx) => (row[colIdx] !== undefined && row[colIdx] !== null ? String(row[colIdx]).trim() : ''));
    dataRows.push(cleanRow);
  }

  return { headers: headerRow, rows: dataRows };
}

/**
 * Parses raw copied table text (from Excel clipboard TSV or CSV).
 */
export function parsePastedTableText(text: string): RawExtractedSheet {
  const lines = text.trim().split(/\r?\n/).filter((l) => l.trim().length > 0);
  if (lines.length === 0) {
    throw new Error('សូមបិទភ្ជាប់ទិន្នន័យជាមុនសិន / Please paste data first');
  }

  const delimiter = lines[0].includes('\t') ? '\t' : ',';
  const rawRows = lines.map((l) => l.split(delimiter).map((c) => c.replace(/^"|"$/g, '').trim()));
  const headers = rawRows[0];
  const dataRows = rawRows.slice(1);

  return { headers, rows: dataRows };
}

/**
 * Options for column discrepancies & splitting when importing from old or extracted systems.
 */
export interface ColumnTransformOptions {
  autoSplitFullName: boolean; // Split "គោត្តនាម-នាម" or full name by first space
  autoStandardizeGender: boolean; // Map M/F, 1/2, Boy/Girl -> ប្រុស/ស្រី
  autoCalculateFields: boolean; // Auto-compute Age, BMI, Ears & Eyes
  columnMap: Record<string, keyof StudentRecord | 'fullName' | 'ignore'>;
}

/**
 * Intelligently transforms raw extracted rows into StudentRecord array.
 */
export function transformExtractedRowsToStudents(
  sheet: RawExtractedSheet,
  options: ColumnTransformOptions
): StudentRecord[] {
  const { headers, rows } = sheet;
  const results: StudentRecord[] = [];

  rows.forEach((row, rowIdx) => {
    const record: Record<string, any> = {
      id: `imp-${Date.now()}-${rowIdx + 1}`,
      studentCode: '',
      lastName: '',
      firstName: '',
      gender: 'ប្រុស',
      dob: '',
      phone: '',
      nationality: 'ខ្មែរ',
      pobProvince: '',
      pobDistrict: '',
      pobCommune: '',
      pobVillage: '',
      curProvince: '',
      curDistrict: '',
      curCommune: '',
      curVillage: '',
      academicYear: '២០២៥-២០២៦',
      previousGrade: '',
      enrollmentDate: '',
      disabilityType: '',
      kitReading: '',
      kitMath: '',
      kitKhmerBook: '',
      kitMathBook: '',
      equityFamily: '',
      equityCard: '',
      orphanStatus: '',
      scholarship: '',
      transferInDate: '',
      transferOutDate: '',
      stopDate: '',
      stopReason: '',
      fatherName: '',
      fatherAlive: 'រស់',
      fatherOccupation: '',
      motherName: '',
      motherAlive: 'រស់',
      motherOccupation: '',
      guardianName: '',
      guardianRelation: '',
      guardianPhone: '',
      travelMethod: 'ថ្មើរជើង',
      travelTime: '',
      travelDistance: '',
      hasKindergarten: 'គ្មាន',
      weightSem1: '',
      heightSem1: '',
      bmiSem1: '',
      bmiStatusSem1: '',
      weightSem2: '',
      heightSem2: '',
      bmiSem2: '',
      bmiStatusSem2: '',
      eyeLeft: '',
      eyeRight: '',
      eyeResult: '',
      earLeft: '',
      earRight: '',
      earResult: '',
      oralHealth: 'ធម្មតា',
      dewormingSem1: '',
      dewormingSem2: '',
      notes: '',
    };

    let fullNameVal = '';

    headers.forEach((h, colIdx) => {
      const val = row[colIdx] || '';
      const mappedTarget = options.columnMap[h];

      if (!mappedTarget || mappedTarget === 'ignore') return;

      if (mappedTarget === 'fullName') {
        fullNameVal = val;
      } else {
        (record as any)[mappedTarget] = val;
      }
    });

    // Handle Full Name Splitting (ខុសបំបែកជួរឈរ)
    if (fullNameVal) {
      if (options.autoSplitFullName) {
        const parts = fullNameVal.trim().split(/\s+/);
        if (parts.length > 1) {
          record.lastName = record.lastName || parts[0];
          record.firstName = record.firstName || parts.slice(1).join(' ');
        } else {
          record.lastName = record.lastName || fullNameVal.trim();
          record.firstName = record.firstName || '';
        }
      } else {
        record.lastName = record.lastName || fullNameVal;
      }
    }

    // Standardize Gender
    if (options.autoStandardizeGender && record.gender) {
      const g = record.gender.toString().trim().toLowerCase();
      if (['f', 'female', 'ស្រី', '2', 'girl', 'ស'].includes(g)) {
        record.gender = 'ស្រី';
      } else if (['m', 'male', 'ប្រុស', '1', 'boy', 'ប'].includes(g)) {
        record.gender = 'ប្រុស';
      }
    }

    // Generate fallback student code if empty
    if (!record.studentCode) {
      record.studentCode = `000${rowIdx + 1}`.slice(-4);
    }

    let finalStudent = record as StudentRecord;

    // Auto-calculate Age, BMI, Sensory results
    if (options.autoCalculateFields) {
      // Inline calculations
      if (finalStudent.dob) {
        const match = String(finalStudent.dob).match(/\b(19\d\d|20\d\d)\b/);
        if (match) {
          const yr = parseInt(match[1], 10);
          finalStudent.age = 2026 - yr;
        }
      }

      if (finalStudent.weightSem1 && finalStudent.heightSem1) {
        const w = parseFloat(String(finalStudent.weightSem1).replace(',', '.'));
        let h = parseFloat(String(finalStudent.heightSem1).replace(',', '.'));
        if (h < 3) h = h * 100;
        if (!isNaN(w) && !isNaN(h) && w > 0 && h > 0) {
          const hm = h / 100;
          const bmiVal = Number((w / (hm * hm)).toFixed(1));
          finalStudent.bmiSem1 = String(bmiVal);
          if (bmiVal < 12.5) finalStudent.bmiStatusSem1 = 'ស្គមខ្លាំង';
          else if (bmiVal < 14.0) finalStudent.bmiStatusSem1 = 'ស្គម';
          else if (bmiVal <= 18.5) finalStudent.bmiStatusSem1 = 'ទម្ងន់ធម្មតា';
          else if (bmiVal <= 21.0) finalStudent.bmiStatusSem1 = 'លើសទម្ងន់';
          else finalStudent.bmiStatusSem1 = 'ធាត់';
        }
      }

      if (finalStudent.weightSem2 && finalStudent.heightSem2) {
        const w = parseFloat(String(finalStudent.weightSem2).replace(',', '.'));
        let h = parseFloat(String(finalStudent.heightSem2).replace(',', '.'));
        if (h < 3) h = h * 100;
        if (!isNaN(w) && !isNaN(h) && w > 0 && h > 0) {
          const hm = h / 100;
          const bmiVal = Number((w / (hm * hm)).toFixed(1));
          finalStudent.bmiSem2 = String(bmiVal);
          if (bmiVal < 12.5) finalStudent.bmiStatusSem2 = 'ស្គមខ្លាំង';
          else if (bmiVal < 14.0) finalStudent.bmiStatusSem2 = 'ស្គម';
          else if (bmiVal <= 18.5) finalStudent.bmiStatusSem2 = 'ទម្ងន់ធម្មតា';
          else if (bmiVal <= 21.0) finalStudent.bmiStatusSem2 = 'លើសទម្ងន់';
          else finalStudent.bmiStatusSem2 = 'ធាត់';
        }
      }

      if (finalStudent.eyeLeft || finalStudent.eyeRight) {
        const l = String(finalStudent.eyeLeft || '');
        const r = String(finalStudent.eyeRight || '');
        const isImpaired = ['6/9', '6/12', '6/15', '6/18', '6/21', 'ខ្សោយ'].some((p) => l.includes(p) || r.includes(p));
        finalStudent.eyeResult = isImpaired ? 'ខ្សោយគំហើញ' : 'ភ្នែកល្អ';
      }

      if (finalStudent.earLeft || finalStudent.earRight) {
        const l = parseFloat(String(finalStudent.earLeft || '').replace(/[^\d.]/g, ''));
        const r = parseFloat(String(finalStudent.earRight || '').replace(/[^\d.]/g, ''));
        if ((!isNaN(l) && l < 60) || (!isNaN(r) && r < 60)) {
          finalStudent.earResult = 'ខ្សោយការស្ដាប់';
        } else if (!isNaN(l) || !isNaN(r)) {
          finalStudent.earResult = 'ត្រចៀកល្អប្រសើរ';
        }
      }
    }

    if (finalStudent.lastName || finalStudent.firstName || finalStudent.studentCode) {
      results.push(finalStudent);
    }
  });

  return results;
}

