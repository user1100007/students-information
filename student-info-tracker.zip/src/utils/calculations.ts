import { StudentRecord } from '../types/student';

/**
 * Calculates student age from Date of Birth (supports DD/MM/YYYY, DD-MM-YYYY, YYYY-MM-DD).
 * Reference year defaults to 2026.
 */
export function calculateAge(dobStr: string, referenceYear = 2026): number | null {
  if (!dobStr) return null;
  const match = String(dobStr).match(/\b(19\d\d|20\d\d)\b/);
  if (!match) return null;
  const birthYear = parseInt(match[1], 10);
  if (isNaN(birthYear) || birthYear < 1950 || birthYear > referenceYear) return null;
  return referenceYear - birthYear;
}

/**
 * Computes BMI = weight / (height / 100)^2 and categorizes Cambodian child growth status:
 * < 12.5: ស្គមខ្លាំង (Severely Underweight)
 * 12.5 - 13.9: ស្គម (Underweight)
 * 14.0 - 18.5: ទម្ងន់ធម្មតា (Normal)
 * 18.6 - 21.0: លើសទម្ងន់ (Overweight)
 * > 21.0: ធាត់ (Obese)
 */
export function computeBMI(weightVal: string | number, heightVal: string | number): { bmi: string; status: string } {
  const w = typeof weightVal === 'number' ? weightVal : parseFloat(String(weightVal).replace(',', '.'));
  let h = typeof heightVal === 'number' ? heightVal : parseFloat(String(heightVal).replace(',', '.'));

  if (isNaN(w) || isNaN(h) || w <= 0 || h <= 0) {
    return { bmi: '', status: '' };
  }

  // Handle accidental meter inputs (e.g. 1.15m instead of 115cm)
  if (h < 3) {
    h = h * 100;
  }

  const heightM = h / 100;
  const bmiVal = w / (heightM * heightM);
  const bmi = Number(bmiVal.toFixed(1));

  let status = 'ទម្ងន់ធម្មតា';
  if (bmi < 12.5) {
    status = 'ស្គមខ្លាំង';
  } else if (bmi < 14.0) {
    status = 'ស្គម';
  } else if (bmi <= 18.5) {
    status = 'ទម្ងន់ធម្មតា';
  } else if (bmi <= 21.0) {
    status = 'លើសទម្ងន់';
  } else {
    status = 'ធាត់';
  }

  return { bmi: String(bmi), status };
}

/**
 * Evaluates vision screening result based on Snellen eye vision (e.g. 6/6, 6/7.5, 6/9, 6/12, 6/18, 6/21).
 * Normal: 6/6 or 6/7.5
 * Impaired: 6/9, 6/12, 6/15, 6/18, 6/21 or worse
 */
export function evaluateEyes(left?: string, right?: string, currentResult?: string): string {
  const l = String(left || '').trim();
  const r = String(right || '').trim();

  if (!l && !r) {
    return currentResult && currentResult.trim() !== '' ? currentResult.trim() : 'មិនទាន់បានពិនិត្យ';
  }

  const impairedPatterns = ['6/9', '6/12', '6/15', '6/18', '6/21', '6/24', '6/36', '6/60', 'ខ្សោយ'];
  const isImpaired = impairedPatterns.some((p) => l.includes(p) || r.includes(p));

  if (isImpaired) {
    return 'ខ្សោយគំហើញ';
  }

  if (l.includes('6/6') || r.includes('6/6') || l.includes('6/7.5') || r.includes('6/7.5')) {
    return 'ភ្នែកល្អ';
  }

  return currentResult && currentResult.trim() !== '' ? currentResult.trim() : 'ភ្នែកល្អ';
}

/**
 * Evaluates hearing screening result based on decibels (dB) (e.g. 70, 70dB, 65, 49, 45).
 * >= 60dB: ត្រចៀកល្អប្រសើរ
 * < 60dB: ខ្សោយការស្ដាប់
 */
export function evaluateHearing(left?: string | number, right?: string | number, currentResult?: string): string {
  const lStr = String(left || '').replace(/[^\d.]/g, '');
  const rStr = String(right || '').replace(/[^\d.]/g, '');
  const l = parseFloat(lStr);
  const r = parseFloat(rStr);

  if (isNaN(l) && isNaN(r)) {
    return currentResult && currentResult.trim() !== '' ? currentResult.trim() : 'មិនទាន់បានពិនិត្យ';
  }

  if ((!isNaN(l) && l < 60) || (!isNaN(r) && r < 60)) {
    return 'ខ្សោយការស្ដាប់';
  }

  return 'ត្រចៀកល្អប្រសើរ';
}

/**
 * Automatically calculates and synchronizes Age, BMI, Eye, and Ear evaluations on a student record.
 */
export function autoCalculateStudentFields(student: StudentRecord): StudentRecord {
  const updated = { ...student };

  // 1. Auto-calculate Age
  if (updated.dob) {
    const age = calculateAge(updated.dob);
    if (age !== null) {
      updated.age = age;
    }
  }

  // 2. Auto-calculate Semester 1 BMI & Status
  if (updated.weightSem1 || updated.heightSem1) {
    const sem1 = computeBMI(updated.weightSem1, updated.heightSem1);
    if (sem1.bmi) {
      updated.bmiSem1 = sem1.bmi;
      if (!updated.bmiStatusSem1 || updated.bmiStatusSem1 === 'មិនទាន់គណនា') {
        updated.bmiStatusSem1 = sem1.status;
      }
    }
  }

  // 3. Auto-calculate Semester 2 BMI & Status
  if (updated.weightSem2 || updated.heightSem2) {
    const sem2 = computeBMI(updated.weightSem2, updated.heightSem2);
    if (sem2.bmi) {
      updated.bmiSem2 = sem2.bmi;
      if (!updated.bmiStatusSem2 || updated.bmiStatusSem2 === 'មិនទាន់គណនា') {
        updated.bmiStatusSem2 = sem2.status;
      }
    }
  }

  // 4. Auto-evaluate Eyes
  if (updated.eyeLeft || updated.eyeRight) {
    updated.eyeResult = evaluateEyes(updated.eyeLeft, updated.eyeRight, updated.eyeResult);
  }

  // 5. Auto-evaluate Ears
  if (updated.earLeft || updated.earRight) {
    updated.earResult = evaluateHearing(updated.earLeft, updated.earRight, updated.earResult);
  }

  return updated;
}
