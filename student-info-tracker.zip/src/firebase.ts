import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getAuth,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  signInAnonymously,
  updateProfile,
  User,
} from 'firebase/auth';
import {
  getFirestore,
  collection,
  doc,
  setDoc,
  getDocs,
  deleteDoc,
  writeBatch,
  getDocFromServer,
  Timestamp,
} from 'firebase/firestore';
import { StudentRecord } from './types/student';
import firebaseConfig from '../firebase-applet-config.json';

// Initialize Firebase App
export const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);

// Initialize Auth
export const auth = getAuth(app);

// Initialize Firestore with configured databaseId if available
export const db = firebaseConfig.firestoreDatabaseId
  ? getFirestore(app, firebaseConfig.firestoreDatabaseId)
  : getFirestore(app);

// Validate connection
export async function testFirestoreConnection(): Promise<boolean> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    return true;
  } catch (err: unknown) {
    if (err instanceof Error && err.message.includes('the client is offline')) {
      console.warn('Firestore is offline or unreachable.');
      return false;
    }
    // Any other response means we connected to Firestore
    return true;
  }
}

// Student Firestore Collection reference
const STUDENTS_COLLECTION = 'students';

/**
 * Fetch all students from Firestore
 */
export async function loadStudentsFromCloud(): Promise<StudentRecord[]> {
  const colRef = collection(db, STUDENTS_COLLECTION);
  const snapshot = await getDocs(colRef);
  const list: StudentRecord[] = [];
  snapshot.forEach((d) => {
    list.push(d.data() as StudentRecord);
  });
  return list;
}

/**
 * Save a single student to Firestore
 */
export async function saveStudentToCloud(student: StudentRecord): Promise<void> {
  const studentRef = doc(db, STUDENTS_COLLECTION, student.id);
  await setDoc(studentRef, {
    ...student,
    cloudSyncedAt: new Date().toISOString(),
  }, { merge: true });
}

/**
 * Delete a student from Firestore
 */
export async function deleteStudentFromCloud(studentId: string): Promise<void> {
  const studentRef = doc(db, STUDENTS_COLLECTION, studentId);
  await deleteDoc(studentRef);
}

/**
 * Batch upload all students to Firestore
 */
export async function syncAllStudentsToCloud(students: StudentRecord[]): Promise<number> {
  let count = 0;
  // Firestore batch allows up to 500 operations
  const chunks: StudentRecord[][] = [];
  for (let i = 0; i < students.length; i += 400) {
    chunks.push(students.slice(i, i + 400));
  }

  for (const chunk of chunks) {
    const batch = writeBatch(db);
    chunk.forEach((student) => {
      const studentRef = doc(db, STUDENTS_COLLECTION, student.id);
      batch.set(studentRef, {
        ...student,
        cloudSyncedAt: new Date().toISOString(),
      }, { merge: true });
      count++;
    });
    await batch.commit();
  }

  return count;
}

export {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  signInAnonymously,
  updateProfile,
};
export type { User };
