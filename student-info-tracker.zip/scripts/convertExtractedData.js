// Script to parse the user's 285 extracted student rows into clean StudentRecord objects
const fs = require('fs');
const path = require('path');

// Helper to calculate age
function calculateAge(dobStr, referenceYear = 2026) {
  if (!dobStr) return null;
  const match = String(dobStr).match(/\b(19\d\d|20\d\d)\b/);
  if (!match) return null;
  const birthYear = parseInt(match[1], 10);
  if (isNaN(birthYear) || birthYear < 1950 || birthYear > referenceYear) return null;
  return referenceYear - birthYear;
}

// Helper to compute BMI
function computeBMI(weightVal, heightVal) {
  const w = parseFloat(weightVal);
  let h = parseFloat(heightVal);
  if (isNaN(w) || isNaN(h) || w <= 0 || h <= 0) {
    return { bmi: '', status: '' };
  }
  // If height was given in meters e.g. 1.15m or 1.5
  if (h < 3) {
    h = h * 100;
  }
  const bmiVal = w / Math.pow(h / 100, 2);
  const bmi = Number(bmiVal.toFixed(1));
  let status = 'ទម្ងន់ធម្មតា';
  if (bmi < 12.5) status = 'ស្គមខ្លាំង';
  else if (bmi < 14.0) status = 'ស្គម';
  else if (bmi <= 18.5) status = 'ទម្ងន់ធម្មតា';
  else if (bmi <= 21.0) status = 'លើសទម្ងន់';
  else status = 'ធាត់';

  return { bmi: String(bmi), status };
}

// Helper to evaluate eyes
function evaluateEyes(left, right, existingResult) {
  if (existingResult && existingResult.trim() !== '') return existingResult.trim();
  const l = String(left || '').trim();
  const r = String(right || '').trim();
  if (!l && !r) return 'មិនទាន់បានពិនិត្យ';
  if (l.includes('6/9') || l.includes('6/12') || l.includes('6/15') || l.includes('6/18') || l.includes('6/21') ||
      r.includes('6/9') || r.includes('6/12') || r.includes('6/15') || r.includes('6/18') || r.includes('6/21')) {
    return 'ខ្សោយគំហើញ';
  }
  return 'ភ្នែកល្អ';
}

// Helper to evaluate ears
function evaluateEars(left, right, existingResult) {
  if (existingResult && existingResult.trim() !== '') return existingResult.trim();
  const lStr = String(left || '').replace(/[^\d.]/g, '');
  const rStr = String(right || '').replace(/[^\d.]/g, '');
  const l = parseFloat(lStr);
  const r = parseFloat(rStr);
  if (isNaN(l) && isNaN(r)) return 'មិនទាន់បានពិនិត្យ';
  if ((!isNaN(l) && l < 60) || (!isNaN(r) && r < 60)) {
    return 'ខ្សោយការស្ដាប់';
  }
  return 'ត្រចៀកល្អប្រសើរ';
}

// Helper to split full Cambodian name
function splitName(fullName) {
  const parts = String(fullName || '').trim().split(/\s+/);
  if (parts.length <= 1) {
    return { lastName: parts[0] || '', firstName: '' };
  }
  const lastName = parts[0];
  const firstName = parts.slice(1).join(' ');
  return { lastName, firstName };
}

// Helper to parse comma-separated address "រោគ, ស្ពានស្រែង, ភ្នំស្រុក, ខេត្តបន្ទាយមានជ័យ"
function splitAddress(addrStr) {
  if (!addrStr) return { village: '', commune: '', district: '', province: '' };
  const parts = String(addrStr).split(',').map(s => s.trim());
  if (parts.length >= 4) {
    return {
      village: parts[0],
      commune: parts[1],
      district: parts[2],
      province: parts[3].replace(/^ខេត្ត/, '').trim(),
    };
  }
  if (parts.length === 3) {
    return {
      village: '',
      commune: parts[0],
      district: parts[1],
      province: parts[2].replace(/^ខេត្ត/, '').trim(),
    };
  }
  return { village: '', commune: '', district: '', province: addrStr.trim() };
}

console.log('Converter helpers ready');
