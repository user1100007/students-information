const fs = require('fs');
const path = require('path');

// We will write the parser helper that turns the 34-column row into a clean StudentRecord
function rowToStudentRecord(row, idx) {
  const get = (i) => (row[i] !== undefined && row[i] !== null ? String(row[i]).trim() : '');
  
  const idNum = row[0] || (idx + 1);
  const studentCode = String(idNum).padStart(4, '0');
  
  // Split name "នាមត្រកូល និងនាម"
  const rawFullName = get(1);
  const nameParts = rawFullName.split(/\s+/).filter(Boolean);
  const lastName = nameParts[0] || '';
  const firstName = nameParts.slice(1).join(' ');

  const gender = get(2) || 'ស្រី';
  const dob = get(3);

  // Age from DOB
  let age = '';
  const yearMatch = dob.match(/\b(19\d\d|20\d\d)\b/);
  if (yearMatch) {
    const y = parseInt(yearMatch[1], 10);
    if (!isNaN(y) && y >= 1950 && y <= 2026) {
      age = 2026 - y;
    }
  }

  const previousGrade = get(4);

  // Parse Place of birth: "រោគ, ស្ពានស្រែង, ភ្នំស្រុក, ខេត្តបន្ទាយមានជ័យ"
  const rawPob = get(5);
  const pobParts = rawPob.split(',').map((s) => s.trim());
  let pobVillage = '';
  let pobCommune = '';
  let pobDistrict = '';
  let pobProvince = 'បន្ទាយមានជ័យ';
  if (pobParts.length >= 4) {
    pobVillage = pobParts[0];
    pobCommune = pobParts[1];
    pobDistrict = pobParts[2];
    pobProvince = pobParts[3].replace(/^ខេត្ត/, '').trim();
  } else if (pobParts.length === 3) {
    pobCommune = pobParts[0];
    pobDistrict = pobParts[1];
    pobProvince = pobParts[2].replace(/^ខេត្ត/, '').trim();
  }

  // Parents
  const rawFather = get(6);
  const fatherParts = rawFather.split(/\s+/).filter(Boolean);
  const fatherLastName = fatherParts[0] || '';
  const fatherFirstName = fatherParts.slice(1).join(' ');
  const fatherOccupation = get(7);

  const rawMother = get(8);
  const motherParts = rawMother.split(/\s+/).filter(Boolean);
  const motherLastName = motherParts[0] || '';
  const motherFirstName = motherParts.slice(1).join(' ');
  const motherOccupation = get(9);

  // Residence
  const rawCur = get(10);
  const curParts = rawCur.split(',').map((s) => s.trim());
  let curVillage = pobVillage;
  let curCommune = pobCommune;
  let curDistrict = pobDistrict;
  let curProvince = pobProvince;
  if (curParts.length >= 4) {
    curVillage = curParts[0];
    curCommune = curParts[1];
    curDistrict = curParts[2];
    curProvince = curParts[3].replace(/^ខេត្ត/, '').trim();
  } else if (curParts.length === 3) {
    curCommune = curParts[0];
    curDistrict = curParts[1];
    curProvince = curParts[2].replace(/^ខេត្ត/, '').trim();
  }

  const ethnicMinority = get(11) === 'ខ្មែរ' ? '' : get(11);
  const rawDisability = get(12);
  const disabilityType = rawDisability.includes('មិនមាន') ? '' : rawDisability;

  // Health: Height & Weight & BMI
  let heightSem1 = get(13);
  let weightSem1 = get(14);
  let bmiSem1 = get(15);
  let bmiStatusSem1 = get(16);

  // Normalize height if input was in meters like 1.5
  if (parseFloat(heightSem1) > 0 && parseFloat(heightSem1) < 3) {
    heightSem1 = String(parseFloat(heightSem1) * 100);
  }

  // If BMI not calculated or weird, calculate it
  const wNum = parseFloat(weightSem1);
  const hNum = parseFloat(heightSem1);
  if (!isNaN(wNum) && !isNaN(hNum) && wNum > 0 && hNum > 0) {
    const calcBmi = Number((wNum / Math.pow(hNum / 100, 2)).toFixed(1));
    bmiSem1 = String(calcBmi);
    if (!bmiStatusSem1 || bmiStatusSem1 === 'មិនទាន់គណនា') {
      if (calcBmi < 12.5) bmiStatusSem1 = 'ស្គមខ្លាំង';
      else if (calcBmi < 14.0) bmiStatusSem1 = 'ស្គម';
      else if (calcBmi <= 18.5) bmiStatusSem1 = 'ទម្ងន់ធម្មតា';
      else if (calcBmi <= 21.0) bmiStatusSem1 = 'លើសទម្ងន់';
      else bmiStatusSem1 = 'ធាត់';
    }
  }

  // Vision
  const eyeLeft = get(18);
  const eyeRight = get(19);
  let eyeResult = get(20);
  if (!eyeResult && (eyeLeft || eyeRight)) {
    if (eyeLeft.includes('6/12') || eyeLeft.includes('6/15') || eyeLeft.includes('6/18') || eyeLeft.includes('6/21') ||
        eyeRight.includes('6/12') || eyeRight.includes('6/15') || eyeRight.includes('6/18') || eyeRight.includes('6/21')) {
      eyeResult = 'ខ្សោយគំហើញ';
    } else {
      eyeResult = 'ភ្នែកល្អ';
    }
  }
  const eyeDevice = get(22);

  // Hearing
  const earLeft = get(25);
  const earRight = get(26);
  let earResult = get(27);
  if (!earResult && (earLeft || earRight)) {
    const l = parseFloat(String(earLeft).replace(/[^\d.]/g, ''));
    const r = parseFloat(String(earRight).replace(/[^\d.]/g, ''));
    if ((!isNaN(l) && l < 60) || (!isNaN(r) && r < 60)) {
      earResult = 'ខ្សោយការស្ដាប់';
    } else {
      earResult = 'ត្រចៀកល្អប្រសើរ';
    }
  }
  const earDevice = get(29);

  const vaccineList = get(32);
  const otherNotes = get(33);

  // Equity / Poor status infer from notes or disability
  let equityFamily = 'មិនក្រីក្រ';
  let equityCard = '';
  if (otherNotes.includes('ក្រ១')) equityFamily = 'ក្រ១';
  else if (otherNotes.includes('ក្រ២')) equityFamily = 'ក្រ២';
  else if (otherNotes.includes('ក្រ')) equityFamily = 'ផ្សេងៗ';

  // Orphan status
  let orphanStatus = 'មិនកំព្រា';
  if (rawFather.includes('ស្លាប់') && rawMother.includes('ស្លាប់')) {
    orphanStatus = 'កំព្រាឪពុកម្ដាយ';
  } else if (rawFather.includes('ស្លាប់')) {
    orphanStatus = 'កំព្រាឪពុក';
  } else if (rawMother.includes('ស្លាប់')) {
    orphanStatus = 'កំព្រាម្ដាយ';
  }

  return {
    id: `std-${studentCode}`,
    studentCode,
    lastName,
    firstName,
    gender,
    dob,
    age,
    phone: '',
    nationality: 'ខ្មែរ',
    pobProvince,
    pobDistrict,
    pobCommune,
    pobVillage,
    curProvince,
    curDistrict,
    curCommune,
    curVillage,
    academicYear: '2025-2026',
    previousGrade,
    enrollmentDate: '2025-11-01',
    disabilityType,
    kitReading: 'បានទទួល',
    kitMath: 'បានទទួល',
    kitKhmerBook: 'មាន',
    kitMathBook: 'មាន',
    equityFamily,
    equityCard,
    ethnicMinority,
    specialTrait: '',
    orphanStatus,
    weightSem1,
    heightSem1,
    bmiSem1,
    bmiStatusSem1,
    weightSem2: '',
    heightSem2: '',
    bmiSem2: '',
    bmiStatusSem2: '',
    eyeLeft,
    eyeRight,
    eyeBoth: eyeLeft && eyeRight ? `${eyeLeft}/${eyeRight}` : '',
    eyeResult,
    eyePrescription: eyeResult === 'ខ្សោយគំហើញ' ? 'ពិនិត្យវេជ្ជបញ្ជាពាក់វ៉ែនតា' : '',
    eyeDevice,
    earLeft,
    earRight,
    earBoth: earLeft && earRight ? `${earLeft}/${earRight}` : '',
    earResult,
    earPrescription: earResult === 'ខ្សោយការស្ដាប់' ? 'ពិនិត្យឧបករណ៍ជំនួយការស្តាប់' : '',
    earDevice,
    vaccineList,
    fatherLastName: fatherLastName.replace(/\(ស្លាប់\)/, '').trim(),
    fatherFirstName,
    fatherPhone: '',
    fatherOccupation: rawFather.includes('ស្លាប់') ? 'ស្លាប់' : fatherOccupation,
    fatherProvince: curProvince,
    fatherDistrict: curDistrict,
    fatherCommune: curCommune,
    fatherVillage: curVillage,
    motherLastName: motherLastName.replace(/\(ស្លាប់\)/, '').trim(),
    motherFirstName,
    motherPhone: '',
    motherOccupation: rawMother.includes('ស្លាប់') ? 'ស្លាប់' : motherOccupation,
    motherProvince: curProvince,
    motherDistrict: curDistrict,
    motherCommune: curCommune,
    motherVillage: curVillage,
    guardianType: fatherLastName ? 'ឪពុក' : (motherLastName ? 'ម្ដាយ' : 'អាណាព្យាបាល'),
    guardianLastName: fatherLastName || motherLastName || '',
    guardianFirstName: fatherFirstName || motherFirstName || '',
    guardianGender: fatherLastName ? 'ប្រុស' : 'ស្រី',
    guardianPhone: '',
    guardianOccupation: fatherOccupation || motherOccupation || 'កសិករ',
    guardianAddress: `ភូមិ${curVillage} ឃុំ${curCommune} ស្រុក${curDistrict} ខេត្ត${curProvince}`,
    otherNotes,
  };
}

module.exports = { rowToStudentRecord };
